#!/usr/bin/env node

const fs = require("fs");

let num = 0;
const lines = fs
    .readFileSync("tests.md", "utf8")
    .split("\n")
    .map((line) =>
        line.substr(0, 4) === "####"
            ? line.replace(/^[^a-zA-Z]+/, `#### ${++num}. `)
            : line
    );

fs.writeFileSync("tests.md", lines.join("\n"), "utf8");
