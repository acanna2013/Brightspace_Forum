package cs180.server.database;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Controller class
 * Allows the user to manipulate courses, posts, and forums.
 * Testing of the Controller class is done in the ControllerTest class.
 *
 * @author Anna Chen
 * @version November 30, 2021
 */

public class Controller
{

    private Database db;
    private boolean enableSaving;

    /**
     * Instantiates users, forums, and posts with given parameters.
     *
     * @param db
     *            The database
     */
    public Controller(Database db)
    {
        this(db, true);
    }

    /**
     * Instantiates users, forums, and posts with given parameters.
     *
     * @param db
     *            The database
     */
    public Controller(Database db, boolean enableSaving)
    {
        this.db = db;
        this.enableSaving = enableSaving;
    }

    /**
     * FetchException thrown for server exceptions
     */
    public static class FetchException extends Exception
    {
        public FetchException(String message)
        {
            super(message);
        }

        public FetchException(String message, Throwable cause)
        {
            super(message, cause);
        }
    }

    public synchronized Database getDatabase()
    {
        return this.db;
    }

    public synchronized Course getCourse(UUID uuid)
    {
        return db.getCourse(uuid);
    }

    public synchronized Map<UUID, Course> getAllCourses()
    {
        return db.getCourses();
    }

    public synchronized Map<UUID, User> getAllUsers()
    {
        return db.getUsers();
    }

    public synchronized void deleteCourse(User currentUser,
                                          UUID uuid)
        throws FetchException
    {
        if (currentUser.getKind().equalsIgnoreCase("Teacher")
            && getCourse(uuid).getTeacher()
                .equals(currentUser.getUUID()))
        {
            db.getCourse(uuid).getStudents().stream()
                .map((id) -> db.getUser(id))
                .forEach((member) -> {
                    member.removeCourse(uuid);
                });
            db.removeCourse(uuid);
        } else if (currentUser.getKind()
            .equalsIgnoreCase("Teacher")
            && !getCourse(uuid).getTeacher()
                .equals(currentUser.getUUID()))
        {
            throw new FetchException("You must be the instructor to delete this course.");
        } else
        {
            throw new FetchException("Students cannot delete a course!");
        }
    }

    public synchronized void createCourse(User currentUser,
                                          Course course)
        throws FetchException
    {
        // only teachers can create courses
        if (currentUser.getKind().equalsIgnoreCase("Teacher"))
        {
            db.addCourse(course);
            currentUser.addCourse(course.getUUID());
        } else
        {
            throw new FetchException("Students cannot create a course!");

        }
    }

    /**
     * Get a user by their username (case insensitive)
     */
    public synchronized User getUserByUsername(String username)
    {
        for (User user : db.getUsers().values())
        {
            if (user.getUsername().equalsIgnoreCase(username))
            {
                return user;
            }
        }
        return null;
    }

    /**
     * Get a user by their name (case insensitive)
     */
    // confirm that return type is User (originally was Course)
    public synchronized User getUserByName(String name)
    {
        for (User user : db.getUsers().values())
        {
            if (user.getFullName().equalsIgnoreCase(name))
            {
                return user;
            }
        }
        return null;
    }

    /**
     * Get a course by its course name (case insensitive)
     */
    public synchronized Course getCourseByName(String name)
    {
        for (Course course : db.getCourses().values())
        {
            if (course.getTitle().equalsIgnoreCase(name))
            {
                return course;
            }
        }
        return null;
    }

    /**
     * Get a forum by its topic (case insensitive)
     */
    // confirm that return type is Forum (originally was Course)
    public synchronized Forum getForumByTopic(User currentUser,
                                              String topic)
    {
        for (Forum forum : db.getForums().values())
        {
            if (forum.getForumTopic().equalsIgnoreCase(topic))
            {
                return forum;
            }
        }
        return null;
    }

    /**
     * Gets User associated with the uuid specified.
     *
     * @param uuid
     *            User's uuid
     * @return User object
     */
    public synchronized User getUser(UUID uuid)
    {
        return db.getUsers().get(uuid);
    }

    /**
     * Creates a new user with the specified parameters.
     *
     * @param user
     *            the user
     */
    public synchronized void createUser(User user)
        throws FetchException
    {
        if (db.getUsers().containsKey(user.getUUID()))
        {
            throw new FetchException("User already exists in the database!");
        } else
        {
            db.addUser(user);
            List<UUID> temp =
                new ArrayList<UUID>(user.getCourses());
            for (UUID uuid : temp)
            {
                db.getCourse(uuid).addStudent(user.getUUID());
            }
        }
    }

    /**
     * Deletes the user from the users arraylist.
     *
     * @param user
     *            User object.
     */
    public synchronized void deleteUser(User currentUser,
                                        User user)
        throws FetchException
    {
        if (currentUser.getKind().equalsIgnoreCase("Teacher")
            || currentUser.getUUID().equals(user.getUUID()))
        {
            if (!db.getUsers().containsKey(user.getUUID()))
            {
                throw new FetchException("User does not exist in the database");
            } else
            {
                List<UUID> tempCourses =
                    new ArrayList<UUID>(user.getCourses());
                for (UUID uuid : tempCourses)
                {
                    db.getCourse(uuid)
                        .removeStudent(user.getUUID());
                }

                List<UUID> tempMessages =
                    new ArrayList<UUID>(user.getMessages());

                for (UUID uuid : tempMessages)
                {
                    if (db.getMessage(uuid) != null)
                        deletePost(currentUser,
                                   db.getMessage(uuid));
                }
                db.removeUser(user.getUUID());
            }
        } else
        {
            throw new FetchException("You are unauthorized to delete this user.");
        }
    }

    /**
     * @param uuid
     *            uuid of the post.
     * @return the post with the specified uuid.
     */
    public synchronized Message getPost(UUID uuid)
    {
        return db.getMessage(uuid);
    }

    /**
     * Create a post on a specified forum.
     *
     * @param post
     *            The post the user wants to create.
     */
    public synchronized void createPost(User currentUser,
                                        Message post)
    {
        db.addMessage(post);
        db.getUser(post.getPostedBy())
            .addMessage(post.getUUID());
        if (post.getParentPost() != null)
        {
            db.getMessage(post.getParentPost())
                .addComment(post.getUUID());
        }
        if (post.getForum() != null)
            db.getForum(post.getForum())
                .addMessage(post.getUUID());
    }

    /**
     * Delete a post from a specified forum.
     *
     * @param post
     *            The post the user wants to delete.
     */
    public synchronized void deletePost(User currentUser,
                                        Message post)
        throws FetchException
    {
        if (currentUser.getKind().equalsIgnoreCase("Teacher")
            || currentUser.getUUID()
                .equals(post.getPostedBy()))
        {
            if (post.getForum() != null)
            {
                db.getForum(post.getForum())
                    .removeMessage(post.getUUID());
            }
            if (post.getParentPost() != null)
            {
                if (db.getMessage(post.getParentPost())
                    != null)
                    db.getMessage(post.getParentPost())
                        .removeComment(post.getUUID());
            }
            if (post.getPostedBy() != null)
            {
                db.getUser(post.getPostedBy())
                    .removeMessage(post.getUUID());
            }

            // delete all comments on the post
            List<UUID> temp =
                new ArrayList<UUID>(db
                    .getMessage(post.getUUID())
                    .getComments());
            for (UUID uuid : temp)
            {
                deletePost(currentUser, db.getMessage(uuid));
            }
            db.removeMessage(post.getUUID());
        } else
        {
            throw new FetchException("You are unauthorized to delete this post!");
        }
    }

    /**
     * Gets the forum with the specified uuid.
     *
     * @param uuid
     *            UUID of the forum.
     * @return the forum with the specified uuid.
     */
    public synchronized Forum getForum(UUID uuid)
    {
        return db.getForums().get(uuid);
    }

    /**
     * Creates a forum with the specified uuid and topic.
     *
     * @param forum
     *            the new forum
     */
    public synchronized void createForum(User currentUser,
                                         Forum forum)
        throws FetchException
    {
        if (currentUser.getKind().equalsIgnoreCase("Teacher"))
        {
            db.addForum(forum);
            // add forum to the course it's under
            db.getCourse(forum.getCourse())
                .addForum(forum.getUUID());
        } else
        {
            throw new FetchException("You are unauthorized to create a new forum!");
        }
    }

    /**
     * Deletes the forum with the specified uuid.
     *
     * @param forum
     *            The forum the user wants to delete.
     */
    public synchronized void deleteForum(User currentUser,
                                         Forum forum)
        throws FetchException
    {
        if (currentUser.getKind().equalsIgnoreCase("Teacher"))
        {
            db.getCourse(forum.getCourse())
                .removeForum(forum.getUUID());
            List<UUID> temp =
                new ArrayList<UUID>(db
                    .getForum(forum.getUUID()).getMessages());
            for (UUID uuid : temp)
            {
                db.getForum(forum.getUUID())
                    .removeMessage(uuid);
            }
            db.removeForum(forum.getUUID());
        } else
        {
            throw new FetchException("You are unauthorized to delete a forum!");
        }
    }

    public synchronized UUID login(String username,
                                   String password)
        throws FetchException
    {
        if (getUserByUsername(username) == null)
            throw new FetchException("User does not exist");
        else
        {
            if (!getUserByUsername(username).getPassword()
                .equals(password))
            {
                throw new FetchException("Invalid password!");
            }
            return getUserByUsername(username).getUUID();
        }
    }

    public synchronized void saveDatabase()
    {
        if (enableSaving)
            db.saveDatabase();
    }
}
