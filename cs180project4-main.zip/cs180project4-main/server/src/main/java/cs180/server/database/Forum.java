package cs180.server.database;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Forum Class - A forum for a specific course.
 * Holds messages from users in that course.
 * Contains methods that can manipulate a forum:
 *      change title name, add/remove messages
 * The Forum class is tested in the CommandTest class.
 * @author Ahmad Abdallah
 * @version November 13th, 2021
 *
 */
public class Forum
{
    private UUID uuid;
    private UUID course;
    private List<UUID> messages;
    private String forumTopic;

    /**
     * Instantiates forum with specified parameters
     * 
     * @param course
     *            The associated course's UUID
     * @param forumTopic
     *            The topic of the forum
     */
    public Forum(UUID course, String forumTopic)
    {
        this.uuid = UUID.randomUUID();
        this.course = course;
        this.forumTopic = forumTopic;
        this.messages = new ArrayList<UUID>();

    }

    /**
     * Instantiates forum with all fields initialized to null (except messages
     * list
     * which is an empty arraylist)
     */
    public Forum()
    {
        this.uuid = null;
        this.course = null;
        this.forumTopic = null;
        this.messages = new ArrayList<UUID>();
    }

    /**
     * Gets forum UUID
     * 
     * @return Forum UUID
     */
    public UUID getUUID()
    {
        return uuid;
    }

    /**
     * Gets course UUID
     * 
     * @return Course UUID
     */
    public UUID getCourse()
    {
        return course;
    }

    /**
     * Gets forum topic
     * 
     * @return Forum topic
     */
    public String getForumTopic()
    {
        return forumTopic;
    }

    /**
     * Gets list of UUIDs for each message in Forum
     * 
     * @return List of UUIDs associated with messages
     */
    public List<UUID> getMessages()
    {
        return messages;
    }

    /**
     * Updates forum topic to the given parameter
     * 
     * @param forumTopic
     *            The new topic given to forum
     */
    public void setForumTopic(String forumTopic)
    {
        this.forumTopic = forumTopic;
    }

    /**
     * Adds given message UUID to the forum's messages list
     * 
     * @param message
     *            UUID for new message
     */
    public void addMessage(UUID message)
    {
        Objects.requireNonNull(message);

        messages.add(message);
    }

    /**
     * Removes given message UUID from forum's messages list
     * 
     * @param message
     *            UUID for message to remove
     */
    public void removeMessage(UUID message)
    {
        Objects.requireNonNull(message);

        if (!messages.contains(message))
        {
            return;
        } else
        {
            messages.remove(message);
        }
    }

    /**
     * Saves forum object in Database/Forum directory. File name is
     * [object-uuid].txt
     * 
     */
    public void save()
    {
        if (uuid == null)
        {
            System.out
                .println("Forum UUID not instantiated, cannot save");
            return;
        }

        // Location of file to save to
        String fileName =
            String.format("Database/Forum/%s.txt",
                          uuid.toString());

        String messagesString = "";
        File f = new File(fileName);

        try
        {
            // Writer initialization
            FileWriter fw = new FileWriter(f, false);
            BufferedWriter bfw = new BufferedWriter(fw);

            // Writes toString string representing forum
            bfw.write(toString());

            // Closes all writers
            bfw.close();
            fw.close();

        } catch (NullPointerException npe)
        {
            System.out
                .println("Cannot save null values, please initialize fields");
            npe.printStackTrace();
        } catch (FileNotFoundException fnf)
        {
            System.out.println("Forum file not found!");
        } catch (IOException ioe)
        {
            System.out.println("Failed to save forum");
            ioe.printStackTrace();
        }

    }

    /**
     * Loads forum object from Database/Forum directory.
     * 
     * @param uuid
     *            UUID of requested forum object
     * 
     */
    public void load(UUID forumUUID)
    {
        String fileName =
            String.format("Database/Forum/%s.txt",
                          forumUUID.toString());

        String messagesString = "";
        String[] messagesArray = new String[1];
        File f = new File(fileName);

        try
        {
            FileReader fr = new FileReader(f);
            BufferedReader bfr = new BufferedReader(fr);

            // Load forum UUID
            this.uuid = UUID.fromString(bfr.readLine());

            // Load course UUID
            this.course = UUID.fromString(bfr.readLine());

            // Load string representing messages array
            messagesString = bfr.readLine();

            // Check if no messages exist
            if (!messagesString.equals("none"))
            {
                // Make sure forum has multiple messages
                if (messagesString.contains(","))
                {
                    messagesArray = messagesString.split(",");

                    // Add message UUIDs from string to messages arraylist
                    for (int i = 0; i < messagesArray.length;
                         i++)
                    {
                        messages.add(UUID
                            .fromString(messagesArray[i]));
                    }
                } else // Case where only one message for a forum
                {
                    messages
                        .add(UUID.fromString(messagesString));
                }

            }

            this.forumTopic = bfr.readLine();

            // Close readers
            bfr.close();
            fr.close();
        } catch (IllegalArgumentException iae)
        {
            System.out.println("Illegal argument!");
            iae.printStackTrace();
        } catch (FileNotFoundException fnf)
        {
            System.out.println("Forum file not found");
        } catch (IOException ioe)
        {
            System.out.println("Failed to load forum");
            ioe.printStackTrace();
        }
    }

    /**
     *
     * Provides string representation of forum object
     *
     * @return String containing all fields of forum object
     *
     */
    @Override
    public String toString()
    {
        String messagesString = "";
        String forumString = "";

        if (messages.size() != 0)
        {
            for (int i = 0; i < messages.size(); i++)
            {
                if (i != 0)
                {
                    messagesString += ",";
                }
                messagesString += messages.get(i).toString();
            }

        } else
        {
            messagesString = "none";
        }

        forumString =
            String.format("%s\n%s\n%s\n%s", uuid.toString(),
                          course.toString(), messagesString,
                          forumTopic);

        return forumString;

    }

}