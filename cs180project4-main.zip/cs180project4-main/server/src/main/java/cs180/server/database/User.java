package cs180.server.database;

import cs180.serialize.ReceiveOnly;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * User class
 * Contains methods that manipulate:
 *      the kind of the user (teacher/student), courses they're enrolled in, messages they've posted,
 *      their unique attributes (username, fullname, password)
 * The User class is tested in the CommandTest class.
 *
 * @author Rachel La
 * @version November 6, 2021
 */
// clang-format off
public class User {
    private UUID uuid;
    private String kind;
    private String username;
    private String fullName;
    @ReceiveOnly
    private String password;
    private List<UUID> courses;
    private List<UUID> messages;

    /**
     * Constructs a User object with given parameters
     *
     * @param kind
     * @param username
     * @param fullName
     * @param password
     */
    public User(String kind, String username, String fullName,
                String password) {
        this.uuid = UUID.randomUUID();
        this.kind = kind;
        this.username = username;
        this.fullName = fullName;
        this.password = password;
        this.courses = new ArrayList<UUID>();
        this.messages = new ArrayList<UUID>();
    }

    /**
     * Constructs a User object with given parameters
     *
     * @param username
     * @param password
     * @param uuid
     */
    public User(String username, String password, UUID uuid) {
        this.username = username;
        this.password = password;
        this.uuid = uuid;
    }

    /**
     * Constructs a User object with null fields
     */
    public User() {
        this.uuid = null;
        this.kind = null;
        this.username = null;
        this.fullName = null;
        this.password = null;
        this.courses = new ArrayList<UUID>();
        this.messages = new ArrayList<UUID>();
    }

    /**
     * Returns the UUID of the user
     */
    public UUID getUUID() {
        return this.uuid;
    }

    /**
     * Returns the kind of the user (student or teacher)
     */
    public String getKind() {
        return this.kind;
    }

    /**
     * Sets the kind of the user to the kind given as a parameter
     *
     * @param kind
     */
    public void setKind(String kind) {
        this.kind = kind;
    }

    /**
     * Returns the username of the user
     */
    public String getUsername() {
        return this.username;
    }

    /**
     * Sets username of the user to the username given as a parameter
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Returns the full name of the user
     */
    public String getFullName() {
        return this.fullName;
    }

    /**
     * Sets full name of the user to the full name given as a parameter
     *
     * @param fullName
     */
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    /**
     * Returns the password of the user
     */
    public String getPassword() {
        return this.password;
    }

    /**
     * Sets password of the user to the password given as a parameter
     *
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Returns the list of courses the user enrolls in
     */
    public List<UUID> getCourses() {
        return this.courses;
    }

    /**
     * Adds new course to the current list of courses
     *
     * @param course
     */
    public void addCourse(UUID course) {
        courses.add(course);
    }

    /**
     * Removes course from the current list of courses
     *
     * @param course
     */
    public void removeCourse(UUID course) {
        courses.remove(course);
    }

    /**
     * Returns a list of messages the student posted
     */
    public List<UUID> getMessages() {
        return this.messages;
    }

    /**
     * Adds new message to the list of messages
     *
     * @param message
     */
    public void addMessage(UUID message) {
        messages.add(message);
    }

    /**
     * Removes message from the list of messages
     *
     * @param message
     */
    public void removeMessage(UUID message) {
        messages.remove(message);
    }

    /**
     * @return variables as a string
     */
    public String toString() {
        String courseString = "";
        String messageString = "";
        if (getCourses().size() == 0) {
            courseString = "none";
        } else {
            for (UUID c : getCourses()) {
                courseString += c + ",";
            }
            courseString =
                courseString.substring(0,
                    courseString.lastIndexOf(','));
        }

        if (getMessages().size() == 0) {
            messageString = "none";
        } else {
            for (UUID m : getMessages()) {
                messageString += m + ",";
            }
            messageString =
                messageString.substring(0,
                    messageString.lastIndexOf(','));
        }
        return getUUID() + "\n" + getKind() + "\n"
                + getUsername() + "\n" + getPassword() + "\n"
                + getFullName() + "\n" + courseString + "\n"
                + messageString;
    }

    /**
     * Creates an uuid.txt file and saves it to Database/User/
     * Writes toString to uuid.txt
     */
    public void saveUser() {
        String file =
                String.format("Database/User/%s.txt", uuid);
        try {
            if (uuid != null) {
                File f = new File(file);
                BufferedWriter writer =
                        new BufferedWriter(new FileWriter(f));
                writer.write(toString());
                writer.close();
            } else {
                System.out
                        .println("User UUID not instantiated, cannot save");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Loads user with the given uuid
     *
     * @param uuid
     */
    public void loadUser(UUID userUuid) {
        String file =
                String.format("Database/User/%s.txt", userUuid);
        try {
            BufferedReader reader =
                    new BufferedReader(new FileReader(file));
            // Sets user uuid
            this.uuid = UUID.fromString(reader.readLine());
            // Sets user kind
            this.kind = reader.readLine();
            // Sets username
            this.username = reader.readLine();
            // Sets password
            this.password = reader.readLine();
            // Sets full name
            this.fullName = reader.readLine();
            String coursesLine = reader.readLine();
            String[] courseList;
            if (!coursesLine.equals("none")) {
                courseList = coursesLine.split(",");
                for (int i = 0; i < courseList.length; i++) {
                    // Sets all courses the user enrolls in to course list
                    this.courses
                            .add(i,
                                    UUID.fromString(courseList[i]));
                }
            }
            String messagesLine = reader.readLine();
            String[] messageList;
            if (!messagesLine.equals("none")) {
                messageList = messagesLine.split(",");
                for (int i = 0; i < messageList.length; i++) {
                    // Sets all messages the user posted to message list
                    this.messages
                            .add(i,
                                    UUID.fromString(messageList[i]));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
// clang-format on
