package cs180.server;

import cs180.serialize.Serialize;
import cs180.server.database.*;
import cs180.server.database.Controller;
import cs180.server.database.Controller.FetchException;
import java.io.*;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * The ServerInterface class is created for each incoming connection.  This
 * class handles parsing incoming messages over TCP and calling the appropriate
 * methods in the Controller class.
 *
 * @author Zachary Mayhew
 * @version December 10, 2021
 */
public class ServerInterface implements Runnable {
    private static AtomicInteger nextId = new AtomicInteger(0);

    private Controller app;
    private PrintStream out;
    private Scanner in;
    private Socket socket;

    private int id;

    private UUID currentUser;
    private UUID sessionId;
    private ServerController serverInstance;

    public ServerInterface(ServerController serverInstance, Controller app, Socket socket) throws IOException {
        this.serverInstance = serverInstance;
        this.socket = socket;
        this.app = app;
        this.id = nextId.getAndIncrement();
        this.currentUser = null;
        this.sessionId = null;
        this.out = new PrintStream(socket.getOutputStream());
        this.in = new Scanner(socket.getInputStream());
    }

    /**
     * Log with the current id
     */
    private void log(String message, Object... args) {
        System.out.printf("[" + id + "] " + message + "\n", args);
    }

    @Override
    public void run() {
        try {
            handleInput();
        } catch (NoSuchElementException e) {
            e.printStackTrace();
        }
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleInput() throws NoSuchElementException {
        var beginLine = in.nextLine().split("\t");
        if (beginLine[0].equals("PING")) {
            log("%s\tPING", socket.getInetAddress().toString());
            out.println("PING~");
            return;
        } else if (beginLine[0].equals("BEGIN_LOGIN")) {
            this.currentUser = handleLogin();
            return;
        } else if (beginLine[0].equals("BEGIN_REQUEST")) {
            if (beginLine.length >= 2) {
                sessionId = UUID.fromString(beginLine[1]);
                currentUser = serverInstance.getSession(sessionId);
            }
            var requestLine = in.nextLine().split("\t");
            if (requestLine.length != 2) {
                log("ErrInfo: %s", Arrays.toString(requestLine));
                respondErr("Invalid request");
                return;
            }
            var requestType = requestLine[0];
            var requestPath = requestLine[1];
            try {
                var okResponse = handleRequest(requestType, requestPath);
                if (!in.nextLine().equals("END_REQUEST")) {
                    respondErr("Invalid requestyee");
                    return;
                }
                if (okResponse != null) {
                    respondOk(okResponse);
                } else {
                    // clang-format off
                    respondOk((unused) -> {
                    });
                    // clang-format on
                }
            } catch (FetchException e) {
                if (!in.nextLine().equals("END_REQUEST"))
                    log("Invalid request received");
                respondErr(e);
                return;
            }
        } else {
            respondErr("Invalid request");
            return;
        }
        app.saveDatabase();
    }

    private Consumer<PrintStream> handleRequest(String method, String path) throws FetchException {
        log("%s\t%s\t%s", socket.getInetAddress().toString(), method, path);
        switch (method) {
        case "POST":
            return handlePost(path.split("/"));
        case "GET":
            return handleGet(path.split("/"));
        case "PUT":
            return handlePut(path.split("/"));
        case "DELETE":
            return handleDelete(path.split("/"));
        default:
            throw new FetchException("Illegal method");
        }
    }

    private User getCurrentUser() {
        return app.getUser(currentUser);
    }

    private Consumer<PrintStream> handlePost(String[] path) throws FetchException {
        if (path.length != 1)
            throw new FetchException("Invalid post path");
        try {
            switch (path[0]) {
            case "users": {
                app.createUser(Serialize.deserialize(in, User.class));
                return null;
            }
            case "posts": {
                if (currentUser == null)
                    throw new FetchException("You must be logged in to post posts");
                app.createPost(getCurrentUser(), Serialize.deserialize(in, Message.class));
                return null;
            }
            case "forums": {
                if (currentUser == null)
                    throw new FetchException("You must be logged in to post forums");
                app.createForum(getCurrentUser(), Serialize.deserialize(in, Forum.class));
                return null;
            }
            case "courses": {
                if (currentUser == null)
                    throw new FetchException("You must be logged in to post courses");
                app.createCourse(getCurrentUser(), Serialize.deserialize(in, Course.class));
                return null;
            }
            default:
                throw new FetchException("Invalid resource path");
            }
        } catch (Serialize.ParseException e) {
            throw new FetchException(e.getMessage(), e);
        }
    }

    private Consumer<PrintStream> handlePut(String[] path) throws FetchException {
        if (currentUser == null)
            throw new FetchException("You must be logged in to put objects");
        if (path.length != 2)
            throw new FetchException("Invalid put path");
        var uuid = UUID.fromString(path[1]);
        try {
            switch (path[0]) {
            case "users": {
                var user = app.getUser(uuid);
                Serialize.deserialize(in, user);
                return null;
            }
            case "posts": {
                var post = app.getPost(uuid);
                Serialize.deserialize(in, post);
                return null;
            }
            case "forums": {
                var forum = app.getForum(uuid);
                Serialize.deserialize(in, forum);
                return null;
            }
            case "courses": {
                var course = app.getCourse(uuid);
                Serialize.deserialize(in, course);
                return null;
            }
            default:
                throw new FetchException("Invalid resource path");
            }
        } catch (Serialize.ParseException e) {
            throw new FetchException(e.getMessage(), e);
        }
    }

    private Consumer<PrintStream> handleDelete(String[] path) throws FetchException {
        if (currentUser == null)
            throw new FetchException("You must be logged in to delete objects");
        if (path.length != 2)
            throw new FetchException("Invalid delete path");
        var uuid = UUID.fromString(path[1]);
        switch (path[0]) {
        case "users": {
            var user = app.getUser(uuid);
            app.deleteUser(getCurrentUser(), user);
            return null;
        }
        case "posts": {
            var post = app.getPost(uuid);
            app.deletePost(getCurrentUser(), post);
            return null;
        }
        case "forums": {
            var forum = app.getForum(uuid);
            app.deleteForum(getCurrentUser(), forum);
            return null;
        }
        case "courses": {
            app.deleteCourse(getCurrentUser(), uuid);
            return null;
        }
        default:
            throw new FetchException("Invalid resource path");
        }
    }

    private Consumer<PrintStream> handleGet(String[] path) throws FetchException {
        if (path.length == 1) {
            switch (path[0]) {
            case "courses": {
                var courses = app.getAllCourses().values();
                return (out) -> Serialize.serializeList(out, courses);
            }
            case "users": {
                var users = app.getAllUsers().values();
                return (out) -> Serialize.serializeList(out, users);
            }
            default:
                throw new FetchException("Invalid resource path");
            }
        } else if (path.length == 2) {
            var uuid = UUID.fromString(path[1]);
            switch (path[0]) {
            case "courses": {
                var course = app.getCourse(uuid);
                if (course == null)
                    throw new FetchException("The course doesn't exist!");
                return (out) -> Serialize.serialize(out, course);
            }
            case "posts": {
                var post = app.getPost(uuid);
                if (post == null)
                    throw new FetchException("The post doesn't exist!");
                return (out) -> Serialize.serialize(out, post);
            }
            case "forums": {
                var forum = app.getForum(uuid);
                if (forum == null)
                    throw new FetchException("The forum doesn't exist!");
                return (out) -> Serialize.serialize(out, forum);
            }
            case "users": {
                var user = app.getUser(uuid);
                if (user == null)
                    throw new FetchException("The user doesn't exist!");
                return (out) -> Serialize.serialize(out, user);
            }
            default:
                throw new FetchException("Invalid resource path");
            }
        } else {
            throw new FetchException("Invalid get path");
        }
    }

    private UUID handleLogin() throws NoSuchElementException {
        while (true) {

            var usernameLine = in.nextLine().split("\t");
            var passwordLine = in.nextLine().split("\t");

            var endLogin = in.nextLine();

            if (!usernameLine[0].equals("USERNAME") || !passwordLine[0].equals("PASSWORD") ||
                !endLogin.equals("END_LOGIN")) {
                respondErr("Bad login request");
                continue;
            }

            var username = usernameLine[1];
            var password = passwordLine[1];

            try {
                var uid = app.login(username, password);
                sessionId = serverInstance.makeSession(uid);
                respondOk((outTwo) -> {
                    outTwo.println(uid.toString());
                    outTwo.println(sessionId);
                });
                log("%s\tLOGIN\t%s", socket.getInetAddress().toString(), username);
                return uid;
            } catch (FetchException e) {
                respondErr(e);
                continue;
            }
        }
    }

    private void respondOk(Consumer<PrintStream> response) {
        out.println("BEGIN_RESPONSE");
        out.println("OK");
        response.accept(out);
        out.println("END_RESPONSE");
    }

    private void respondErr(Throwable e) {
        respondErr(e.getMessage());
    }

    private void respondErr(String message) {
        out.println("BEGIN_RESPONSE");
        out.println("ERR\t" + message);
        out.println("END_RESPONSE");
    }
}
