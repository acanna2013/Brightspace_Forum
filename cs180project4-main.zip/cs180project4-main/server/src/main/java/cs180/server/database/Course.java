package cs180.server.database;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Course class
 * Contains attributes of a Course, getters, and setters.
 * Contains methods to add/remove forums/students to a course.
 * Save and load course information into a file.
 * The Course class is tested in the CommandTest class.
 * @author Rachel La
 * @version November 11, 2021
 */

public class Course
{
    private UUID uuid;
    private String title;
    private UUID teacher;
    private List<UUID> students;
    private List<UUID> forums;

    /**
     * Constructs a Course object with given parameters
     *
     * @param teacher
     * @param title
     */
    public Course(UUID teacher, String title)
    {
        this.uuid = UUID.randomUUID();
        this.teacher = teacher;
        this.title = title;
        students = new ArrayList<UUID>();
        forums = new ArrayList<UUID>();
    }

    /**
     * Constructs a Course object with null fields
     */
    public Course()
    {
        this.uuid = null;
        this.teacher = null;
        this.title = null;
        students = new ArrayList<UUID>();
        forums = new ArrayList<UUID>();
    }

    /**
     * Returns the UUID of the course
     */
    public UUID getUUID()
    {
        return this.uuid;
    }

    /**
     * Returns the title of the course
     */
    public String getTitle()
    {
        return this.title;
    }

    /**
     * Sets the title of the course to the title given as a parameter
     *
     * @param title
     */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /**
     * Returns the teacher's UUID
     */
    public UUID getTeacher()
    {
        return this.teacher;
    }

    /**
     * Returns a list of UUIDs of the students enroll the course
     */
    public List<UUID> getStudents()
    {
        return this.students;
    }

    /**
     * Adds new student given as a parameter to the course
     *
     * @param student
     */
    public void addStudent(UUID student)
    {
        students.add(student);
    }

    /**
     * Removes student provided in the parameter from the course
     *
     * @param student
     */
    public void removeStudent(UUID student)
    {
        students.remove(student);
    }

    /**
     * Returns a list of UUIDs of the forums in the course
     */
    public List<UUID> getForum()
    {
        return this.forums;
    }

    /**
     * Adds new forum given as a parameter to the course
     *
     * @param forum
     */
    public void addForum(UUID forum)
    {
        forums.add(forum);
    }

    /**
     * Removes forum provided in the parameter from the course
     *
     * @param forum
     */
    public void removeForum(UUID forum)
    {
        forums.remove(forum);
    }

    /**
     *
     * @return variables as a string
     */
    public String toString()
    {
        String studentString = "";
        String forumString = "";
        if (getStudents().size() == 0) {
            studentString = "none";
        } else
        {
            for (UUID s : getStudents())
            {
                studentString += s + ",";
            }
            studentString =
                studentString.substring(0,
                    studentString.lastIndexOf(','));
        }

        if (getForum().size() == 0) {
            forumString = "none";
        } else
        {
            for (UUID f : getForum()) {
                forumString += f + ",";
            }
            forumString =
                forumString.substring(0, forumString.lastIndexOf(','));
        }
        return getUUID() + "\n" + getTeacher() + "\n"
                + getTitle() + "\n" + studentString + "\n" + forumString;
    }

    /**
     * Creates an uuid.txt file and saves it to Database/Course/
     * Writes toString to uuid.txt
     */
    public void saveCourse()
    {
        String file =
                String.format("Database/Course/%s.txt", uuid);
        try
        {
            if (uuid != null) {
                File f = new File(file);
                BufferedWriter writer =
                        new BufferedWriter(new FileWriter(f));
                writer.write(toString());
                writer.close();
            } else {
                System.out
                        .println("Course UUID not instantiated, cannot save");
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Loads course with the given uuid
     *
     * @param uuid
     */
    public void loadCourse(UUID courseUuid)
    {
        String file =
                String.format("Database/Course/%s.txt", courseUuid);
        try {
            BufferedReader reader =
                    new BufferedReader(new FileReader(file));
            // Sets course uuid
            this.uuid = UUID.fromString(reader.readLine());
            // Sets teacher uuid
            this.teacher = UUID.fromString(reader.readLine());
            // Sets title
            this.title = reader.readLine();
            String studentsLine = reader.readLine();
            String[] studentList;
            if (!studentsLine.equals("none")) {
                studentList = studentsLine.split(",");
                for (int i = 0; i < studentList.length; i++) {
                    // Sets students enroll in the course to student list
                    this.students
                            .add(i,
                                    UUID.fromString(studentList[i]));
                }
            }
            String forumsLine = reader.readLine();
            String[] forumList;
            if (!forumsLine.equals("none")) {
                forumList = forumsLine.split(",");
                for (int i = 0; i < forumList.length; i++) {
                    // Sets forums in the course to forum list
                    this.forums
                            .add(i,
                                    UUID.fromString(forumList[i]));
                }
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
