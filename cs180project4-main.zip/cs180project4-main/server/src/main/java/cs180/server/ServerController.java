package cs180.server;

import cs180.server.database.Controller;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The ServerController class manages the creation of new threads each with its
 * own instance of ServerInterface.  The ServerController also maintains a map
 * of all session ID's and their corresponding user id's.
 *
 * @author Zachary Mayhew
 * @version December 11, 2021
 */
public class ServerController {

    private Controller app;
    private int port;
    private ConcurrentHashMap<UUID, UUID> sessions;
    private AtomicBoolean shouldClose;
    private ServerSocket serverSocket;

    public ServerController(Controller app, int port) {
        this.serverSocket = null;
        this.sessions = new ConcurrentHashMap<>();
        this.app = app;
        this.port = port;
        this.shouldClose = new AtomicBoolean(false);
    }

    // No need to sync bc shouldClose is atomic
    public void kill() throws IOException {
        this.serverSocket.close();
        this.shouldClose.set(true);
    }

    /**
     * Creates a new session with the given userId and returns the session id
     */
    public synchronized UUID makeSession(UUID userId) {
        var sid = UUID.randomUUID();
        sessions.put(sid, userId);
        return sid;
    }

    /**
     * Returns the user id associated with the given session
     */
    public UUID getSession(UUID sid) {
        return sessions.get(sid);
    }

    public void start() throws IOException {
        start(new Object());
    }

    public void start(Object readyMonitor) throws IOException {
        synchronized (readyMonitor) {
            serverSocket = new ServerSocket(port);
            System.out.println("Opened on port " + port);
            readyMonitor.notifyAll();
        }

        while (!shouldClose.get() && serverSocket.isBound()) {
            try {
                var socket = serverSocket.accept();
                var handler = new Thread(new ServerInterface(this, app, socket));
                handler.start();
            } catch (IOException e) {
                if (e.getMessage().equals("Socket closed")) {
                    continue;
                }
                e.printStackTrace();
            }
        }

        System.out.println("Closed");

        serverSocket.close();
    }
}
