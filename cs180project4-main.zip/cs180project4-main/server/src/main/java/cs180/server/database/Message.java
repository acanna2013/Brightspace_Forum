package cs180.server.database;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Message Class - String representing post on forum or reply to post
 * Contains methods that can manipulate the message:
 *      change grade, change upvotes, add/remove comments, date created/edited, message contents
 * The Message class is tested in the CommandTest class.
 *
 * @author Ahmad Abdallah
 * @version November 13th, 2021
 *
 */
public class Message
{
    private static final DateTimeFormatter DTF =
        DateTimeFormatter.ofPattern("MM/dd/YYYY HH:mm a z");
    private UUID uuid;
    private UUID postedBy;
    private UUID forum;
    private UUID parentPost;
    private List<UUID> comments;
    private List<UUID> usersUpvoted;
    private ZonedDateTime dateCreated;
    private ZonedDateTime dateLastEdited;
    private String title;
    private String messageContents;
    private int upvotes;
    private double grade;

    /**
     * Initialize message with provided parameters. Date locally set.
     *
     * @param forum
     * @param parentPost
     * @param title
     * @param messageContents
     * @param upvotes
     * @param grade
     */
    public Message(UUID postedBy, UUID forum, UUID parentPost,
        String title, String messageContents, int upvotes,
        double grade)
    {
        this.uuid = UUID.randomUUID();
        this.postedBy = postedBy;
        this.forum = forum;
        this.parentPost = parentPost;
        this.comments = new ArrayList<UUID>();
        this.usersUpvoted = new ArrayList<UUID>();
        this.dateCreated = ZonedDateTime.now();
        this.dateLastEdited = ZonedDateTime.now();
        this.title = title;
        this.messageContents = messageContents;
        this.upvotes = upvotes;
        this.grade = grade;

    }

    /**
     * Initialize message with provided parameters. Parent post is null. Date
     * locally set.
     *
     * @param postedBy
     * @param forum
     * @param title
     * @param messageContents
     * @param upvotes
     * @param grade
     */
    public Message(UUID postedBy, UUID forum, String title,
        String messageContents, int upvotes, double grade)
    {
        this.uuid = UUID.randomUUID();
        this.postedBy = postedBy;
        this.forum = forum;
        this.parentPost = null;
        this.comments = new ArrayList<UUID>();
        this.usersUpvoted = new ArrayList<UUID>();
        this.dateCreated = ZonedDateTime.now();
        this.dateLastEdited = ZonedDateTime.now();
        this.title = title;
        this.messageContents = messageContents;
        this.upvotes = upvotes;
        this.grade = grade;

    }

    /**
     * Initialize message with provided parameters. Date locally set. Upvotes
     * and
     * grade set to 0
     *
     * @param postedBy
     * @param forum
     * @param parentPost
     * @param title
     * @param messageContents
     */
    public Message(UUID postedBy, UUID forum, UUID parentPost,
        String title, String messageContents)
    {
        this.uuid = UUID.randomUUID();
        this.postedBy = postedBy;
        this.forum = forum;
        this.parentPost = parentPost;
        this.comments = new ArrayList<UUID>();
        this.usersUpvoted = new ArrayList<UUID>();
        this.dateCreated = ZonedDateTime.now();
        this.dateLastEdited = ZonedDateTime.now();
        this.title = title;
        this.messageContents = messageContents;
        this.upvotes = 0;
        this.grade = 0;

    }

    /**
     * Initialize message with provided parameters. Parent post is null. Date
     * locally set. Upvotes and
     * grade set to 0
     *
     * @param postedBy
     * @param forum
     * @param title
     * @param messageContents
     */
    public Message(UUID postedBy, UUID forum, String title,
        String messageContents)
    {
        this.uuid = UUID.randomUUID();
        this.postedBy = postedBy;
        this.forum = forum;
        this.parentPost = null;
        this.comments = new ArrayList<UUID>();
        this.usersUpvoted = new ArrayList<UUID>();
        this.dateCreated = ZonedDateTime.now();
        this.dateLastEdited = ZonedDateTime.now();
        this.title = title;
        this.messageContents = messageContents;
        this.upvotes = 0;
        this.grade = 0;

    }

    /**
     * Instantiates message with all fields initialized to null (except comments
     * list, which is an empty arrayList)
     */
    public Message()
    {
        this.uuid = null;
        this.postedBy = null;
        this.forum = null;
        this.parentPost = null;
        this.comments = new ArrayList<UUID>();
        this.usersUpvoted = new ArrayList<UUID>();
        this.dateCreated = null;
        this.dateLastEdited = null;
        this.title = null;
        this.messageContents = null;
        this.upvotes = 0;
        this.grade = 0;

    }

    /**
     * Gets message UUID
     *
     * @return Forum UUID
     */
    public UUID getUUID()
    {
        return uuid;
    }

    /**
     * Gets UUID of user who posted the message
     *
     * @return User UUID
     */
    public UUID getPostedBy()
    {
        return postedBy;
    }

    /**
     * Gets UUID of forum message is located in
     *
     * @return Forum UUID
     */
    public UUID getForum()
    {
        return forum;
    }

    /**
     * Gets UUID of message's parent post
     *
     * @return Post UUID
     */
    public UUID getParentPost()
    {
        if (parentPost == null)
        {
            return null;
        }

        return parentPost;
    }

    /**
     * Gets UUID list of all comments on message
     *
     * @return UUID list of comments
     */
    public List<UUID> getComments()
    {
        return comments;
    }

    /**
     * Gets UUID list of all comments on message
     * 
     * @return UUID list of users who voted on this message
     */
    public List<UUID> getUsersUpvoted()
    {
        return usersUpvoted;
    }

    /**
     * Get the zoned date time
     *
     * @return the zoned date time
     */
    public ZonedDateTime getZonedDateTime()
    {
        return dateCreated;
    }

    /**
     * Gets string of date message was created
     *
     * @return Date string
     */
    public String getDateCreated()
    {
        return DTF.format(dateCreated);
    }

    /**
     * Gets string of date message was last edited
     *
     * @return Date string
     */
    public String getDateLastEdited()
    {
        return DTF.format(dateLastEdited);
    }

    /**
     * Gets title of message
     *
     * @return Title string
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * Gets message content
     *
     * @return Message content string
     */
    public String getMessageContents()
    {
        return messageContents;
    }

    /**
     * Gets upvotes given to message
     *
     * @return upvotes integer
     */
    public int getUpvotes()
    {
        return upvotes;
    }

    /**
     * Gets grade given to message
     *
     * @return Date string
     */
    public double getGrade()
    {
        return grade;
    }

    /**
     * Adds comment to comment list
     *
     * @param comment
     *            UUID for new comment
     */
    public void addComment(UUID comment)
    {
        Objects.requireNonNull(comment);

        comments.add(comment);
    }

    /**
     * Removes comment from comment list
     *
     * @param comment
     *            UUID for comment to remove
     */
    public void removeComment(UUID comment)
    {
        Objects.requireNonNull(comment);

        if (!comments.contains(comment))
        {
            return;
        } else
        {
            comments.remove(comment);
        }
    }

    /**
     * Adds user to list of users who upvoted the message
     * 
     * @param user
     *            UUID for user who upvoted post
     */
    public void addUserUpvoted(UUID user)
    {
        Objects.requireNonNull(user);

        usersUpvoted.add(user);
    }

    /**
     * Removes a user who upvoted on a post
     * 
     * @param user
     *            UUID for user who upvoted post
     */
    public void removeUserUpvoted(UUID user)
    {
        Objects.requireNonNull(user);

        if (!usersUpvoted.contains(user))
        {
            return;
        } else
        {
            usersUpvoted.remove(user);
        }
    }

    /**
     * Sets date last edited to current local time
     *
     */
    public void updateDateLastEdited()
    {
        dateLastEdited = ZonedDateTime.now();
    }

    /**
     * Sets title to provided title
     *
     * @param title
     *            String for new message title
     */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /**
     * Sets message contents to provided text
     *
     * @param messageContents
     *            String for new message content
     */
    public void setMessageContents(String messageContents)
    {
        this.messageContents = messageContents;
    }

    /**
     * Sets upvotes to provided upvote int
     *
     * @param upvotes
     *            int value for new upvotes
     *
     */
    public void setUpvote(int upvotesParam)
    {
        this.upvotes = upvotesParam;
    }

    /**
     * Sets grade to provided grade
     *
     * @param grade
     *            Double value for new grade
     */
    public void setGrade(double grade)
    {
        this.grade = grade;
    }

    /**
     * Saves message object in Database/Message directory. File name is
     * [object-uuid].txt
     */
    public void save()
    {
        if (uuid == null)
        {
            System.out
                .println("Message UUID not instantiated, cannot save");
            return;
        }
        // Location of file to save to
        String fileName =
            String.format("Database/Message/%s.txt",
                          uuid.toString());
        File f = new File(fileName);

        try
        {
            FileWriter fw = new FileWriter(f);
            BufferedWriter bfw = new BufferedWriter(fw);

            // Writes toString string representing message
            bfw.write(toString());

            bfw.close();
            fw.close();

        } catch (NullPointerException npe)
        {
            System.out
                .println("Cannot save null values, please initilize fields");
            npe.printStackTrace();
        } catch (FileNotFoundException fnf)
        {
            System.out.println("Message file not found!");
        } catch (IOException ioe)
        {
            System.out.println("Failed to save message");
            ioe.printStackTrace();
        }

    }

    /**
     * Loads message object from Database/Message directory.
     *
     * @param uuid
     *            UUID for requested message
     */
    public void load(UUID messageUUID)
    {
        // Location of file to load from
        String fileName =
            String.format("Database/Message/%s.txt",
                          messageUUID.toString());

        String forumString = "";
        String parentPostString = "";
        String commentsString = "";
        String usersUpvotedString = "";
        String[] commentsArray = new String[1];
        String[] usersUpvotedArray = new String[1];
        File f = new File(fileName);

        try
        {
            // Initialize readers
            FileReader fr = new FileReader(f);
            BufferedReader bfr = new BufferedReader(fr);

            // Load message uuid
            this.uuid = UUID.fromString(bfr.readLine());

            // Load message postedBy
            this.postedBy = UUID.fromString(bfr.readLine());

            // Load message forum
            forumString = bfr.readLine();

            if (forumString.equals("none"))
            {
                this.forum = null;
            } else
            {
                this.forum = UUID.fromString(forumString);
            }

            // Load message's parent post
            parentPostString = bfr.readLine();

            if (parentPostString.equals("none"))
            {
                this.parentPost = null;
            } else
            {
                this.parentPost =
                    UUID.fromString(parentPostString);
            }

            commentsString = bfr.readLine();

            // Check if message has no comments
            if (!commentsString.equals("none"))
            {
                // Make sure forum has multiple messages
                if (commentsString.contains(","))
                {
                    commentsArray = commentsString.split(",");

                    // Add message UUIDs from string to messages arraylist
                    for (int i = 0; i < commentsArray.length;
                         i++)
                    {
                        comments.add(UUID
                            .fromString(commentsArray[i]));
                    }
                } else // Case where only one comment for a message
                {
                    comments
                        .add(UUID.fromString(commentsString));
                }
            }

            usersUpvotedString = bfr.readLine();

            // Check make sure at least one user has upvoted this message
            if (!usersUpvotedString.equals("none"))
            {
                // Make sure multiple users have upvoted this message
                if (usersUpvotedString.contains(","))
                {
                    usersUpvotedArray =
                        usersUpvotedString.split(",");

                    // Add user UUIDs to list of users voted
                    for (int i = 0;
                         i < usersUpvotedArray.length; i++)
                    {
                        usersUpvoted.add(UUID
                            .fromString(usersUpvotedArray[i]));
                    }
                } else // Case where only one user voted for a message
                {
                    usersUpvoted.add(UUID
                        .fromString(usersUpvotedString));
                }
            }

            // Load message's date created
            this.dateCreated =
                ZonedDateTime.parse(bfr.readLine());

            // Load message's date last edited
            this.dateLastEdited =
                ZonedDateTime.parse(bfr.readLine());

            // Load message title
            this.title = bfr.readLine();

            // Load message contents
            this.messageContents = bfr.readLine();

            // Load message upvote count
            this.upvotes = Integer.parseInt(bfr.readLine());

            // Load message's grade
            this.grade = Double.parseDouble(bfr.readLine());

        } catch (IllegalArgumentException iae)
        {
            System.out.println("Illegal argument!");
            iae.printStackTrace();
        } catch (FileNotFoundException fnf)
        {
            System.out.println("Message file not found");
        } catch (IOException ioe)
        {
            System.out.println("Failed to load message");
            ioe.printStackTrace();
        }
    }

    /**
     *
     * Provides string representation of message object
     *
     * @return String containing all fields of message object
     *
     */
    @Override
    public String toString()
    {
        String forumString = "";
        String parentPostString = "";
        String commentsString = "";
        String usersUpvotedString = "";

        // Ensure message has valid forum
        if (forum == null)
        {
            forumString = "none";
        } else
        {
            forumString = forum.toString();
        }

        // Ensure message has parent post
        if (parentPost == null)
        {
            parentPostString = "none";
        } else
        {
            parentPostString = parentPost.toString();
        }

        // Ensure message has comments
        if (comments.size() != 0)
        {
            for (int i = 0; i < comments.size(); i++)
            {
                if (i != 0)
                {
                    commentsString += ",";
                }
                commentsString += comments.get(i).toString();
            }

        } else
        {
            commentsString = "none";
        }

        // Ensure a user has upvoted the post
        if (usersUpvoted.size() != 0)
        {
            for (int i = 0; i < usersUpvoted.size(); i++)
            {
                if (i != 0)
                {
                    usersUpvotedString += ",";
                }
                usersUpvotedString +=
                    usersUpvoted.get(i).toString();
            }

        } else
        {
            usersUpvotedString = "none";
        }

        String messageString =
            String
                .format("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%d\n%.2f",
                        uuid.toString(), postedBy.toString(),
                        forumString, parentPostString,
                        commentsString, usersUpvotedString,
                        dateCreated.toString(),
                        dateLastEdited.toString(), title,
                        messageContents, upvotes, grade);

        return messageString;
    }

}
