package cs180.server.database;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Database of persistent objects (courses, forums, messages, users)
 * Contains methods to manipulate the courses, forums, messages, and users hashmap.
 * The Database class is tested in the ControllerTest class.
 *
 * @author Ahmad Abdallah, Rachel La
 * @version November 10, 2021
 *
 */
public class Database
{
    // Paths for respective class files
    private static final Path DATABASE_PATH =
        Paths.get("Database/");
    private static final Path COURSE_PATH =
        Paths.get("Database/Course/");
    private static final Path FORUM_PATH =
        Paths.get("Database/Forum/");
    private static final Path MESSAGE_PATH =
        Paths.get("Database/Message/");
    private static final Path USER_PATH =
        Paths.get("Database/User/");

    private Map<UUID, Course> courses;
    private Map<UUID, Forum> forums;
    private Map<UUID, Message> messages;
    private Map<UUID, User> users;

    /**
     * Initialize database items with given parameters
     *
     * @param courses
     *            Map of UUID keys and Course values
     * @param forums
     *            Map of UUID keys and Forum values
     * @param messages
     *            Map of UUID keys and Message values
     * @param users
     *            Map of UUID keys and User values
     *
     */
    public Database(Map<UUID, Course> courses,
                    Map<UUID, Forum> forums, Map<UUID, Message> messages,
                    Map<UUID, User> users)
    {
        this.courses = courses;
        this.forums = forums;
        this.messages = messages;
        this.users = users;
    }

    /**
     * Initialize database items to empty lists
     *
     */
    public Database()
    {
        this.courses = new HashMap<UUID, Course>();
        this.forums = new HashMap<UUID, Forum>();
        this.messages = new HashMap<UUID, Message>();
        this.users = new HashMap<UUID, User>();
    }

    /**
     * Gets UUID list of all courses in database
     *
     * @return list of all courses
     */
    public Map<UUID, Course> getCourses()
    {
        return courses;
    }

    /**
     * Gets UUID list of all forums in database
     *
     * @return list of all forums
     */
    public Map<UUID, Forum> getForums()
    {
        return forums;
    }

    /**
     * Gets UUID list of all messages in database
     *
     * @return list of all messages
     */
    public Map<UUID, Message> getMessages()
    {
        return messages;
    }

    /**
     * Gets UUID list of all users in database
     *
     * @return list of all users
     */
    public Map<UUID, User> getUsers()
    {
        return users;
    }

    /**
     * Adds course to courses database
     *
     * @param course
     *            UUID for new course
     */
    public void addCourse(Course course)
    {
        this.courses.put(course.getUUID(), course);
    }

    /**
     * Adds forum to forums database
     *
     * @param forum
     *            UUID for new forum
     */
    public void addForum(Forum forum)
    {
        this.forums.put(forum.getUUID(), forum);
    }

    /**
     * Adds message to messages database
     *
     * @param message
     *            UUID for new message
     */
    public void addMessage(Message message)
    {
        this.messages.put(message.getUUID(), message);
    }

    /**
     * Adds user to users database
     *
     * @param user
     *            UUID for new user
     */
    public void addUser(User user)
    {
        this.users.put(user.getUUID(), user);
    }

    /**
     * Removes course from courses database
     *
     * @param course
     *            UUID for course to remove
     */
    public void removeCourse(UUID course)
    {
        this.courses.remove(course);
    }

    /**
     * Removes forum from forums database
     *
     * @param forum
     *            UUID for forum to remove
     */
    public void removeForum(UUID forum)
    {
        this.forums.remove(forum);
    }

    /**
     * Removes message from messages database
     *
     * @param message
     *            UUID for message to remove
     */
    public void removeMessage(UUID message)
    {
        this.messages.remove(message);
    }

    /**
     * Removes user from users database
     *
     * @param user
     *            UUID for user to remove
     */
    public void removeUser(UUID user)
    {
        this.users.remove(user);
    }

    /**
     * Return course from provided uuid
     *
     * @param uuid
     */
    public Course getCourse(UUID uuid)
    {
        return this.courses.get(uuid);
    }

    /**
     * Return forum from provided uuid
     *
     * @param uuid
     */
    public Forum getForum(UUID uuid)
    {
        return this.forums.get(uuid);
    }

    /**
     * Return message from provided uuid
     *
     * @param uuid
     */
    public Message getMessage(UUID uuid)
    {
        return this.messages.get(uuid);
    }

    /**
     * Return user from provided uuid
     *
     * @param uuid
     */
    public User getUser(UUID uuid)
    {
        return this.users.get(uuid);
    }

    /**
     * Checks if all directories exist, initializing them if they do not. Loads
     * in all User, Course, Forum, and Message objects from within database
     *
     */
    public void loadDatabase()
    {
        directoryCheck();

        forums = loadForums();

        messages = loadMessages();

        courses = loadCourses();

        users = loadUsers();

    }

    /**
     * Loads in all forums from forum folder. DOES NOT check if database or
     * forum folder exists beforehand
     *
     * @return A hashmap of UUID keys and Forum values
     *
     */
    private Map<UUID, Forum> loadForums()
    {
        File[] forumFiles =
            new File(FORUM_PATH.toString()).listFiles();

        HashMap<UUID, Forum> temp =
            new HashMap<UUID, Forum>();

        for (int i = 0; i < forumFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = forumFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            // Instantiating forum
            Forum f = new Forum();
            f.load(UUID.fromString(uuid));

            // Forum added to temp
            temp.put(f.getUUID(), f);
        }

        return temp;
    }

    /**
     * Loads in all messages from message folder. DOES NOT check if database or
     * message folder exists beforehand
     *
     * @return A hashmap of UUID keys and Message values
     *
     */
    private Map<UUID, Message> loadMessages()
    {
        File[] messageFiles =
            new File(MESSAGE_PATH.toString()).listFiles();

        HashMap<UUID, Message> temp =
            new HashMap<UUID, Message>();

        for (int i = 0; i < messageFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = messageFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            // Instantiating message
            Message m = new Message();
            m.load(UUID.fromString(uuid));

            // Message added to temp
            temp.put(m.getUUID(), m);
        }

        return temp;
    }

    /**
     * Loads in all courses from course folder. DOES NOT check if database or
     * course folder exists beforehand
     *
     * @return A hashmap of UUID keys and Course values
     *
     */
    private Map<UUID, Course> loadCourses()
    {
        File[] courseFiles =
            new File(COURSE_PATH.toString()).listFiles();

        HashMap<UUID, Course> temp =
            new HashMap<UUID, Course>();

        for (int i = 0; i < courseFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = courseFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            // Instantiating course
            Course c = new Course();
            c.loadCourse(UUID.fromString(uuid));

            // Course added to temp
            temp.put(c.getUUID(), c);
        }

        return temp;
    }

    /**
     * Loads in all users from course folder. DOES NOT check if database or
     * user folder exists beforehand
     *
     * @return A hashmap of UUID keys and User values
     *
     */
    private Map<UUID, User> loadUsers()
    {
        File[] userFiles =
            new File(USER_PATH.toString()).listFiles();

        HashMap<UUID, User> temp = new HashMap<UUID, User>();

        for (int i = 0; i < userFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = userFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            // Instantiating user
            User u = new User();
            u.loadUser(UUID.fromString(uuid));

            // User added to temp
            temp.put(u.getUUID(), u);
        }

        return temp;
    }

    /**
     * Checks if all directories exist, initializing them if they do not. Saves
     * all Course, Forum, Message, and User objects in respective folders within
     * database
     *
     */
    public void saveDatabase()
    {
        directoryCheck();

        saveForums(forums);

        saveMessages(messages);

        saveCourses(courses);

        saveUsers(users);
    }

    /**
     * Saves all forums in forumMap to forums folder. DOES NOT check if database
     * or
     * forum folder exists beforehand
     *
     * @param forumMap
     *            the forums hashmap
     */
    private void saveForums(Map<UUID, Forum> forumMap)
    {
        File[] forumFiles =
            new File(FORUM_PATH.toString()).listFiles();

        for (Forum curForum : forumMap.values())
        {
            curForum.save();

        }

        for (int i = 0; i < forumFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = forumFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            if (!forumMap.containsKey(UUID.fromString(uuid)))
            {
                try
                {
                    Files.delete(Paths.get(filePath));
                } catch (NoSuchFileException nsf)
                {
                    System.out
                        .println("Forum File not found, cannot remove");
                } catch (IOException ioe)
                {
                    System.out.println("Error saving");
                    ioe.printStackTrace();
                }
            }
        }
    }

    /**
     * Saves all messages in messageMap to message folder. DOES NOT check if
     * database or
     * message folder exists beforehand
     *
     * @param messageMap
     *            the messages hashmap
     */
    private void saveMessages(Map<UUID, Message> messageMap)
    {
        File[] messageFiles =
            new File(MESSAGE_PATH.toString()).listFiles();

        for (Message curMessage : messageMap.values())
        {
            curMessage.save();
        }

        for (int i = 0; i < messageFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = messageFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            if (!messageMap
                .containsKey(UUID.fromString(uuid)))
            {
                try
                {
                    Files.delete(Paths.get(filePath));
                } catch (NoSuchFileException nsf)
                {
                    System.out
                        .println("Message File not found, cannot remove");
                } catch (IOException ioe)
                {
                    System.out.println("Error saving");
                    ioe.printStackTrace();
                }
            }
        }
    }

    /**
     * Saves all courses in courseMap to course folder. DOES NOT check if
     * database or
     * course folder exists beforehand
     *
     * @param courseMap
     *            the courses hashmap
     */
    private void saveCourses(Map<UUID, Course> courseMap)
    {
        File[] courseFiles =
            new File(COURSE_PATH.toString()).listFiles();

        for (Course curCourse : courseMap.values())
        {
            curCourse.saveCourse();
        }

        for (int i = 0; i < courseFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = courseFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            if (!courseMap.containsKey(UUID.fromString(uuid)))
            {
                try
                {
                    Files.delete(Paths.get(filePath));
                } catch (NoSuchFileException nsf)
                {
                    System.out
                        .println("Course File not found, cannot remove");
                } catch (IOException ioe)
                {
                    System.out.println("Error saving");
                    ioe.printStackTrace();
                }
            }
        }
    }

    /**
     * Saves all users in userMap to user folder. DOES NOT check if database or
     * user folder exists beforehand
     *
     * @param userMap
     *            the users hashmap
     */
    private void saveUsers(Map<UUID, User> userMap)
    {
        File[] userFiles =
            new File(USER_PATH.toString()).listFiles();

        for (User curUser : userMap.values())
        {
            curUser.saveUser();
        }

        for (int i = 0; i < userFiles.length; i++)
        {
            // Getting UUID from file name
            String filePath = userFiles[i].toString();
            String uuid =
                filePath
                    .substring(filePath.lastIndexOf('/') + 1,
                        filePath.length() - 4);

            if (!userMap.containsKey(UUID.fromString(uuid)))
            {
                try
                {
                    Files.delete(Paths.get(filePath));
                } catch (NoSuchFileException nsf)
                {
                    System.out
                        .println("User File not found, cannot remove");
                } catch (IOException ioe)
                {
                    System.out.println("Error saving");
                    ioe.printStackTrace();
                }
            }
        }
    }

    /**
     * Checks if database folder and respective class folders exist. If they
     * don't exist, they are created
     *
     */
    private void directoryCheck()
    {
        // Checking if database exists
        if (!Files.exists(DATABASE_PATH))
        {
            new File(DATABASE_PATH.toString()).mkdir();
        }

        // Checking if course folder exists
        if (!Files.exists(COURSE_PATH))
        {
            new File(COURSE_PATH.toString()).mkdir();
        }

        // Checking if forum folder exists
        if (!Files.exists(FORUM_PATH))
        {
            new File(FORUM_PATH.toString()).mkdir();
        }

        // Checking if message folder exists
        if (!Files.exists(MESSAGE_PATH))
        {
            new File(MESSAGE_PATH.toString()).mkdir();
        }

        // Checking if user folder exists
        if (!Files.exists(USER_PATH))
        {
            new File(USER_PATH.toString()).mkdir();
        }
    }
}
