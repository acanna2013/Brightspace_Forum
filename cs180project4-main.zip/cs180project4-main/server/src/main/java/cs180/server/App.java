package cs180.server;

import cs180.server.database.*;
import java.io.*;
import org.apache.commons.cli.*;

/**
 * Main Application Class
 * Starts the command interface.
 * Loads and saves database by the using the load and save methods in the Database class.
 *
 * @author Zachary Mayhew
 * @version November 2, 2021
 */
public class App {
    public static void main(String[] args) throws IOException {
        var options = new Options();

        var portOpt = new Option("p", "port", true, "Port to host server on (default: 1234)");
        portOpt.setArgName("port");
        options.addOption(portOpt);

        var parser = new DefaultParser();
        var help = new HelpFormatter();

        try {
            var cmd = parser.parse(options, args);

            var db = new Database();
            db.loadDatabase();
            var app = new Controller(db);
            var portStr = cmd.getOptionValue(portOpt, "1234");
            var server = new ServerController(app, Integer.parseInt(portStr));
            server.start();
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            help.printHelp("cs180 server", options);
        } catch (NumberFormatException e) {
            System.out.println("Expected number");
            help.printHelp("start-server [options]", options);
        }
    }
}
