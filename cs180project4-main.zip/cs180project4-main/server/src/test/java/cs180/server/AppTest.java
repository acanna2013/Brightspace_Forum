package cs180.server;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test the App class
 * Ensures the App class works.
 *
 * @author Zachary Mayhew
 * @version November 2, 2021
 */
public class AppTest {
    @Test
    public void test() {
        assertTrue(true);
    }
}
