package cs180.server;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import org.junit.BeforeClass;
import org.junit.Test;

import cs180.server.database.Course;
import cs180.server.database.Database;
import cs180.server.database.Forum;
import cs180.server.database.Message;
import cs180.server.database.User;

/**
 * DatabaseTest - Test cases for Database class and User, Course, Forum, and
 * Message classes
 * 
 * @author Ahmad Abdallah
 * @version November 13th, 2021
 */

public class DatabaseTest
{
    private static final Path DATABASE_PATH =
        Paths.get("Database/");
    private static final Path COURSE_PATH =
        Paths.get("Database/Course/");
    private static final Path FORUM_PATH =
        Paths.get("Database/Forum/");
    private static final Path MESSAGE_PATH =
        Paths.get("Database/Message/");
    private static final Path USER_PATH =
        Paths.get("Database/User/");

    static Database db;
    static User testUser;
    static Course testCourse;
    static Forum testForum;
    static Message testMessage;

    static User loadUser;
    static Course loadCourse;
    static Forum loadForum;
    static Message loadMessage;

    static UUID postedBy;
    static UUID userUpvoteID;
    static UUID commentID;

    static File databaseFile;
    static File forumFile;

    @BeforeClass
    public static void testSetup() throws Exception
    {
        postedBy = UUID.randomUUID();

        testUser =
            new User("teacher", "user", "name", "pass");
        testCourse =
            new Course(testUser.getUUID(), "course title");
        testForum =
            new Forum(testCourse.getUUID(), "forum topic");
        testMessage =
            new Message(postedBy, testForum.getUUID(),
                        "message title", "message contents");

        db = new Database();
        loadUser = new User();
        loadCourse = new Course();
        loadForum = new Forum();
        loadMessage = new Message();

        commentID = UUID.randomUUID();
        userUpvoteID = UUID.randomUUID();

        new File(DATABASE_PATH.toString()).mkdir();
        new File(COURSE_PATH.toString()).mkdir();
        new File(FORUM_PATH.toString()).mkdir();
        new File(MESSAGE_PATH.toString()).mkdir();
        new File(USER_PATH.toString()).mkdir();

    }

    @Test
    public void testGetters()
    {
        assertEquals(testCourse.getTeacher(),
                     testUser.getUUID());
        assertEquals(testForum.getCourse(),
                     testCourse.getUUID());
        assertEquals(testMessage.getForum(),
                     testForum.getUUID());
    }

    @Test
    public void testSetters()
    {
        testUser.setFullName("mark");
        assertEquals(testUser.getFullName(), "mark");
        testUser.setUsername("new user");
        assertEquals(testUser.getUsername(), "new user");
        testUser.setPassword("new pass");
        assertEquals(testUser.getPassword(), "new pass");

        testCourse.setTitle("new title");
        assertEquals(testCourse.getTitle(), "new title");

        testForum.setForumTopic("new topic");
        assertEquals(testForum.getForumTopic(), "new topic");

        testMessage.setTitle("new title");
        assertEquals(testMessage.getTitle(), "new title");
        testMessage.setMessageContents("new content");
        assertEquals(testMessage.getMessageContents(),
                     "new content");
        testMessage.setGrade(10);
        assertEquals((int) testMessage.getGrade(), 10);
        testMessage.setUpvote(12);
        assertEquals(testMessage.getUpvotes(), 12);
    }

    @Test
    public void testLists()
    {
        testUser.addCourse(testCourse.getUUID());
        assertEquals(testUser.getCourses().get(0),
                     testCourse.getUUID());
        testUser.removeCourse(testCourse.getUUID());
        assertEquals(testUser.getCourses().size(), 0);

        testCourse.addForum(testForum.getUUID());
        assertEquals(testCourse.getForum().get(0),
                     testForum.getUUID());
        testCourse.removeForum(testForum.getUUID());
        assertEquals(testCourse.getForum().size(), 0);

        testForum.addMessage(testMessage.getUUID());
        assertEquals(testForum.getMessages().get(0),
                     testMessage.getUUID());
        testForum.removeMessage(testMessage.getUUID());
        assertEquals(testForum.getMessages().size(), 0);

        testMessage.addComment(commentID);
        assertEquals(testMessage.getComments().get(0),
                     commentID);
        testMessage.removeComment(commentID);
        assertEquals(testMessage.getComments().size(), 0);
        testMessage.addUserUpvoted(userUpvoteID);
        assertEquals(testMessage.getUsersUpvoted().get(0),
                     userUpvoteID);
        testMessage.removeUserUpvoted(userUpvoteID);
        assertEquals(testMessage.getUsersUpvoted().size(), 0);

    }

    @Test
    public void mapGettingSetting()
    {
        db.addUser(testUser);
        assertEquals(db.getUser(testUser.getUUID())
            .toString(), testUser.toString());
        db.removeUser(testUser.getUUID());
        assertEquals(db.getUsers().size(), 0);

        db.addCourse(testCourse);
        assertEquals(db.getCourse(testCourse.getUUID())
            .toString(), testCourse.toString());
        db.removeCourse(testCourse.getUUID());
        assertEquals(db.getCourses().size(), 0);

        db.addForum(testForum);
        assertEquals(db.getForum(testForum.getUUID())
            .toString(), testForum.toString());
        db.removeForum(testForum.getUUID());
        assertEquals(db.getForums().size(), 0);

        db.addMessage(testMessage);
        assertEquals(db.getMessage(testMessage.getUUID())
            .toString(), testMessage.toString());
        db.removeMessage(testMessage.getUUID());
        assertEquals(db.getMessages().size(), 0);
    }

    @Test
    public void testDatabaseSaving()
    {
        db.addUser(testUser);
        db.addCourse(testCourse);
        db.addForum(testForum);
        db.addMessage(testMessage);

        db.saveDatabase();
        File[] userFiles =
            new File(USER_PATH.toString()).listFiles();
        File[] courseFiles =
            new File(COURSE_PATH.toString()).listFiles();
        File[] forumFiles =
            new File(FORUM_PATH.toString()).listFiles();
        File[] messageFiles =
            new File(MESSAGE_PATH.toString()).listFiles();

        for (File f : userFiles)
        {
            String fileID = f.getPath();
            fileID =
                fileID.substring(fileID.lastIndexOf('/') + 1,
                                 fileID.length() - 4);
            assertTrue(db.getUsers()
                .containsKey(UUID.fromString(fileID)));
        }

        for (File f : courseFiles)
        {
            String fileID = f.getPath();
            fileID =
                fileID.substring(fileID.lastIndexOf('/') + 1,
                                 fileID.length() - 4);
            assertTrue(db.getCourses()
                .containsKey(UUID.fromString(fileID)));
        }

        for (File f : forumFiles)
        {
            String fileID = f.getPath();
            fileID =
                fileID.substring(fileID.lastIndexOf('/') + 1,
                                 fileID.length() - 4);
            assertTrue(db.getForums()
                .containsKey(UUID.fromString(fileID)));
        }

        for (File f : messageFiles)
        {
            String fileID = f.getPath();
            fileID =
                fileID.substring(fileID.lastIndexOf('/') + 1,
                                 fileID.length() - 4);
            assertTrue(db.getMessages()
                .containsKey(UUID.fromString(fileID)));
        }
    }

    @Test
    public void testDatabaseLoading()
    {
        db.removeUser(testUser.getUUID());
        db.removeCourse(testCourse.getUUID());
        db.removeForum(testForum.getUUID());
        db.removeMessage(testMessage.getUUID());

        db.loadDatabase();

        assertEquals(db.getUser(testUser.getUUID())
            .toString(), testUser.toString());
        assertEquals(db.getCourse(testCourse.getUUID())
            .toString(), testCourse.toString());
        assertEquals(db.getForum(testForum.getUUID())
            .toString(), testForum.toString());
        assertEquals(db.getMessage(testMessage.getUUID())
            .toString(), testMessage.toString());
    }

    @Test
    public void testUserSavingLoading() throws Exception
    {
        testUser.saveUser();
        BufferedReader userReader =
            new BufferedReader(new FileReader(new File(String
                .format("%s/%s.txt", USER_PATH,
                        testUser.getUUID().toString()))));

        String savedUser = "";
        String currentLine = userReader.readLine();
        while (currentLine != null)
        {
            savedUser += currentLine + "\n";
            currentLine = userReader.readLine();
        }
        savedUser =
            savedUser.substring(0,
                                savedUser.lastIndexOf("\n"));

        assertEquals(testUser.toString(), savedUser);

        loadUser.loadUser(testUser.getUUID());
        assertEquals(testUser.toString(),
                     loadUser.toString());

    }

    @Test
    public void testCourseSavingLoading() throws Exception
    {
        testCourse.saveCourse();
        BufferedReader courseReader =
            new BufferedReader(new FileReader(new File(String
                .format("%s/%s.txt", COURSE_PATH,
                        testCourse.getUUID().toString()))));
        String savedCourse = "";
        String currentLine = courseReader.readLine();
        while (currentLine != null)
        {
            savedCourse += currentLine + "\n";
            currentLine = courseReader.readLine();
        }
        savedCourse =
            savedCourse
                .substring(0, savedCourse.lastIndexOf("\n"));

        assertEquals(savedCourse, testCourse.toString());

        loadCourse.loadCourse(testCourse.getUUID());
        assertEquals(testCourse.toString(),
                     loadCourse.toString());
    }

    @Test
    public void testForumSavingLoading() throws Exception
    {
        testForum.save();
        BufferedReader forumReader =
            new BufferedReader(new FileReader(new File(String
                .format("%s/%s.txt", FORUM_PATH,
                        testForum.getUUID().toString()))));
        String savedForum = "";
        String currentLine = forumReader.readLine();
        while (currentLine != null)
        {
            savedForum += currentLine + "\n";
            currentLine = forumReader.readLine();
        }

        savedForum =
            savedForum
                .substring(0, savedForum.lastIndexOf("\n"));

        assertEquals(savedForum, testForum.toString());

        loadForum.load(testForum.getUUID());
        assertEquals(testForum.toString(),
                     loadForum.toString());
    }

    @Test
    public void testMessageSavingLoading() throws Exception
    {
        testMessage.save();
        BufferedReader messageReader =
            new BufferedReader(new FileReader(new File(String
                .format("%s/%s.txt", MESSAGE_PATH,
                        testMessage.getUUID().toString()))));
        String savedMessage = "";
        String currentLine = messageReader.readLine();
        while (currentLine != null)
        {
            savedMessage += currentLine + "\n";
            currentLine = messageReader.readLine();
        }

        savedMessage =
            savedMessage
                .substring(0, savedMessage.lastIndexOf("\n"));

        assertEquals(savedMessage, testMessage.toString());

        loadMessage.load(testMessage.getUUID());
        assertEquals(testMessage.toString(),
                     loadMessage.toString());
    }

}
