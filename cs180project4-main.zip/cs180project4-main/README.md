# Project 5
- [Project 5](#project-5)
  - [Notes to grader](#notes-to-grader)
  - [Running](#running)
    - [Client](#client)
    - [Server](#server)
  - [Directory Structure](#directory-structure)
  - [Database Utility](#database-utility)
    - [Resetting the database](#resetting-the-database)
    - [Using an existing database](#using-an-existing-database)
    - [Delete all backups](#delete-all-backups)
  - [Documentation](#documentation)

## Notes to grader

Report and Code both submitted by Zachary Mayhew <zmayhew@purdue.edu>

> For project 4 we encountered some issues involving Voccarium damaging our
> directory structure such that our program no longer ran properly.  If this
> happens, please contact us.

> Some exceptions may be printed out in the server log output.  This is
> for debugging purposes and many of these exceptions are expected behavior.

> The server runs on port 1234 by default.  If this is an issue, see the
> [Server](#server) section

> The code is best tested on MacOS or Linux

> If you encounter an issue that corrupts the database and causes the program to
> stop working, stop the server and reset the database using the
> [database utility](#database-utility).

## Running

### Client

To run the client, run this command:

```
./gradlew client:run
```

### Server

To run the server, run this command:

```
./gradlew server:run
```

To run the server with a specific port:

```
./gradlew server:run --args="-p <port>"
```

## Directory Structure

* `/client` Client side code
* `/server` Server side code
* `/serialize` Custom serialization library

## Database Utility

The database utility (`./db`) can be used to fix errors or reuse database
instances for testing purposes.


The database utility will always create backups with the format
`Database.year.month.day.hour.minute.second.bak`

### Resetting the database

You can reset the database (deleting all data) by running the following command:

```
./db deleteall
```

### Using an existing database

You can use a particular database instance by running:

```
./db use [database_name]
```

For the default example database:

```
./db use example_db
```

### Delete all backups

To delete all backups:

```
./db removebackups
```

## Documentation

All documentation for classes are in Javadocs.
