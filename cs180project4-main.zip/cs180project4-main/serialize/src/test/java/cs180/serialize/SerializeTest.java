package cs180.serialize;

import static org.junit.Assert.*;

import java.io.*;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.Random;
import org.junit.Test;

/**
 * Test serialization stuff
 *
 * @author Zachary Mayhew
 * @version December 10, 2021
 */
public class SerializeTest {
    /**
     * Test class
     */
    private static class TestClass {
        private static final int STATIC_FIELD = 12345;
        private UUID uuid;
        private UUID postedBy;
        private UUID forum;
        private UUID parentPost;
        private List<UUID> comments;
        private transient String password;
        private List<UUID> usersUpvoted;
        private ZonedDateTime dateCreated;
        private ZonedDateTime dateLastEdited;
        private String title;
        private String messageContents;
        private int upvotes;
        private double grade;

        public TestClass(UUID uuid, UUID postedBy, UUID forum, UUID parentPost, String password, List<UUID> comments,
            List<UUID> usersUpvoted, ZonedDateTime dateCreated, ZonedDateTime dateLastEdited, String title,
            String messageContents, int upvotes, double grade) {
            this.uuid = uuid;
            this.postedBy = postedBy;
            this.forum = forum;
            this.parentPost = parentPost;
            this.comments = comments;
            this.password = password;
            this.usersUpvoted = usersUpvoted;
            this.dateCreated = dateCreated;
            this.dateLastEdited = dateLastEdited;
            this.title = title;
            this.messageContents = messageContents;
            this.upvotes = upvotes;
            this.grade = grade;
        }

        public static TestClass makeRandom() {
            var ids = new ArrayList<UUID>();
            for (int i = 0; i < 3; i++)
                ids.add(UUID.randomUUID());
            var rand = new Random();
            return new TestClass(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(),
                "password123", ids, ids, ZonedDateTime.now(), ZonedDateTime.now(), "Hello, \nW\tO\\rld!",
                "This is some text", rand.nextInt(), rand.nextDouble());
        }

        public TestClass() {
        }

        @Override
        public int hashCode() {
            return Objects.hash(uuid, postedBy, forum, parentPost, comments, usersUpvoted, dateCreated, dateLastEdited,
                title, messageContents, upvotes, grade);
        }
    }

    @Test
    public void testStringEscape() {
        var a = "\\\\n\n\\\text";
        assertEquals(Serialize.escapeString("\\\\n\n\\\text"), "\\\\\\\\n\\n\\\\\\text");
        assertEquals(a, Serialize.unescapeString(Serialize.escapeString(a)));
        assertEquals(Serialize.escapeString("\n"), "\\n");
        assertEquals(Serialize.escapeString("\t"), "\\t");
        assertEquals(Serialize.escapeString("\\"), "\\\\");
        assertEquals(Serialize.escapeString("\\\n"), "\\\\\\n");
        assertEquals(Serialize.escapeString("\\\t"), "\\\\\\t");
        assertEquals(Serialize.escapeString("\\\\"), "\\\\\\\\");
        assertEquals(Serialize.unescapeString("\\n"), "\n");
        assertEquals(Serialize.unescapeString("\\t"), "\t");
        assertEquals(Serialize.unescapeString("\\\\"), "\\");
        assertEquals(Serialize.unescapeString("\\\\\\n"), "\\\n");
        assertEquals(Serialize.unescapeString("\\\\\\t"), "\\\t");
        assertEquals(Serialize.unescapeString("\\\\\\\\"), "\\\\");
    }

    @Test
    public void testSerialize() throws Serialize.ParseException, UnsupportedEncodingException {
        var actual = new ArrayList<TestClass>();

        for (int j = 0; j < 50; j++) {
            actual.add(TestClass.makeRandom());
        }

        var pout = new ByteArrayOutputStream();
        Serialize.serializeList(new PrintStream(pout), actual);
        var in = new ByteArrayInputStream(pout.toByteArray());

        var result = Serialize.deserializeList(new Scanner(in), TestClass.class);
        assertEquals(actual.size(), result.size());
        for (int i = 0; i < result.size(); i++) {
            assertEquals(actual.get(i).hashCode(), result.get(i).hashCode());
        }
    }
}
