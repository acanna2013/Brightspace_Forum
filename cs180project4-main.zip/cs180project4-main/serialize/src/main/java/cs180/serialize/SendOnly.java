package cs180.serialize;

/**
 * An interface denoting data that will only be serialized, not deserialized.
 *
 * @author Zachary Mayhew
 * @version December 10, 2021
 */
public @interface SendOnly {
}
