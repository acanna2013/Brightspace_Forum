package cs180.serialize;

import java.io.PrintStream;
import java.lang.reflect.*;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * The Serialize class handles serialization and deserialization of data over
 * input and output streams.
 *
 * @author Zachary Mayhew
 * @version December 10, 2021
 */
public class Serialize {
    public static String escapeString(String in) {
        return in.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t");
    }

    public static String unescapeString(String in) {
        String out = "";
        for (int i = 0; i < in.length(); i++) {
            if (in.charAt(i) == '\\') {
                i++;
                if (i >= in.length())
                    break;
                if (in.charAt(i) == 'n')
                    out += "\n";
                else if (in.charAt(i) == 't')
                    out += "\t";
                else if (in.charAt(i) == '\\')
                    out += "\\";
                else
                    out += in.charAt(i);
            } else {
                out += in.charAt(i);
            }
        }
        return out;
    }

    /**
     * Exception when parsing serialized text
     */
    public static class ParseException extends Exception {
        public ParseException(String message) {
            super(message);
        }

        public ParseException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    public static <T> void serializeList(PrintStream out, Collection<T> objs) {
        var magic = UUID.randomUUID().toString();
        out.printf("ENUMERATE\t%d\t%s\n", objs.size(), magic);
        for (var obj : objs) {
            serialize(out, obj);
        }
        out.printf("END_ENUMERATE\t%s\n", magic);
        out.flush();
    }

    public static <T> List<T> deserializeList(Scanner in, Class<T> clazz) throws ParseException {
        try {
            var list = new ArrayList<T>();
            var constructor = clazz.getConstructor();
            constructor.setAccessible(true);

            var enumLine = in.nextLine().split("\t");
            expect(enumLine[0].equals("ENUMERATE"), "expected enumerate");
            var numElements = Integer.parseInt(enumLine[1]);
            var magic = enumLine[2];

            for (int i = 0; i < numElements; i++) {
                var obj = constructor.newInstance();
                deserialize(in, obj);
                list.add(obj);
            }

            var endEnumLine = in.nextLine().split("\t");
            expect(endEnumLine[0].equals("END_ENUMERATE"), "expected end enumerate");
            expect(endEnumLine[1].equals(magic), "expected magic");
            return list;
        } catch (InstantiationException e) {
            throw new ParseException("bad constructor", e);
        } catch (IllegalAccessException e) {
            throw new ParseException("bad constructor", e);
        } catch (InvocationTargetException e) {
            throw new ParseException("bad constructor", e);
        } catch (NoSuchMethodException e) {
            throw new ParseException("bad constructor", e);
        } catch (NumberFormatException e) {
            throw new ParseException("expected integral enumerate size", e);
        }
    }

    /**
     * Serialize an object to a PrintStream.
     *
     * Only works on objects with fields that can easily be converted to/from
     * strings
     */
    public static void serialize(PrintStream out, Object obj) {
        var clazz = obj.getClass();
        var fields = clazz.getDeclaredFields();
        var magic = UUID.randomUUID();
        out.printf("BEGIN\t%s\t%s\n", clazz.getSimpleName(), magic.toString());
        for (var field : fields) {
            if (field.isAnnotationPresent(ReceiveOnly.class) || Modifier.isTransient(field.getModifiers()) ||
                Modifier.isStatic(field.getModifiers()))
                continue;
            try {
                field.setAccessible(true);
                out.printf("FIELD\t%s\t", field.getType().getSimpleName());
                var val = field.get(obj);
                out.println(escapeString(val == null ? "null" : val.toString()));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        out.printf("END\t%s\t%s\n", clazz.getSimpleName(), magic.toString());
        out.flush();
    }

    public static <T> T deserialize(Scanner in, Class<T> clazz) throws ParseException {
        try {
            var constructor = clazz.getConstructor();
            constructor.setAccessible(true);
            var out = constructor.newInstance();
            deserialize(in, out);
            return out;
        } catch (InstantiationException e) {
            throw new ParseException("bad constructor", e);
        } catch (IllegalAccessException e) {
            throw new ParseException("bad constructor", e);
        } catch (InvocationTargetException e) {
            throw new ParseException("bad constructor", e);
        } catch (NoSuchMethodException e) {
            throw new ParseException("bad constructor", e);
        }
    }

    public static void deserialize(Scanner in, Object obj) throws ParseException {
        var clazz = obj.getClass();
        var fields = clazz.getDeclaredFields();
        var beginLine = in.nextLine().split("\t");
        expect(beginLine[0].equals("BEGIN"), "Expected begin line");
        expect(beginLine[1].equals(clazz.getSimpleName()), "Wrong class type");
        var magic = beginLine[2];
        for (var field : fields) {
            if (field.isAnnotationPresent(SendOnly.class) || Modifier.isTransient(field.getModifiers()) ||
                Modifier.isStatic(field.getModifiers()))
                continue;
            try {
                field.setAccessible(true);
                var fieldLine = in.nextLine().split("\t");
                expect(fieldLine[0].equals("FIELD"), "Expected field line");
                expect(fieldLine[1].equals(field.getType().getSimpleName()), "Expected field type same");

                var strValue = unescapeString(fieldLine[2]);

                if (strValue.equals("null")) {
                    field.set(obj, null);
                    continue;
                }

                switch (fieldLine[1]) {
                case "String":
                    field.set(obj, strValue);
                    break;
                case "UUID":
                    field.set(obj, UUID.fromString(strValue));
                    break;
                case "List": {
                    var list = new ArrayList<UUID>();
                    if (!strValue.equals("[]")) {
                        var split = strValue.substring(1, strValue.length() - 1).split(",");
                        for (var item : split) {
                            try {
                                list.add(UUID.fromString(item.trim()));
                            } catch (IllegalArgumentException e) {
                                System.out.println(item.trim());
                                throw new ParseException(e.getMessage(), e);
                            }
                        }
                    }
                    field.set(obj, list);
                    break;
                }
                case "ZonedDateTime":
                    field.set(obj, ZonedDateTime.parse(strValue));
                    break;
                case "double":
                    field.setDouble(obj, Double.parseDouble(strValue));
                    break;
                case "int":
                    field.setInt(obj, Integer.parseInt(strValue));
                    break;
                default:
                    throw new ParseException("Unexpected type: " + fieldLine[1]);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
        var endLine = in.nextLine().split("\t");
        expect(endLine[0].equals("END"), "Expected end line");
        expect(endLine[1].equals(clazz.getSimpleName()), "Wrong class type");
        expect(endLine[2].equals(magic), "Invalid magic");
    }

    private static void expect(boolean predicate, String message) throws ParseException {
        if (!predicate)
            throw new ParseException(message);
    }
}