package cs180.serialize;

/**
 * An interface denoting data that will only be deserialized, not serialized.
 *
 * @author Zachary Mayhew
 * @version December 10, 2021
 */
public @interface ReceiveOnly {
}
