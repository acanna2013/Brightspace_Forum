package cs180.client;

import static org.junit.Assert.*;

import cs180.client.ClientInterface.FetchException;
import cs180.client.database.*;
import cs180.server.ServerController;
import cs180.server.database.Controller;
import cs180.server.database.Database;
import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.*;
import org.junit.*;
import org.junit.rules.Timeout;

/**
 * Test cases for client server interface
 * 
 * @author Zachary Mayhew
 * @version December 10, 2021
 */
public class ClientServerTest {

    // We need to use a global timeout because @Test(timeout...) will execute
    // the test in a different thread from @Before and will make all sorts of
    // mess.
    @Rule public Timeout timeout = Timeout.seconds(2);

    private Database db;
    private Controller app;
    private ClientInterface ci;
    private Thread serverThread;
    private ServerController serverController;

    @Before
    public void startServer() throws InterruptedException, IOException, FetchException {
        // DB is not sync, only access data from app
        db = new Database(new HashMap<>(), new HashMap<>(), new HashMap<>(), new HashMap<>());
        app = new Controller(db, false);
        var serverMonitor = new Object();
        serverThread = new Thread(() -> {
            try {
                serverController = new ServerController(app, 1234);
                serverController.start(serverMonitor);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        serverThread.start();
        synchronized (serverMonitor) {
            serverMonitor.wait();
        }

        ci = new ClientInterface("localhost", 1234);
    }

    @After
    public void stopServer() throws InterruptedException, IOException {
        if (serverController != null) {
            serverController.kill();
            serverThread.join();
        }
    }

    private User loginTestTeacher() throws FetchException {
        var testUser = createDummyUser(true, "johndoe", "John Doe", "bad_password");
        ci.login("johndoe", "bad_password");
        return testUser;
    }

    private User createDummyUser(boolean teacher, String username, String fullName, String password)
        throws FetchException {
        var testUser = new User(UUID.randomUUID(), teacher ? "teacher" : "student", username, password, fullName,
            new ArrayList<>(), new ArrayList<>());
        ci.createUser(testUser);
        return testUser;
    }

    private Course createDummyCourse(UUID teacher, String name) throws FetchException {
        var testCourse = new Course(UUID.randomUUID(), name, teacher, new ArrayList<>(), new ArrayList<>());
        ci.createCourse(testCourse);
        return testCourse;
    }

    private Message createDummyPost(UUID postedBy, UUID forum, String title, String message) throws FetchException {
        var testPost = new Message(UUID.randomUUID(), postedBy, forum, null, new ArrayList<>(), new ArrayList<>(),
            ZonedDateTime.now(), ZonedDateTime.now(), title, message, 0, 0.0);
        ci.createPost(testPost);
        return testPost;
    }

    private Forum createDummyForum(UUID course, String topic) throws FetchException {
        var testForum = new Forum(UUID.randomUUID(), course, new ArrayList<>(), topic);
        ci.createForum(testForum);
        return testForum;
    }

    // Courses

    @Test
    public void testGetCourse() throws FetchException {
        var teacher = loginTestTeacher();
        var course = createDummyCourse(teacher.getUUID(), "Course");
        var fetched = ci.getCourse(course.getUUID());
        assertEquals(course, fetched);
    }

    @Test
    public void testGetAllCourses() throws FetchException {
        var teacher = loginTestTeacher();
        var c1 = createDummyCourse(teacher.getUUID(), "C1");
        var c2 = createDummyCourse(teacher.getUUID(), "C2");
        var cs = ci.getAllCourses();
        assertEquals(cs.size(), 2);
        assertTrue(cs.contains(c1));
        assertTrue(cs.contains(c2));
    }

    @Test
    public void testDeleteCourse() throws FetchException {
        var teacher = loginTestTeacher();
        var c1 = createDummyCourse(teacher.getUUID(), "C1");
        ci.deleteCourse(c1.getUUID());
        assertThrows(FetchException.class, () -> ci.getCourse(c1.getUUID()));
    }

    @Test
    public void testUpdateCourse() throws FetchException {
        var teacher = loginTestTeacher();
        var c1 = createDummyCourse(teacher.getUUID(), "C1");
        c1.setTitle("C1234");
        ci.updateCourse(c1);
        var fetched = ci.getCourse(c1.getUUID());
        assertEquals(fetched.getTitle(), "C1234");
    }

    // User

    @Test
    public void testGetAllUsers() throws FetchException {
        var u1 = loginTestTeacher();
        var u2 = createDummyUser(false, "billybob", "Billy Bob", "pass1");
        var us = ci.getAllUsers();
        assertEquals(us.size(), 2);
        assertTrue(us.contains(u1));
        assertTrue(us.contains(u2));
    }

    @Test
    public void testGetUser() throws FetchException {
        var u1 = loginTestTeacher();
        createDummyUser(false, "billybob", "Billy Bob", "pass1");
        var user = ci.getUser(u1.getUUID());
        assertEquals(u1, user);
    }

    @Test
    public void testDeleteUser() throws FetchException {
        var u1 = createDummyUser(true, "johndoe", "John Doe", "pass");
        assertThrows(FetchException.class, () -> ci.deleteUser(u1.getUUID()));
        ci.login("johndoe", "pass");
        ci.deleteUser(u1.getUUID());
        assertThrows(FetchException.class, () -> ci.getUser(u1.getUUID()));
    }

    @Test
    public void testUpdateUser() throws FetchException {
        var u1 = loginTestTeacher();
        createDummyUser(false, "billybob", "Billy Bob", "pass1");
        u1.setFullName("Bob");
        ci.updateUser(u1);
        var user = ci.getUser(u1.getUUID());
        assertEquals(u1, user);
    }

    // Posts

    @Test
    public void testGetPost() throws FetchException {
        var u1 = loginTestTeacher();
        var c1 = createDummyCourse(u1.getUUID(), "course");
        var f1 = createDummyForum(c1.getUUID(), "forum");
        var p1 = createDummyPost(u1.getUUID(), f1.getUUID(), "title", "msg");
        var fetched = ci.getPost(p1.getUUID());
        assertEquals(p1, fetched);
    }

    @Test
    public void testUpdatePost() throws FetchException {
        var u1 = loginTestTeacher();
        var c1 = createDummyCourse(u1.getUUID(), "course");
        var f1 = createDummyForum(c1.getUUID(), "forum");
        var p1 = createDummyPost(u1.getUUID(), f1.getUUID(), "title", "msg");
        p1.setGrade(3.2);
        ci.updatePost(p1);
        var fetched = ci.getPost(p1.getUUID());
        assertEquals(p1, fetched);
    }

    @Test
    public void testDeletePost() throws FetchException {
        var u1 = loginTestTeacher();
        var c1 = createDummyCourse(u1.getUUID(), "course");
        var f1 = createDummyForum(c1.getUUID(), "forum");
        var p1 = createDummyPost(u1.getUUID(), f1.getUUID(), "title", "msg");
        ci.deletePost(p1.getUUID());
        assertThrows(FetchException.class, () -> ci.getPost(p1.getUUID()));
    }

    // Forum

    @Test
    public void testGetForum() throws FetchException {
        var u1 = loginTestTeacher();
        var c1 = createDummyCourse(u1.getUUID(), "course");
        var f1 = createDummyForum(c1.getUUID(), "forum");
        var fetched = ci.getForum(f1.getUUID());
        assertEquals(f1, fetched);
    }

    @Test
    public void testUpdateForum() throws FetchException {
        var u1 = loginTestTeacher();
        var c1 = createDummyCourse(u1.getUUID(), "course");
        var f1 = createDummyForum(c1.getUUID(), "forum");
        f1.setForumTopic("not_this");
        ci.updateForum(f1);
        var fetched = ci.getForum(f1.getUUID());
        assertEquals(f1, fetched);
    }

    @Test
    public void testDeleteForum() throws FetchException {
        var u1 = loginTestTeacher();
        var c1 = createDummyCourse(u1.getUUID(), "course");
        var f1 = createDummyForum(c1.getUUID(), "forum");
        ci.deleteForum(f1.getUUID());
        assertThrows(FetchException.class, () -> ci.getForum(f1.getUUID()));
    }

    @Test
    public void testLogin() throws InterruptedException, IOException, FetchException {
        var testUser = new User(
            UUID.randomUUID(), "teacher", "johndoe", "bad_password", "John Doe", new ArrayList<>(), new ArrayList<>());
        ci.createUser(testUser);
        ci.login("johndoe", "bad_password");
        assertEquals(ci.getCurrentUser(), testUser.getUUID());
        assertNotNull(app.getUser(testUser.getUUID()));
    }
}
