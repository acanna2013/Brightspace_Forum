package cs180.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.UUID;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;

import cs180.client.database.Course;
import cs180.client.database.User;

/**
 * CourseListView
 * Displays lists of courses in the database
 * Allows teachers to create and edit courses
 * Allows users to join or open a course
 *
 * @author Anna Chen
 * @version November 28, 2021
 */

public class CourseListView extends JPanel
    implements UpdatablePane
{

    private ClientInterface ci;

    private User currentUser;
    private List<Course> courseList;
    private MainWindow mainWindow;

    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");

    Timer updateTimer;

    public CourseListView(ClientInterface app,
        MainWindow mainWindow)
    {
        try
        {
            this.ci = app;
            var uid = app.getCurrentUser();
            currentUser = app.getUser(uid);
            courseList = app.getAllCourses();
            createAndDisplayGUI();
            this.mainWindow = mainWindow;
        } catch (ClientInterface.FetchException f)
        {
            JOptionPane
                .showMessageDialog(null, f.getMessage(),
                                   "Error connecting to app!",
                                   JOptionPane.ERROR_MESSAGE);
        }
        updateTimer =
            new Timer(mainWindow.UPDATE_TIME, (e) -> {
                try
                {
                    if (!mainWindow.checkCurrentUser())
                    {
                        mainWindow.dispose();
                    } else
                    {
                        var uid = app.getCurrentUser();
                        currentUser = app.getUser(uid);
                        courseList = app.getAllCourses();
                    }

                } catch (ClientInterface.FetchException f)
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           f.getMessage(),
                                           "Error connecting to app!",
                                           JOptionPane.ERROR_MESSAGE);
                }
                removeAll();
                createAndDisplayGUI();
                revalidate();
            });
    }

    private void createAndDisplayGUI()
    {
        setBackground(Color.BLACK);
        setLayout(new BorderLayout());
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel,
                                      BoxLayout.Y_AXIS));
        panel.setMaximumSize(new Dimension(100, 200));
        panel.setPreferredSize(new Dimension(500, 500));

        JPanel topCreate = new JPanel();
        topCreate.setBorder(BorderFactory
            .createLineBorder(PUR_GOLD_NEON, 5));

        // Create course button for teachers
        JButton createButton =
            new JButton("<html><b>Create</b></html>");
        createButton
            .setFont(new Font("Arial", Font.PLAIN, 20));
        createButton
            .addActionListener(makeCreateActionListener(createButton));
        createButton.setBorderPainted(true);
        createButton.setForeground(Color.decode("#C28E0E"));
        topCreate.add(createButton);
        add(topCreate, BorderLayout.NORTH);

        for (Course course : courseList)
        {
            JPanel coursePanel = new JPanel();
            coursePanel
                .setLayout(new FlowLayout(FlowLayout.LEFT));
            coursePanel
                .setBorder(new CompoundBorder(BorderFactory
                    .createLineBorder(Color
                        .decode("#C28E0E"), 5), BorderFactory
                            .createEmptyBorder(10, 10, 10,
                                               10)));
            coursePanel
                .setPreferredSize(new Dimension(150, 20));

            JLabel title = new JLabel((course.getTitle()));
            title.setForeground((PUR_GOLD_NEON));
            title.setFont(new Font("Arial", Font.PLAIN, 20));
            title.setMaximumSize(new Dimension(60, 50));
            JScrollPane scrollPane1 =
                new JScrollPane(title,
                                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scrollPane1.setSize(new Dimension(100, 60));
            coursePanel.add(scrollPane1);
            try
            {
                JLabel teacherTitle =
                    new JLabel("\nTeacher: "
                        + ci.getUser(course.getTeacher())
                            .getFullName());
                teacherTitle.setForeground((PUR_GOLD_NEON));
                teacherTitle
                    .setFont(new Font("Arial", Font.PLAIN,
                                      12));
                teacherTitle
                    .setMaximumSize(new Dimension(100, 20));
                JScrollPane scrollPane =
                    new JScrollPane(teacherTitle,
                                    JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                                    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                scrollPane.setSize(new Dimension(100, 20));
                coursePanel.add(scrollPane);
            } catch (ClientInterface.FetchException e)
            {
                JLabel teacherTitle =
                    new JLabel("\nTeacher: TBD");
                teacherTitle.setForeground((PUR_GOLD_NEON));
                teacherTitle
                    .setFont(new Font("Arial", Font.PLAIN,
                                      12));
                teacherTitle
                    .setMaximumSize(new Dimension(100, 20));
                JScrollPane scrollPane =
                    new JScrollPane(teacherTitle,
                                    JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                                    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
                scrollPane.setSize(new Dimension(100, 20));
                coursePanel.add(scrollPane);
            }
            // Edit course button for teachers
            JButton editButton = new JButton("Edit");
            editButton.setForeground(PUR_GOLD_NEON);
            editButton
                .addActionListener(makeEditActionListener(course,
                                                          editButton));

            // Open course button for teachers and students
            JButton openButton = new JButton("Open");
            openButton.setForeground(PUR_GOLD_NEON);
            openButton
                .addActionListener(makeOpenActionListener(course,
                                                          openButton));

            if (!currentUser.getCourses()
                .contains(course.getUUID()))
            {
                openButton.setEnabled(false);
            }

            // Join course button for students and teachers
            JButton joinButton = new JButton("Join");
            joinButton.setForeground(PUR_GOLD_NEON);
            joinButton
                .addActionListener(makeJoinActionListener(course,
                                                          joinButton));

            if (currentUser.getCourses()
                .contains(course.getUUID()))
            {
                joinButton.setEnabled(false);
            }

            // Delete course button for students and teachers
            JButton deleteButton = new JButton("Delete");
            deleteButton.setForeground(PUR_GOLD_NEON);
            deleteButton
                .addActionListener(makeDeleteActionListener(course,
                                                            coursePanel,
                                                            deleteButton));
            revalidate();

            if (currentUser.getKind()
                .equalsIgnoreCase("student"))
            {
                createButton.setEnabled(false);
                deleteButton.setEnabled(false);
                editButton.setEnabled(false);
            }
            coursePanel.add(Box.createVerticalStrut(5));
            coursePanel.add(openButton);
            coursePanel.add(joinButton);
            coursePanel.add(editButton);
            coursePanel.add(deleteButton);
            coursePanel.add(Box.createVerticalStrut(5));
            panel.add(coursePanel);

        }
        JScrollPane scrollPane = new JScrollPane(panel);
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);
        revalidate();
    }

    private ActionListener makeOpenActionListener(Course course,
                                                  JButton openButton)
    {
        return new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == openButton)
                {
                    try
                    {
                        open(course);
                    } catch (ClientInterface.FetchException ex)
                    {
                        // ex.printStackTrace();
                        JOptionPane
                            .showMessageDialog(null, ex
                                .getMessage(), "Error",
                                               JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        };
    }

    private ActionListener makeCreateActionListener(JButton createButton)
    {
        return new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == createButton)
                {
                    try
                    {
                        create();
                    } catch (ClientInterface.FetchException ex)
                    {
                        // ex.printStackTrace();
                        JOptionPane
                            .showMessageDialog(null, ex
                                .getMessage(), "Error",
                                               JOptionPane.ERROR_MESSAGE);

                    }
                }
            }
        };
    }

    private ActionListener makeJoinActionListener(Course course,
                                                  JButton joinButton)
    {
        return new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == joinButton)
                {
                    try
                    {
                        join(course);
                    } catch (ClientInterface.FetchException ex)
                    {
                        // ex.printStackTrace();
                        JOptionPane
                            .showMessageDialog(null, ex
                                .getMessage(), "Error",
                                               JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        };
    }

    private ActionListener makeEditActionListener(Course course,
                                                  JButton editButton)
    {
        return new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == editButton)
                {
                    try
                    {
                        edit(course);
                    } catch (ClientInterface.FetchException ex)
                    {
                        // ex.printStackTrace();
                        JOptionPane
                            .showMessageDialog(null, ex
                                .getMessage(), "Error",
                                               JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        };
    }

    private ActionListener makeDeleteActionListener(Course course,
                                                    JPanel panel,
                                                    JButton deleteButton)
    {
        return new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == deleteButton)
                {
                    try
                    {
                        deleteCourse(course);
                        remove(panel);
                        revalidate();
                    } catch (ClientInterface.FetchException ex)
                    {
                        // ex.printStackTrace();
                        JOptionPane
                            .showMessageDialog(null, ex
                                .getMessage(), "Error",
                                               JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        };
    }

    public void join(Course course)
        throws ClientInterface.FetchException
    {
        String affirmation = "";
        do
        {
            for (UUID uuid : currentUser.getCourses())
            {
                if (course.getUUID().equals(uuid))
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           "You already joined this course!",
                                           "Invalid course",
                                           JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            affirmation =
                JOptionPane
                    .showInputDialog(null,
                                     "Are you sure you want to join this course "
                                         + course.getTitle()
                                         + "?",
                                     "Join course",
                                     JOptionPane.QUESTION_MESSAGE);
            if (affirmation == null)
                return;
            if (affirmation.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Please input something!",
                                       "Invalid input",
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (affirmation.isEmpty());
        if (affirmation.equalsIgnoreCase("yes"))
        {
            currentUser.addCourse(course.getUUID());
            ci.updateUser(currentUser);
            course.addStudent(currentUser.getUUID());
            ci.updateCourse(course);
        }
        removeAll();
        createAndDisplayGUI();
    }

    // display view of forums in the course
    public void open(Course course)
        throws ClientInterface.FetchException
    {
        ci.getForumList(course.getForum());
        mainWindow.showForumList(course.getUUID());
    }

    public String create()
        throws ClientInterface.FetchException
    {
        String courseTitle = "";
        if (currentUser.getKind().equalsIgnoreCase("teacher"))
        {
            do
            {
                courseTitle =
                    JOptionPane
                        .showInputDialog(null,
                                         "Enter name of course you want to create",
                                         "Create New Course",
                                         JOptionPane.QUESTION_MESSAGE);
                if (courseTitle == null)
                {
                    return null;
                }
                if (courseTitle.isEmpty())
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           "Nothing was inputted. Please enter course name.",
                                           "Invalid input.",
                                           JOptionPane.ERROR_MESSAGE);
                }
            }
            while (courseTitle.isEmpty());
        } else
        {
            JOptionPane
                .showMessageDialog(null,
                                   "User not authorized to create course!",
                                   "Access Denied",
                                   JOptionPane.ERROR_MESSAGE);
            return null;
        }
        Course addCourse =
            new Course(courseTitle, currentUser.getUUID());
        courseList.add(addCourse);
        ci.createCourse(addCourse);
        removeAll();
        createAndDisplayGUI();
        return courseTitle;
    }

    // Edit course name
    public void edit(Course course)
        throws ClientInterface.FetchException
    {
        String affirmation = "";

        // ask for confirmation if user wants to edit course
        if (currentUser.getKind().equalsIgnoreCase("Teacher"))
        {
            do
            {
                affirmation =
                    JOptionPane
                        .showInputDialog(null,
                                         "Are you sure you want to edit this course?",
                                         "Edit Course",
                                         JOptionPane.QUESTION_MESSAGE);
                if (affirmation == null)
                {
                    return;
                }
                if (affirmation.isEmpty())
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           "Nothing was inputted. Please enter course name.",
                                           "Invalid input.",
                                           JOptionPane.ERROR_MESSAGE);
                }
            }
            while (affirmation.isEmpty());

            // If user wants to delete or edit name of course
            if (affirmation.equalsIgnoreCase("yes"))
            {
                editCourseName(course);
            }
        } else
        {
            JOptionPane
                .showMessageDialog(null,
                                   "User not authorized to edit course!",
                                   "Access Denied",
                                   JOptionPane.ERROR_MESSAGE);
            return;
        }
        removeAll();
        createAndDisplayGUI();
    }

    // called in edit() method
    public String editCourseName(Course course)
        throws ClientInterface.FetchException
    {
        String courseTitle = "";
        // Course's new name
        do
        {
            courseTitle =
                JOptionPane
                    .showInputDialog(null,
                                     "Enter new course name",
                                     "Edit Course Name",
                                     JOptionPane.QUESTION_MESSAGE);
            if (courseTitle == null)
            {
                return null;
            }
            if (courseTitle.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Nothing was inputted. Please enter course name.",
                                       "Invalid input.",
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (courseTitle.isEmpty());
        course.setTitle(courseTitle);
        ci.updateCourse(course);
        removeAll();
        createAndDisplayGUI();
        return courseTitle;
    }

    public void deleteCourse(Course course)
        throws ClientInterface.FetchException
    {
        String delConfirmation = "";
        // Delete course
        do
        {
            delConfirmation =
                JOptionPane
                    .showInputDialog(null,
                                     "Are you sure you want to delete this course "
                                         + course.getTitle()
                                         + "?",
                                     "Delete Course",
                                     JOptionPane.QUESTION_MESSAGE);
            if (delConfirmation == null)
            {
                return;
            }
            if (delConfirmation.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Nothing was inputted. Please try again.",
                                       "Invalid input.",
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (delConfirmation.isEmpty());
        if (delConfirmation.equalsIgnoreCase("yes"))
        {
            ci.deleteCourse(course.getUUID());
            currentUser.removeCourse(course.getUUID());
            ci.updateUser(currentUser);
        }
        var uid = ci.getCurrentUser();
        currentUser = ci.getUser(uid);
        courseList = ci.getAllCourses();

        removeAll();
        createAndDisplayGUI();
    }

    public void startAutoUpdate()
    {
        updateTimer.start();
    }

    public void pauseAutoUpdate()
    {
        updateTimer.stop();
    }

    public void updateGUI(UUID thingToUpdate)
    {
        // leave empty
    }

}