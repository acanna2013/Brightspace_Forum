package cs180.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;

import cs180.client.ClientInterface.FetchException;
import cs180.client.database.Message;
import cs180.client.database.User;

/**
 * PostListView class
 *
 * Contains list of posts and replies in the forum
 * Contains sorting dropdown
 * Allows users to create, edit, delete posts
 * Allows users to reply to other posts
 * Allows students to upvote posts
 * Allows teacher to grade posts
 *
 * @author Rachel La, Zachary Mayhew
 * @version December 4, 2021
 */

public class PostListView extends JPanel
    implements UpdatablePane
{
    private ClientInterface app;
    private User currentUser;
    private UUID currentForumOrUser;
    private boolean isForum;
    private Message currentPost;
    private List<Message> posts;
    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");
    private Timer updateTimer;

    JScrollPane scroller;
    String postContent;
    String newTitle;
    JButton create;
    JFrame createWindow;
    JButton submitCreate;
    JButton submitEdit;
    JTextArea postTitle;
    JTextArea userPost;
    MainWindow window;
    boolean isClicked = false;

    public PostListView(boolean isForum, ClientInterface app,
        MainWindow window)
    {
        try
        {
            this.isForum = isForum;
            this.app = app;
            var uid = app.getCurrentUser();
            currentUser = app.getUser(uid);
            this.window = window;
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error connecting to app",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
        }
        updateTimer = new Timer(window.UPDATE_TIME, (e) -> {
            try
            {
                if (!window.checkCurrentUser())
                {
                    if (createWindow != null
                        && createWindow.isVisible())
                    {
                        createWindow.dispose();
                    }

                    window.dispose();
                } else
                {
                    removeAll();
                    createAndDisplayGUI();
                    revalidate();
                }
            } catch (ClientInterface.FetchException e1)
            {
                e1.printStackTrace();
            }
        });
    }

    ActionListener actionListener = new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            if (e.getSource() == create)
            {
                createPost(null);
            }
            if (e.getSource() == submitEdit)
            {
                submitEdit();
            }
        }
    };

    /**
     * Creates new post in the forum
     */
    public void createPost(UUID replyTo)
    {
        createWindow = new JFrame("Create New Post");
        createWindow.setSize(600, 400);
        createWindow.setLocationRelativeTo(null);
        createWindow
            .setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        createWindow.setVisible(true);

        JPanel titlePanel = new JPanel();
        JPanel submitPanel = new JPanel();
        submitCreate = new JButton("Submit");
        submitCreate
            .addActionListener((e) -> submitCreate(replyTo));
        submitPanel.add(submitCreate);
        postTitle = new JTextArea("Enter title", 0, 20);
        userPost = new JTextArea(20, 20);
        postTitle.setLineWrap(true);
        userPost.setLineWrap(true);
        titlePanel.add(postTitle);
        JScrollPane scrollPane = new JScrollPane(userPost);
        createWindow.add(titlePanel, BorderLayout.NORTH);
        createWindow.add(scrollPane, BorderLayout.CENTER);
        createWindow.add(submitPanel, BorderLayout.PAGE_END);
    }

    /**
     * Closes create post frame and save new post to forum
     *
     * @param replyTo
     */
    public void submitCreate(UUID replyTo)
    {
        if (!isForum)
        {
            return;
        }
        createWindow.dispose();
        if (postTitle.getText().isEmpty()
            || userPost.getText().isEmpty())
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Can't create an empty post."
                                       + " Please try again!",
                                   "Create Post",
                                   JOptionPane.ERROR_MESSAGE);
        } else
        {
            newTitle =
                postTitle.getText().replaceAll("\n", " ");
            postContent =
                userPost.getText().replaceAll("\n", " ");
            LocalDateTime now = LocalDateTime.now();
            ZonedDateTime zonedDateTime =
                now.atZone(ZoneId.systemDefault());
            Message post =
                new Message(UUID.randomUUID(),
                            currentUser.getUUID(),
                            replyTo == null
                                ? currentForumOrUser
                                : null,
                            replyTo, new ArrayList<>(),
                            new ArrayList<>(), zonedDateTime,
                            zonedDateTime, newTitle,
                            postContent, 0, 0.0);
            try
            {
                app.createPost(post);
                createAndDisplayGUI();
            } catch (ClientInterface.FetchException e)
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "An error occurs. Please try again",
                                       "Error",
                                       JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
            isClicked = false;
        }
    }

    /**
     * Pops up a window asking user for the post to delete
     *
     * @param p
     * @return the post they want to delete
     */
    public void deletePost(Message p)
    {
        try
        {
            app.deletePost(p.getUUID());
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "An error occurs. Please try again",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    /**
     * Sort post from newest to oldest
     *
     * @param listOfPosts
     */
    public void byNewestToOldest(List<Message> listOfPosts)
    {
        Collections
            .sort(listOfPosts, (a, b) -> a.getZonedDateTime()
                .compareTo(b.getZonedDateTime()));
        Collections.reverse(listOfPosts);
        posts = listOfPosts;
        try
        {
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            e.printStackTrace();
        }
        isClicked = true;
    }

    /**
     * Sort post from oldest to newest
     *
     * @param listOfPosts
     */
    public void byOldestToNewest(List<Message> listOfPosts)
    {
        Collections
            .sort(listOfPosts, (a, b) -> a.getZonedDateTime()
                .compareTo(b.getZonedDateTime()));
        posts = listOfPosts;
        try
        {
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            e.printStackTrace();
        }
        isClicked = true;
    }

    /**
     * Sort post by votes
     *
     * @param listOfPosts
     */
    public void byVotes(List<Message> listOfPosts)
    {
        Collections.sort(listOfPosts, (a, b) -> b.getUpvotes() - a.getUpvotes());
        posts = listOfPosts;
        try
        {
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            e.printStackTrace();
        }
        isClicked = true;
    }

    /**
     * Pops up a window for the user to edit the post content or title
     *
     * @param postToEdit
     */
    public void edit(Message postToEdit)
    {
        createWindow = new JFrame("Edit Post");
        createWindow.setSize(600, 400);
        createWindow.setLocationRelativeTo(null);
        createWindow
            .setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        createWindow.setVisible(true);

        JPanel titlePanel = new JPanel();
        JPanel submitPanel = new JPanel();
        submitEdit = new JButton("Submit");
        submitEdit.addActionListener(actionListener);
        submitPanel.add(submitEdit);
        postTitle = new JTextArea("Enter title", 0, 20);
        postTitle.setText(postToEdit.getTitle());
        userPost = new JTextArea(20, 20);
        userPost.setText(postToEdit.getMessageContents());
        postTitle.setLineWrap(true);
        userPost.setLineWrap(true);
        titlePanel.add(postTitle);
        JScrollPane scrollPane = new JScrollPane(userPost);
        createWindow.add(titlePanel, BorderLayout.NORTH);
        createWindow.add(scrollPane, BorderLayout.CENTER);
        createWindow.add(submitPanel, BorderLayout.PAGE_END);
        currentPost = postToEdit;
    }

    /**
     * Save new changes made to post after the user clicked submit
     */
    public void submitEdit()
    {
        createWindow.dispose();
        if (postTitle.getText().isEmpty()
            || userPost.getText().isEmpty())
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Can't create an empty post."
                                       + " Please try again!",
                                   "Create Post",
                                   JOptionPane.ERROR_MESSAGE);
        } else
        {
            currentPost.setTitle(postTitle.getText()
                .replaceAll("\n", " "));
            currentPost.setMessageContents(userPost.getText()
                .replaceAll("\n", " "));
            currentPost.updateDateLastEdited();
            try
            {
                app.updatePost(currentPost);
                createAndDisplayGUI();
            } catch (ClientInterface.FetchException e)
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "An error occurs. Please try again",
                                       "Error",
                                       JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    /**
     * Increments the upvote whenever the upvote button is clicked
     *
     * @param post
     */
    public void upvote(Message post)
    {
        boolean hasNotVote = true;
        for (UUID u : post.getUsersUpvoted())
        {
            if (currentUser.getUUID().equals(u))
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "You've already voted!",
                                       "Upvote Post",
                                       JOptionPane.ERROR_MESSAGE);
                hasNotVote = false;
            }
        }
        if (hasNotVote)
        {
            post.addUserUpvoted(currentUser.getUUID());
            int vote = post.getUpvotes();
            post.setUpvote(vote + 1);
            JOptionPane
                .showMessageDialog(null,
                                   "Voted!\nUpvote: "
                                       + post.getUpvotes(),
                                   "Upvote Post",
                                   JOptionPane.INFORMATION_MESSAGE);
            try
            {
                app.updatePost(post);
                createAndDisplayGUI();
            } catch (ClientInterface.FetchException e)
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Error updating vote. Please try again",
                                       "Error",
                                       JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }

    /**
     * Pops up a window for teacher to grade the post
     *
     * @param post
     */
    public void score(Message post)
    {
        boolean isDouble;
        String temp;
        double score = post.getGrade();
        do
        {
            try
            {
                temp =
                    JOptionPane
                        .showInputDialog(null, "Grade:",
                                         "Grade Post",
                                         JOptionPane.QUESTION_MESSAGE);
                if (temp == null)
                {
                    return;
                }
                if (temp.isEmpty())
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           "Please enter something!",
                                           "Grade Post",
                                           JOptionPane.ERROR_MESSAGE);
                    isDouble = false;
                } else
                {
                    score = Double.parseDouble(temp);
                    isDouble = true;
                }
            } catch (NumberFormatException e)
            {
                isDouble = false;
                JOptionPane
                    .showMessageDialog(null,
                                       "Please only enter numbers!",
                                       "Grade Post",
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (!isDouble);
        post.setGrade(score);
        try
        {
            app.updatePost(post);
            JOptionPane
                .showMessageDialog(null,
                                   "Grade updated successfully!\nGrade: "
                                       + post.getGrade(),
                                   "Grade Post",
                                   JOptionPane.INFORMATION_MESSAGE);
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error updating score. Please try again",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public void createAndDisplayGUI()
        throws ClientInterface.FetchException
    {
        removeAll();
        setLayout(new BorderLayout());

        List<Message> listOfPosts;

        if (isForum)
        {
            var forum = app.getForum(currentForumOrUser);
            listOfPosts =
                app.getPostList(forum.getMessages());
        } else
        {
            var user = app.getUser(currentForumOrUser);
            listOfPosts = app.getPostList(user.getMessages());
        }

        JPanel upperPanel = new JPanel();
        upperPanel.setBackground(Color.BLACK);
        JButton oldestToNewest = new JButton("Oldest-Newest");
        oldestToNewest.setForeground(PUR_GOLD_NEON);
        JButton newestToOldest = new JButton("Newest-Oldest");
        newestToOldest.setForeground(PUR_GOLD_NEON);
        JButton byVote = new JButton("By Vote");
        byVote.setForeground(PUR_GOLD_NEON);
        oldestToNewest
            .addActionListener((e) -> byOldestToNewest(listOfPosts));
        newestToOldest
            .addActionListener((e) -> byNewestToOldest(listOfPosts));
        byVote.addActionListener((e) -> byVotes(listOfPosts));

        upperPanel.add(oldestToNewest);
        upperPanel.add(newestToOldest);
        upperPanel.add(byVote);

        JPanel forumNamePanel = new JPanel();

        if (isForum)
        {
            create = new JButton("Create Post");
            create.addActionListener(actionListener);
            create.setForeground(PUR_GOLD_NEON);
            upperPanel.add(create);
            var currentForum =
                app.getForum(currentForumOrUser);
            JLabel forumName =
                new JLabel(currentForum.getForumTopic());
            forumName
                .setFont(new Font("Arial", Font.BOLD, 15));
            forumName.setForeground(PUR_GOLD_NEON);
            forumNamePanel.setBackground(Color.BLACK);
            forumNamePanel.add(forumName);
        }

        JPanel postsPanel = new JPanel();
        postsPanel.setLayout(new BoxLayout(postsPanel,
                                           BoxLayout.Y_AXIS));

        if (!isClicked)
        {
            posts = listOfPosts;
        }

        for (Message post : posts)
        {
            makePostPanel(post, postsPanel, 0);
        }

        postsPanel.setSize(postsPanel.getPreferredSize());

        scroller = new JScrollPane(postsPanel);
        forumNamePanel.add(upperPanel);
        add(forumNamePanel, BorderLayout.NORTH);
        add(scroller, BorderLayout.CENTER);
        setVisible(true);
        revalidate();
    }

    private void makePostPanel(Message post, JPanel target,
                               int level)
        throws FetchException
    {
        JPanel postPanel = new JPanel();

        postPanel.setSize(600, 600);
        postPanel.setLayout(new BorderLayout());

        JPanel titlePanel = new JPanel();
        var title =
            new JLabel(String
                .format("<html><b>%s</b> - %s - %s</html>",
                        post.getTitle(),
                        app.getUser(post.getPostedBy())
                            .getFullName(),
                        post.getDateCreated().toString()));
        title.setFont(new Font("Arial", Font.BOLD, 15));
        title.setForeground(PUR_GOLD_NEON);
        var author = new JLabel();
        titlePanel.add(title);
        titlePanel.add(author);

        JPanel scoringPanel = new JPanel();
        var upvote =
            new JLabel(String.format("Upvotes: %d",
                                     post.getUpvotes()));
        upvote.setFont(new Font("Arial", Font.PLAIN, 12));
        scoringPanel.add(upvote);

        postPanel.add(titlePanel, BorderLayout.NORTH);
        postPanel.add(scoringPanel,
                      BorderLayout.AFTER_LINE_ENDS);
        var value =
            new JLabel(String
                .format("<html><div width=\"300px\">%s</div></html>",
                        post.getMessageContents()));
        value.setFont(new Font("Arial", Font.PLAIN, 15));
        postPanel.add(value, BorderLayout.CENTER);

        var buttonPanel = new JPanel();

        // var openButton = new JButton("Open");
        // openButton.addActionListener((e) -> new PostView(app, window));
        // buttonPanel.add(openButton);

        var replyButton = new JButton("Reply");
        replyButton.addActionListener((e) -> createPost(post
            .getUUID()));
        buttonPanel.add(replyButton);
        replyButton.setForeground(PUR_GOLD_NEON);

        if (currentUser.getKind().equalsIgnoreCase("teacher")
            || post.getPostedBy()
                .equals(currentUser.getUUID()))
        {
            var score =
                new JLabel(String.format("Grade: %.2f",
                                         post.getGrade()));
            score.setFont(new Font("Arial", Font.PLAIN, 12));
            scoringPanel.add(score);

            var editButton = new JButton("Edit");
            editButton.addActionListener((e) -> edit(post));
            editButton.setForeground(PUR_GOLD_NEON);
            buttonPanel.add(editButton);
        }

        var upvoteButton = new JButton("Upvote");
        upvoteButton.addActionListener((e) -> upvote(post));
        upvoteButton.setForeground(PUR_GOLD_NEON);
        buttonPanel.add(upvoteButton);

        if (currentUser.getKind().equalsIgnoreCase("teacher"))
        {
            var scoreButton = new JButton("Score");
            scoreButton.addActionListener((e) -> score(post));
            buttonPanel.add(scoreButton);
            scoreButton.setForeground(PUR_GOLD_NEON);

            var deleteButton = new JButton("Delete");
            deleteButton
                .addActionListener((e) -> deletePost(post));
            buttonPanel.add(deleteButton);
            deleteButton.setForeground(PUR_GOLD_NEON);
        }

        postPanel.add(buttonPanel, BorderLayout.SOUTH);

        postPanel.setBorder(BorderFactory
            .createCompoundBorder(BorderFactory
                .createEmptyBorder(0, level * 50, 0, 0),
                                  BorderFactory
                                      .createLineBorder(PUR_GOLD_NEON,
                                                        3)));

        postPanel.setSize(postPanel.getPreferredSize());

        target.add(postPanel);

        if (isForum)
        {
            for (Message comment : app
                .getPostList(post.getComments()))
            {
                makePostPanel(comment, target, level + 1);
            }
        }
    }

    public void startAutoUpdate()
    {
        updateTimer.start();
    }

    @Override
    public void pauseAutoUpdate()
    {
        updateTimer.stop();
    }

    @Override
    public void updateGUI(UUID forum)
    {
        currentForumOrUser = forum;
        try
        {
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "An error occurs. Please try again",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
