package cs180.client;

/**
 * The entry point for client side code.
 *
 * @author Zachary Mayhew, Ahmad Abdallah
 * @version December 10, 2021
 */
public class App
{
    public static void main(String[] args)
    {
        new LoginView().run();
        System.out.println("Hello, Client!");
    }
}