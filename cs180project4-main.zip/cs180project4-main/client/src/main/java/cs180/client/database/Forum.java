package cs180.client.database;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Forum Class - A forum for a specific course.
 * Holds messages from users in that course.
 * Contains methods that can manipulate a forum:
 * change title name, add/remove messages
 * The Forum class is tested in the CommandTest class.
 *
 * @author Ahmad Abdallah, Zachary Mayhew
 * @version November 13th, 2021
 */
// clang-format off
public class Forum
{
    private UUID uuid;
    private UUID course;
    private List<UUID> messages;
    private String forumTopic;

    public Forum()
    {
    }

    public Forum(UUID course, String forumTopic)
    {
        this.uuid = UUID.randomUUID();
        this.course = course;
        this.messages = new ArrayList<>();
        this.forumTopic = forumTopic;
    }

    public Forum(UUID uuid, UUID course, List<UUID> messages,
        String forumTopic)
    {
        this.uuid = uuid;
        this.course = course;
        this.messages = messages;
        this.forumTopic = forumTopic;
    }

    /**
     * Gets forum UUID
     *
     * @return Forum UUID
     */
    public UUID getUUID()
    {
        return uuid;
    }

    /**
     * Gets course UUID
     *
     * @return Course UUID
     */
    public UUID getCourse()
    {
        return course;
    }

    /**
     * Gets forum topic
     *
     * @return Forum topic
     */
    public String getForumTopic()
    {
        return forumTopic;
    }

    /**
     * Gets list of UUIDs for each message in Forum
     *
     * @return List of UUIDs associated with messages
     */
    public List<UUID> getMessages()
    {
        return messages;
    }

    /**
     * Updates forum topic to the given parameter
     *
     * @param forumTopic
     *            The new topic given to forum
     */
    public void setForumTopic(String forumTopic)
    {
        this.forumTopic = forumTopic;
    }

    /**
     * Adds given message UUID to the forum's messages list
     *
     * @param message
     *            UUID for new message
     */
    public void addMessage(UUID message)
    {
        Objects.requireNonNull(message);

        messages.add(message);
    }

    /**
     * Removes given message UUID from forum's messages list
     *
     * @param message
     *            UUID for message to remove
     */
    public void removeMessage(UUID message)
    {
        Objects.requireNonNull(message);

        messages.remove(message);
    }

    @Override
    public boolean equals(Object o)
    {
        if (o == this)
            return true;
        if (!(o instanceof Forum))
            return false;
        var forum = (Forum) o;
        return Objects.equals(uuid, forum.uuid)
            && Objects.equals(course, forum.course)
            && Arrays.equals(messages.toArray(),
                             forum.messages.toArray())
            && Objects.equals(forumTopic, forum.forumTopic);
    }
}
// clang-format on