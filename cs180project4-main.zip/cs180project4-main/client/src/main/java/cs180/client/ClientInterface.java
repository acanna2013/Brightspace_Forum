package cs180.client;

import cs180.client.database.*;
import cs180.serialize.Serialize;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * The client interface class handles communication with the server.
 *
 * <p>The client-server interface is based on simple sockets with a REST-like api.
 * A new socket is created for each operation so if an operation fails, the
 * socket IO streams will not become mangled.
 *
 * <p>All data is passed using the serialize package.
 *
 * @see cs180.server.ServerInterface
 * @author Zachary Mayhew
 * @version December 2, 2021
 */
public class ClientInterface {

    /**
     * Utility class for function that throws throwable
     *
     * @param <T> the parameter type
     * @param <R> the return type
     * @param <E> the throwable type
     */
    @FunctionalInterface
    private static interface ThrowingFunction<T, R, E extends Throwable> {
        R apply(T t) throws E;
    }

    /**
     * Fetch exception thrown for any server side errors
     */
    public static class FetchException extends Exception {
        public FetchException(String message) {
            super(message);
        }

        public FetchException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * A class storing important data for a particular fetch
     */
    private static class Fetch {
        public final Scanner in;
        public final PrintStream out;
        public final Socket socket;
        /**
         * @param in
         * @param out
         * @param socket
         * @throws IOException
         * @throws UnknownHostException
         */
        public Fetch(String hostname, int port) throws UnknownHostException, IOException {
            this.socket = new Socket(hostname, port);
            this.in = new Scanner(socket.getInputStream());
            this.out = new PrintStream(socket.getOutputStream());
        }
    }

    private String hostname;
    private int port;

    /**
     * The method with which to interact with the server.
     */
    public static enum Method {
        /**
         * POST requests are requests that create a new object.
         */
        Post("POST"),

        /**
         * GET requests are requests that get data from the server.
         */
        Get("GET"),

        /**
         * DELETE requests are requests that delete an existing object.
         */
        Delete("DELETE"),

        /**
         * PUT requests are requests that update an existing object.
         */
        Put("PUT");

        public final String kind;

        private Method(String kind) {
            this.kind = kind;
        }
    }

    private UUID currentUser;
    private UUID sessionId;

    /**
     * Create a new client interface instance with the given hostname and port.
     * @throws IOException
     */
    public ClientInterface(String hostname, int port) throws FetchException {
        this.hostname = hostname;
        this.port = port;
        currentUser = null;
        sessionId = null;
        if (!pingTest()) {
            throw new FetchException("Server error");
        }
    }

    private Fetch beginFetch() throws FetchException {
        try {
            return new Fetch(hostname, port);
        } catch (IOException e) {
            throw new FetchException(e.getMessage(), e);
        }
    }

    public boolean pingTest() throws FetchException {
        var f = beginFetch();
        f.out.println("PING");
        return f.in.nextLine().equals("PING~");
    }

    // clang-format off
    /**
     * Fetch some data from the server.
     *
     * <h2>Request Types</h2>
     * <h3>POST</h3>
     *
     * <p>POST requests are requests that create a new object.
     *
     * <p>POST requests must use a path with the form: {@code <object>}
     * where object is one of {@code users}, {@code posts}, {@code forums}
     * or {@code courses}.
     *
     * <h3>GET</h3>
     *
     * <p>GET requests are requests that get data from the server.
     *
     * <p>GET requests may get a specific object using the path:
     * {@code <object>/<uuid>}, or get all instances of an object with the
     * path {@code <object>} where {@code object} is one of {@code users},
     * {@code posts}, {@code forums} or {@code courses} and {@code uuid}
     * is the uuid of the object to get. Forums and Posts only support getting
     * a specific object by uuid.
     *
     * <h3>DELETE</h3>
     *
     * <p>DELETE requests are requests that delete an existing object.
     *
     * <p>DELETE requests must use a path with the form: {@code <object>}
     * where object is one of {@code users}, {@code posts}, {@code forums}
     * or {@code courses}.
     *
     * <h3>PUT</h3>
     *
     * PUT requests are requests that update an existing object.
     *
     * <p>PUT requests must use a path with the form: {@code <object>/<uuid>}
     * where {@code object} is one of {@code users}, {@code posts},
     * {@code forums} or {@code courses} and {@code uuid} is the uuid of the
     * object to update.
     *
     * @param method the method with which to request data from the server
     * @param path the path argument for the given method
     * @param sender a consumer which is called to write data to the client
     *               output stream.
     * @param supplier a functor which converts text from the client scanner to
     *                 some type {@code T}
     * @param <T> the type to be returned by the fetch operation.
     * @throws FetchException if the server returns an error of if the client
     *                        fails to parse the response.
     */
    public <T> T fetch(Method method, String path, Consumer<PrintStream> sender,
                       ThrowingFunction<Scanner, T, Serialize.ParseException> supplier) throws FetchException {
        var f = beginFetch();
        var out = f.out;
        var in = f.in;
        // clang-format on
        // Send the request
        if (sessionId != null) {
            out.println("BEGIN_REQUEST\t" + sessionId.toString());
        } else {
            out.println("BEGIN_REQUEST");
        }
        out.println(method.kind + "\t" + path);

        if (sender != null)
            sender.accept(out);

        out.println("END_REQUEST");

        // Receive the response
        if (!in.nextLine().equals("BEGIN_RESPONSE"))
            throw new FetchException("Invalid response");

        var replyHeader = in.nextLine().split("\t");

        if (!replyHeader[0].equals("OK")) {
            throw new FetchException(replyHeader[1]);
        }

        T output = null;
        try {
            if (supplier != null)
                output = supplier.apply(in);
        } catch (Serialize.ParseException e) {
            e.printStackTrace();
            throw new FetchException(e.getMessage());
        }

        if (!in.nextLine().equals("END_RESPONSE"))
            throw new FetchException("Invalid response");

        return output;
    }

    private static String path(String... entries) {
        return String.join("/", entries);
    }

    private <T> T getSingle(String path, Class<T> type) throws FetchException {
        return fetch(Method.Get, path, null, (in) -> Serialize.deserialize(in, type));
    }

    private <T> List<T> getMultiple(String path, Class<T> type) throws FetchException {
        return fetch(Method.Get, path, null, (in) -> Serialize.deserializeList(in, type));
    }

    private <T> void postSingle(String path, T obj) throws FetchException {
        fetch(Method.Post, path, (out) -> Serialize.serialize(out, obj), null);
    }

    private <T> void putSingle(String path, T obj) throws FetchException {
        fetch(Method.Put, path, (out) -> Serialize.serialize(out, obj), null);
    }

    private <T> void deleteSingle(String path) throws FetchException {
        fetch(Method.Delete, path, null, null);
    }

    public List<Course> getCourseList(List<UUID> uuids) throws FetchException {
        var out = new ArrayList<Course>(uuids.size());
        for (var uuid : uuids)
            out.add(getCourse(uuid));
        return out;
    }

    public List<Message> getPostList(List<UUID> uuids) throws FetchException {
        var out = new ArrayList<Message>(uuids.size());
        for (var uuid : uuids)
            out.add(getPost(uuid));
        return out;
    }

    public List<User> getUserList(List<UUID> uuids) throws FetchException {
        var out = new ArrayList<User>(uuids.size());
        for (var uuid : uuids)
            out.add(getUser(uuid));
        return out;
    }

    public List<Forum> getForumList(List<UUID> uuids) throws FetchException {
        var out = new ArrayList<Forum>(uuids.size());
        for (var uuid : uuids)
            out.add(getForum(uuid));
        return out;
    }

    // Course

    public Course getCourse(UUID uuid) throws FetchException {
        return getSingle(path("courses", uuid.toString()), Course.class);
    }

    public List<Course> getAllCourses() throws FetchException {
        return getMultiple(path("courses"), Course.class);
    }

    public void deleteCourse(UUID uuid) throws FetchException {
        deleteSingle(path("courses", uuid.toString()));
    }

    public void createCourse(Course course) throws FetchException {
        postSingle(path("courses"), course);
    }

    public void updateCourse(Course course) throws FetchException {
        putSingle(path("courses", course.getUUID().toString()), course);
    }

    // User

    public List<User> getAllUsers() throws FetchException {
        return getMultiple(path("users"), User.class);
    }

    public User getUser(UUID uuid) throws FetchException {
        return getSingle(path("users", uuid.toString()), User.class);
    }

    public void createUser(User user) throws FetchException {
        postSingle(path("users"), user);
    }

    public void deleteUser(UUID user) throws FetchException {
        deleteSingle(path("users", user.toString()));
    }

    public void updateUser(User user) throws FetchException {
        putSingle(path("users", user.getUUID().toString()), user);
    }

    public UUID getCurrentUser() throws FetchException {
        return currentUser;
    }

    public void login(String username, String password) throws FetchException {
        var f = beginFetch();
        var out = f.out;
        var in = f.in;
        out.println("BEGIN_LOGIN");
        out.println("USERNAME\t" + username);
        // GigaSecurity Pro Max 2.0 (patent pending)
        out.println("PASSWORD\t" + password);
        out.println("END_LOGIN");

        // Receive the response
        if (!in.nextLine().equals("BEGIN_RESPONSE"))
            throw new FetchException("Invalid response");

        var replyHeader = in.nextLine().split("\t");

        if (!replyHeader[0].equals("OK")) {
            throw new FetchException(replyHeader[1]);
        }

        try {
            currentUser = UUID.fromString(in.nextLine());
            sessionId = UUID.fromString(in.nextLine());
        } catch (NumberFormatException e) {
            throw new FetchException(e.getMessage(), e);
        }

        if (!in.nextLine().equals("END_RESPONSE"))
            throw new FetchException("Invalid response");
    }

    // Post

    public Message getPost(UUID uuid) throws FetchException {
        return getSingle(path("posts", uuid.toString()), Message.class);
    }

    public void createPost(Message post) throws FetchException {
        postSingle(path("posts"), post);
    }

    public void updatePost(Message post) throws FetchException {
        putSingle(path("posts", post.getUUID().toString()), post);
    }

    public void deletePost(UUID post) throws FetchException {
        deleteSingle(path("posts", post.toString()));
    }

    // Forum

    public Forum getForum(UUID uuid) throws FetchException {
        return getSingle(path("forums", uuid.toString()), Forum.class);
    }

    public void createForum(Forum forum) throws FetchException {
        postSingle(path("forums"), forum);
    }

    public void updateForum(Forum forum) throws FetchException {
        putSingle(path("forums", forum.getUUID().toString()), forum);
    }

    public void deleteForum(UUID forum) throws FetchException {
        deleteSingle(path("forums", forum.toString()));
    }
}
