package cs180.client.database;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * Message Class - String representing post on forum or reply to post
 * Contains methods that can manipulate the message:
 *      change grade, change upvotes, add/remove comments, date created/edited, message contents
 * The Message class is tested in the CommandTest class.
 *
 * @author Ahmad Abdallah, Zachary Mayhew
 * @version November 13th, 2021
 *
 */
public class Message {
    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("MM/dd/YYYY HH:mm a z");
    private UUID uuid;
    private UUID postedBy;
    private UUID forum;
    private UUID parentPost;
    private List<UUID> comments;
    private List<UUID> usersUpvoted;
    private ZonedDateTime dateCreated;
    private ZonedDateTime dateLastEdited;
    private String title;
    private String messageContents;
    private int upvotes;
    private double grade;

    public Message() {
        this.uuid = null;
        this.postedBy = null;
        this.forum = null;
        this.parentPost = null;
        this.comments = null;
        this.usersUpvoted = null;
        this.dateCreated = null;
        this.dateLastEdited = null;
        this.title = null;
        this.messageContents = null;
        this.upvotes = 0;
        this.grade = 0.0;
    }

    public Message(UUID uuid, UUID postedBy, UUID forum, UUID parentPost, List<UUID> comments, List<UUID> usersUpvoted,
        ZonedDateTime dateCreated, ZonedDateTime dateLastEdited, String title, String messageContents, int upvotes,
        double grade) {
        this.uuid = uuid;
        this.postedBy = postedBy;
        this.forum = forum;
        this.parentPost = parentPost;
        this.comments = comments;
        this.usersUpvoted = usersUpvoted;
        this.dateCreated = dateCreated;
        this.dateLastEdited = dateLastEdited;
        this.title = title;
        this.messageContents = messageContents;
        this.upvotes = upvotes;
        this.grade = grade;
    }

    public Message(
        UUID postedBy, UUID forum, UUID parentPost, String title, String messageContents) {
        this.uuid = UUID.randomUUID();
        this.postedBy = postedBy;
        this.forum = forum;
        this.parentPost = parentPost;
        this.comments = new ArrayList<UUID>();
        this.usersUpvoted = new ArrayList<UUID>();
        this.dateCreated = ZonedDateTime.now();
        this.dateLastEdited = ZonedDateTime.now();
        this.title = title;
        this.messageContents = messageContents;
        this.upvotes = 0;
        this.grade = 0;
    }

    /**
     * Gets message UUID
     *
     * @return Forum UUID
     */
    public UUID getUUID() {
        return uuid;
    }

    /**
     * Gets UUID of user who posted the message
     *
     * @return User UUID
     */
    public UUID getPostedBy() {
        return postedBy;
    }

    /**
     * Gets UUID of forum message is located in
     *
     * @return Forum UUID
     */
    public UUID getForum() {
        return forum;
    }

    /**
     * Gets UUID of message's parent post
     *
     * @return Post UUID
     */
    public UUID getParentPost() {
        if (parentPost == null) {
            return null;
        }

        return parentPost;
    }

    /**
     * Gets UUID list of all comments on message
     *
     * @return UUID list of comments
     */
    public List<UUID> getComments() {
        return comments;
    }

    /**
     * Gets UUID list of all comments on message
     *
     * @return UUID list of users who voted on this message
     */
    public List<UUID> getUsersUpvoted() {
        return usersUpvoted;
    }

    /**
     * Get the zoned date time
     *
     * @return the zoned date time
     */
    public ZonedDateTime getZonedDateTime() {
        return dateCreated;
    }

    /**
     * Gets string of date message was created
     *
     * @return Date string
     */
    public String getDateCreated() {
        return DTF.format(dateCreated);
    }

    /**
     * Gets string of date message was last edited
     *
     * @return Date string
     */
    public String getDateLastEdited() {
        return DTF.format(dateLastEdited);
    }

    /**
     * Gets title of message
     *
     * @return Title string
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets message content
     *
     * @return Message content string
     */
    public String getMessageContents() {
        return messageContents;
    }

    /**
     * Gets upvotes given to message
     *
     * @return upvotes integer
     */
    public int getUpvotes() {
        return upvotes;
    }

    /**
     * Gets grade given to message
     *
     * @return Date string
     */
    public double getGrade() {
        return grade;
    }

    /**
     * Adds comment to comment list
     *
     * @param comment
     *            UUID for new comment
     */
    public void addComment(UUID comment) {
        Objects.requireNonNull(comment);

        comments.add(comment);
    }

    /**
     * Removes comment from comment list
     *
     * @param comment
     *            UUID for comment to remove
     */
    public void removeComment(UUID comment) {
        Objects.requireNonNull(comment);

        comments.remove(comment);
    }

    /**
     * Adds user to list of users who upvoted the message
     *
     * @param user
     *            UUID for user who upvoted post
     */
    public void addUserUpvoted(UUID user) {
        Objects.requireNonNull(user);

        usersUpvoted.add(user);
    }

    /**
     * Removes a user who upvoted on a post
     *
     * @param user
     *            UUID for user who upvoted post
     */
    public void removeUserUpvoted(UUID user) {
        Objects.requireNonNull(user);

        usersUpvoted.remove(user);
    }

    /**
     * Sets date last edited to current local time
     *
     */
    public void updateDateLastEdited() {
        dateLastEdited = ZonedDateTime.now();
    }

    /**
     * Sets title to provided title
     *
     * @param title
     *            String for new message title
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Sets message contents to provided text
     *
     * @param messageContents
     *            String for new message content
     */
    public void setMessageContents(String messageContents) {
        this.messageContents = messageContents;
    }

    /**
     * Sets upvotes to provided upvote int
     *
     * @param upvotes
     *            int value for new upvotes
     *
     */
    public void setUpvote(int upvotesParam) {
        this.upvotes = upvotesParam;
    }

    /**
     * Sets grade to provided grade
     *
     * @param grade
     *            Double value for new grade
     */
    public void setGrade(double grade) {
        this.grade = grade;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Message))
            return false;
        var message = (Message)o;
        return Objects.equals(uuid, message.uuid) && Objects.equals(postedBy, message.postedBy) &&
            Objects.equals(forum, message.forum) && Objects.equals(parentPost, message.parentPost) &&
            Arrays.equals(comments.toArray(), message.comments.toArray()) &&
            Objects.equals(usersUpvoted, message.usersUpvoted) && Objects.equals(dateCreated, message.dateCreated) &&
            Objects.equals(dateLastEdited, message.dateLastEdited) && Objects.equals(title, message.title) &&
            Objects.equals(messageContents, message.messageContents) && upvotes == message.upvotes &&
            grade == message.grade;
    }
}
