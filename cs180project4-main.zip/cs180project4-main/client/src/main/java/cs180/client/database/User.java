package cs180.client.database;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import cs180.serialize.SendOnly;

/**
 * User class
 * Contains methods that manipulate:
 * the kind of the user (teacher/student), courses they're enrolled in, messages
 * they've posted,
 * their unique attributes (username, fullname, password)
 * The User class is tested in the CommandTest class.
 *
 * @author Rachel La, Zachary Mayhew
 * @version November 6, 2021
 */

// clang-format off
public class User
{
    private UUID uuid;
    private String kind;
    private String username;
    private String fullName;
    @SendOnly
    private String password;
    private List<UUID> courses;
    private List<UUID> messages;

    public User()
    {
    }

    public User(String kind, String username, String password,
        String fullName)
    {
        this.uuid = UUID.randomUUID();
        this.kind = kind;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.courses = new ArrayList<>();
        this.messages = new ArrayList<>();
    }

    public User(UUID uuid, String kind, String username,
        String password, String fullName, List<UUID> courses,
        List<UUID> messages)
    {
        this.uuid = uuid;
        this.kind = kind;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.courses = courses;
        this.messages = messages;
    }

    /**
     * Returns the UUID of the user
     */
    public UUID getUUID()
    {
        return this.uuid;
    }

    /**
     * Returns the kind of the user (student or teacher)
     */
    public String getKind()
    {
        return this.kind;
    }

    /**
     * Sets the kind of the user to the kind given as a parameter
     *
     * @param kind
     */
    public void setKind(String kind)
    {
        this.kind = kind;
    }

    /**
     * Returns the username of the user
     */
    public String getUsername()
    {
        return this.username;
    }

    /**
     * Sets username of the user to the username given as a parameter
     *
     * @param username
     */
    public void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * Returns the full name of the user
     */
    public String getFullName()
    {
        return this.fullName;
    }

    /**
     * Sets full name of the user to the full name given as a parameter
     *
     * @param fullName
     */
    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    /**
     * Returns the password of the user
     */
    public String getPassword()
    {
        return this.password;
    }

    /**
     * Sets password of the user to the password given as a parameter
     *
     * @param password
     */
    public void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * Returns the list of courses the user enrolls in
     */
    public List<UUID> getCourses()
    {
        return this.courses;
    }

    /**
     * Adds new course to the current list of courses
     *
     * @param course
     */
    public void addCourse(UUID course)
    {
        courses.add(course);
    }

    /**
     * Removes course from the current list of courses
     *
     * @param course
     */
    public void removeCourse(UUID course)
    {
        courses.remove(course);
    }

    /**
     * Returns a list of messages the student posted
     */
    public List<UUID> getMessages()
    {
        return this.messages;
    }

    /**
     * Adds new message to the list of messages
     *
     * @param message
     */
    public void addMessage(UUID message)
    {
        messages.add(message);
    }

    /**
     * Removes message from the list of messages
     *
     * @param message
     */
    public void removeMessage(UUID message)
    {
        messages.remove(message);
    }

    @Override
    public boolean equals(Object o)
    {
        if (o == this)
            return true;
        if (!(o instanceof User))
            return false;
        // Ignore password
        var user = (User) o;
        return Objects.equals(uuid, user.uuid)
            && Objects.equals(kind, user.kind)
            && Objects.equals(username, user.username)
            && Objects.equals(fullName, user.fullName)
            && Arrays.equals(courses.toArray(),
                             user.courses.toArray())
            && Arrays.equals(messages.toArray(),
                             user.messages.toArray());
    }

}
// clang-format on