package cs180.client;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;

import cs180.client.ClientInterface.FetchException;
import cs180.client.database.Course;
import cs180.client.database.User;

/**
 * UserView - Lists all registered users in grid along with information
 * such as name, account type, and courses they are members of
 *
 * @author Ahmad Abdallah
 * @version November 27, 2021
 */

public class UserView extends JPanel
{
    // Num cols for user grid view
    private final static int NUM_COLS = 2;
    // String
    final static String ERROR_HEADER = "Server Error";
    // Color
    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");
    final static Color DELETE_RED = Color.decode("#FF1D07");

    // Client Interface
    ClientInterface ci;

    // Main Window for flipping cards
    MainWindow mainWindow;

    // Database info
    private User currentUser;
    private List<User> usersList;
    private List<Course> courseList;

    // Timer
    Timer updateTimer;

    // Icons
    BufferedImage iconImage;
    Image scaledIcon;

    public UserView(ClientInterface ci, MainWindow mainWindow)
    {
        this.ci = ci;

        this.mainWindow = mainWindow;

        updateTimer =
            new Timer(MainWindow.UPDATE_TIME, (e) -> {
                if (!mainWindow.checkCurrentUser())
                {
                    mainWindow.dispose();
                } else
                {
                    loadData();
                    removeAll();
                    createAndDisplayGUI();
                    revalidate();
                }
            });

        loadData();

        iconSetup();

        createAndDisplayGUI();

        startAutoUpdate();
    }

    public void createAndDisplayGUI()
    {
        // Overarching users panel
        setLayout(new GridLayout(0, NUM_COLS, 5, 5));
        setBackground(Color.BLACK);

        for (User userI : usersList)
        {
            // Initializing individual user panel
            JPanel userInfo = new JPanel();

            userInfo
                .setLayout(new BoxLayout(userInfo,
                                         BoxLayout.Y_AXIS));

            Border inner =
                new CompoundBorder(BorderFactory
                    .createLineBorder(Color
                        .decode("#C28E0E"), 5), BorderFactory
                            .createEmptyBorder(10, 10, 10,
                                               10));
            Border outer =
                new CompoundBorder(BorderFactory
                    .createLineBorder(Color.BLACK, 8), inner);

            userInfo.setBorder(outer);

            userInfo
                .setPreferredSize((new Dimension(300, 250)));

            // Adding user info to panel
            // Name of user
            JLabel name =
                new JLabel(String
                    .format("<html><b>%s</b></html>",
                            userI.getFullName()));
            name.setForeground((PUR_GOLD_NEON));
            name.setFont(new Font("Arial", Font.PLAIN, 20));
            name.setMaximumSize(new Dimension(300, 100));

            // Users username
            JLabel user =
                new JLabel(String
                    .format("<html><b>Username:</b> %s</html>",
                            userI.getUsername()));
            user.setForeground((PUR_GOLD_NEON));
            user.setFont(new Font("Arial", Font.PLAIN, 15));

            // User account kind
            JLabel kind =
                new JLabel(String
                    .format("<html><b>Role:</b> %s</html>",
                            userI.getKind()));
            kind.setForeground((PUR_GOLD_NEON));
            kind.setFont(new Font("Arial", Font.PLAIN, 15));

            // All courses user has joined
            String coursesStr = "";
            for (UUID curCourse : userI.getCourses())
            {
                if (!coursesStr.isEmpty())
                {
                    coursesStr += ", ";
                }

                // Getting course title and adding to string of user's courses
                for (Course c : courseList)
                {
                    if (c.getUUID().equals(curCourse))
                    {
                        coursesStr += c.getTitle();
                    }
                }
            }

            JLabel usersCourses =
                new JLabel(String
                    .format("<html><b>Courses:</b> %s</html>",
                            coursesStr));
            usersCourses.setForeground((PUR_GOLD_NEON));
            usersCourses
                .setFont(new Font("Arial", Font.PLAIN, 15));
            usersCourses
                .setMaximumSize(new Dimension(300, 250));

            // Open this user's messages
            JButton listPosts = new JButton("List Posts");
            listPosts.setForeground(PUR_GOLD_NEON);

            // Action listener for openUser button
            listPosts.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ae)
                {
                    if (ae.getSource() == listPosts)
                    {
                        mainWindow.showUserPostList(userI
                            .getUUID());
                    }
                }
            });

            // Delete user button for teachers
            JButton deleteUser = new JButton("Delete");
            deleteUser.setForeground(DELETE_RED);

            // Action listener for delete button
            deleteUser.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ae)
                {
                    if (ae.getSource() == deleteUser)
                    {
                        Object confirmation =
                            JOptionPane
                                .showOptionDialog(null,
                                                  "Are you sure you want to delete this user?",
                                                  "Delete",
                                                  JOptionPane.YES_NO_OPTION,
                                                  JOptionPane.QUESTION_MESSAGE,
                                                  new ImageIcon(scaledIcon),
                                                  null, null);

                        int checkedConfirmation =
                            nullCheck(confirmation);
                        if (checkedConfirmation
                            == JOptionPane.YES_OPTION)
                        {
                            deleteUser(userI);
                            remove(userInfo);
                            repaint();
                            revalidate();
                        }
                    }
                }
            });

            if (currentUser.getKind()
                .equalsIgnoreCase("student")
                || currentUser.getUUID()
                    .equals(userI.getUUID()))
            {
                deleteUser.setEnabled(false);
            }

            // Adding components to individual user panel
            userInfo.add(name);
            userInfo.add(user);
            userInfo.add(kind);
            userInfo.add(usersCourses);
            userInfo.add(listPosts);
            userInfo.add(deleteUser);

            userInfo.setVisible(true);

            // Adding individual user panel to overarching panel
            add(userInfo);
        }

        setVisible(true);

    }

    /**
     * Removes userToDelete from server databse
     *
     * @param userToDelete
     *            The user requested to delete
     */
    private void deleteUser(User userToDelete)
    {
        try
        {
            ci.deleteUser(userToDelete.getUUID());
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "There Was an Issue with Deleting this User",
                                   ERROR_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * Checks if parameter is null, if not casts it to an int
     *
     * @param checkThis
     * @return Int version of object, -1 if object was null
     */
    private int nullCheck(Object checkThis)
    {
        if (checkThis == null)
        {
            return -1;
        }

        return (int) checkThis;
    }

    /**
     * Loads user, current user, and course data from server
     */
    public void loadData()
    {
        try
        {
            usersList = ci.getAllUsers();

            courseList = ci.getAllCourses();

            currentUser = ci.getUser(ci.getCurrentUser());
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error Loading Information",
                                   ERROR_HEADER,
                                   JOptionPane.ERROR_MESSAGE);

            fe.printStackTrace();
        }
    }

    /**
     * Initializes scaled icon
     */
    private void iconSetup()
    {
        try
        {
            iconImage =
                ImageIO.read(getClass().getClassLoader()
                    .getResourceAsStream("purdueLogo.png"));

        } catch (IOException e)
        {
            System.out.println("Failed to load icons");
            e.printStackTrace();
        }
        scaledIcon =
            iconImage.getScaledInstance(64, 64,
                                        Image.SCALE_SMOOTH);

    }

    /**
     * Updates information from server every 10 seconds and refreshes UI
     */
    public void startAutoUpdate()
    {
        updateTimer.start();
    }

    /**
     * Pauses information transfer and UI updates
     */
    public void pauseAutoUpdate()
    {
        updateTimer.stop();
    }

}
