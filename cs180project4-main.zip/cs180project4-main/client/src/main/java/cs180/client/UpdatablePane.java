/**
 * UpdatablePane - Methods required for specific views (CourseList, ForumList,
 * PostList, Post)
 *
 * @author Ahmad Abdallah
 * @version December 5, 2021
 */

package cs180.client;

import java.util.UUID;

/**
 * Updatable Pane - An interface for update feature related methods
 * 
 * @author Ahmad Abdallah
 * @version December 11, 2021
 */

public interface UpdatablePane
{
    void startAutoUpdate();

    void pauseAutoUpdate();

    void updateGUI(UUID thingToUpdate);
}
