package cs180.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.UUID;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.Timer;

import cs180.client.ClientInterface.FetchException;
import cs180.client.database.Forum;
import cs180.client.database.User;

/**
 * ForumListView class
 *
 * Contains list of forums in the course
 * Allows teacher to create, edit, and delete forums
 * Contains a post button which opens post list view
 *
 * @author Rachel La, Zachary Mayhew, Ahmad Abdallah
 * @version December 2, 2021
 */
// clang-format off
public class ForumListView extends JPanel
    implements UpdatablePane
{
    private ClientInterface app;

    private User currentUser;
    private UUID currentCourse;
    private Timer updateTimer;

    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");

    private MainWindow window;

    public ForumListView(ClientInterface app,
        MainWindow window)
    {
        try
        {
            this.app = app;
            var uid = app.getCurrentUser();
            currentUser = app.getUser(uid);
            this.window = window;
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error connecting to app",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
        }
        updateTimer = new Timer(window.UPDATE_TIME, (e) -> {
            try
            {
                if (!window.checkCurrentUser())
                {
                    window.dispose();
                } else
                {
                    createAndDisplayGUI();
                }
            } catch (FetchException e1)
            {
                e1.printStackTrace();
            }
        });
    }

    /**
     * Pops up a window for user to create new forum
     * 
     * @return the title of the new forum
     */
    public void createForum()
    {
        String input;
        Forum createdForum;

        do
        {
            input =
                JOptionPane
                    .showInputDialog(null, "Enter Forum Name",
                                     "Create Forum",
                                     JOptionPane.QUESTION_MESSAGE);

            if (input == null)
            {
                return;
            } else if (input.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Please Enter A Valid Forum Name",
                                       "Create Forum",
                                       JOptionPane.ERROR_MESSAGE);
            }

        }
        while (input.isEmpty());

        createdForum = new Forum(currentCourse, input);

        try
        {
            app.createForum(createdForum);
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error Connecting to Server",
                                   "Server Error",
                                   JOptionPane.ERROR_MESSAGE);
        }

        try
        {
            createAndDisplayGUI();
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error Updating Interfacce",
                                   "UI Error",
                                   JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Creates a new forum using given parameter
     * 
     * @param forum
     */
    public void create(String forum)
    {
        Forum newForum =
            new Forum(UUID.randomUUID(), currentCourse, null,
                      forum);
        try
        {
            app.createForum(newForum);
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "An error occurs. Please try again",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    /**
     * Asks the user for new forum name
     * 
     * @return the new forum name
     */
    public String getNewForumName()
    {
        String newForumName;
        do
        {
            newForumName =
                JOptionPane
                    .showInputDialog(null,
                                     "Enter New Forum Name",
                                     "Rename Forum",
                                     JOptionPane.QUESTION_MESSAGE);
            if (newForumName == null)
            {
                return null;
            }
            if (newForumName.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Please Enter New Forum Name",
                                       "Error",
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (newForumName.isEmpty());
        return newForumName;
    }

    /**
     * Rename the forum using given parameters
     * 
     * @param forumToRename
     */
    public void edit(Forum forumToRename)
    {
        String newName = "";

        do
        {
            newName =
                JOptionPane
                    .showInputDialog(this,
                                     "Enter new Forum Name",
                                     "Rename Forum",
                                     JOptionPane.QUESTION_MESSAGE);

            if (newName == null)
            {
                return;
            } else if (newName.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Please Enter a Valid Forum Name",
                                       "Rename Forum",
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (newName.isEmpty());

        forumToRename.setForumTopic(newName);
        try
        {
            app.updateForum(forumToRename);
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null, fe.getMessage(),
                                   "Server Error",
                                   JOptionPane.ERROR_MESSAGE);
        }

        try
        {
            createAndDisplayGUI();
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error Updating Interface",
                                   "UI Error",
                                   JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * Deletes forum from course
     * 
     * @param
     */
    public void deleteForum(Forum f)
    {
        try
        {
            app.deleteForum(f.getUUID());
            createAndDisplayGUI();
        } catch (ClientInterface.FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "An error occurs. Please try again",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public void createAndDisplayGUI() throws FetchException
    {
        removeAll();
        setLayout(new BorderLayout());

        JPanel forumsPanel = new JPanel();
        forumsPanel
            .setLayout(new BoxLayout(forumsPanel,
                                     BoxLayout.Y_AXIS));
        forumsPanel.setBorder(BorderFactory
            .createCompoundBorder(BorderFactory
                .createEmptyBorder(0, 0, 0, 0),
                                  BorderFactory
                                      .createLineBorder(PUR_GOLD_NEON,
                                                        5)));

        var course = app.getCourse(currentCourse);
        var forums = app.getForumList(course.getForum());

        // Creates button for every forum
        for (Forum forum : forums)
        {
            JPanel forumPanel = new JPanel();

            var topic =
                new JLabel(String
                    .format("<html><b>%s</b></html>",
                            forum.getForumTopic()));
            topic.setFont(new Font("Arial", Font.BOLD, 13));

            forumPanel.add(topic);

            var openButton = new JButton("Open");
            openButton.addActionListener((e) -> window
                .showPostList(forum.getUUID()));
            openButton.setForeground(PUR_GOLD_NEON);
            forumPanel.add(openButton);

            var editButton = new JButton("Edit");
            editButton.addActionListener((e) -> edit(forum));
            editButton.setForeground(PUR_GOLD_NEON);
            forumPanel.add(editButton);

            if (currentUser.getKind()
                .equalsIgnoreCase("teacher"))
            {
                var deleteButton = new JButton("Delete");
                deleteButton.setForeground(PUR_GOLD_NEON);
                deleteButton
                    .addActionListener((e) -> deleteForum(forum));
                forumPanel.add(deleteButton);
            } else
            {
                editButton.setEnabled(false);
            }

            forumPanel.setMaximumSize(new Dimension(500, 50));

            forumsPanel.add(forumPanel);
        }

        var scroller = new JScrollPane(forumsPanel);

        var topBar = new JPanel();

        var courseName = new JLabel(course.getTitle());
        courseName.setFont(new Font("Arial", Font.BOLD, 18));
        courseName.setForeground(PUR_GOLD_NEON);
        var createButton = new JButton("Create Forum");
        createButton.setForeground(PUR_GOLD_NEON);
        createButton.addActionListener((e) -> createForum());

        if (!currentUser.getKind()
            .equalsIgnoreCase("teacher"))
        {
            createButton.setEnabled(false);
        }

        topBar.setBackground(Color.BLACK);
        topBar.add(courseName);
        topBar.add(createButton);
        topBar.setBorder(BorderFactory
            .createCompoundBorder(BorderFactory
                .createEmptyBorder(0, 0, 0, 0),
                                  BorderFactory
                                      .createLineBorder(PUR_GOLD_NEON,
                                                        3)));

        add(topBar, BorderLayout.NORTH);
        add(scroller, BorderLayout.CENTER);

        setVisible(true);
        revalidate();
    }

    @Override
    public void startAutoUpdate()
    {
        updateTimer.start();
    }

    @Override
    public void pauseAutoUpdate()
    {
        updateTimer.stop();

    }

    @Override
    public void updateGUI(UUID course)
    {
        currentCourse = course;
        try
        {
            createAndDisplayGUI();
        } catch (FetchException e)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "An error occurs. Please try again",
                                   "Error",
                                   JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
// clang-format on
