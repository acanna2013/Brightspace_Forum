package cs180.client;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import cs180.client.ClientInterface.FetchException;

/**
 * MainWindow Class - The overall window containing all other views
 *
 * @author Ahmad Abdallah
 * @version November 23th, 2021
 */

public class MainWindow extends JFrame implements Runnable
{
    // Button Commands
    final static String USERS = "users";
    final static String COURSES = "courses";
    final static String FORUMS = "forums";
    final static String POST_LIST = "post list";
    final static String USER_POST_LIST = "user post list";
    final static String POST = "post";
    final static String ACCOUNT = "account";
    final static String LOGOUT = "logout";
    // Color
    final static Color PUR_GOLD_DRAB =
        Color.decode("#CEB888");
    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");
    // Update time
    final static int UPDATE_TIME = 45000;

    // JPanels
    UserView userV;
    CourseListView courseListV;
    ForumListView forumListV;
    PostListView postListV;
    PostListView userPostListV;
    AccountView accountV;

    // Client Interface
    ClientInterface ci;

    // Card layout
    JPanel cards;

    // Buttons
    JButton usersButton;
    JButton courseButton;
    JButton accountButton;
    JButton logoutButton;

    // Icon image
    BufferedImage iconImage;
    Image scaledIcon;

    public MainWindow(ClientInterface ci)
    {
        userV = new UserView(ci, this);
        accountV = new AccountView(ci, this);
        courseListV = new CourseListView(ci, this);
        forumListV = new ForumListView(ci, this);
        postListV = new PostListView(true, ci, this);
        userPostListV = new PostListView(false, ci, this);

        this.ci = ci;
        iconSetup();
    }

    public void run()
    {
        JPanel navBar = new JPanel();
        cards = new JPanel(new CardLayout());

        getContentPane().setLayout(new BorderLayout());

        getContentPane().add(navBar, BorderLayout.NORTH);

        /**
         * A class which controls the action listener for the main window
         *
         */
        class ControlActionListener implements ActionListener
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CardLayout cl =
                    (CardLayout) (cards.getLayout());
                String cmd = e.getActionCommand();

                if (cmd.equals(USERS))
                {
                    // Ensure any info updated on account page is reflected
                    // instantly
                    allocateUpdate(userV);

                    cl.show(cards, USERS);

                    userV.loadData();
                    userV.removeAll();
                    userV.createAndDisplayGUI();
                    userV.revalidate();

                    resetButtonColors();
                    usersButton.setForeground(Color
                        .decode("#C28E0E"));

                } else if (cmd.equals(COURSES))
                {
                    allocateUpdate(courseListV);

                    cl.show(cards, COURSES);

                    resetButtonColors();
                    courseButton.setForeground(Color
                        .decode("#C28E0E"));
                } else if (cmd.equals(ACCOUNT))
                {
                    allocateUpdate(accountV);

                    cl.show(cards, ACCOUNT);

                    resetButtonColors();
                    accountButton.setForeground(Color
                        .decode("#C28E0E"));
                } else if (cmd.equals(LOGOUT))
                {
                    dispose();
                }
            }
        }

        ControlActionListener actionListener =
            new ControlActionListener();

        // Button initialization
        usersButton =
            new JButton("<html><b>Users</b></html>");

        usersButton.setForeground(PUR_GOLD_NEON);
        usersButton
            .setFont(new Font("Arial", Font.PLAIN, 20));
        usersButton.addActionListener(actionListener);
        usersButton.setActionCommand(USERS);
        usersButton.setBorderPainted(false);

        courseButton =
            new JButton("<html><b>Courses</b></html>");
        courseButton.setForeground(PUR_GOLD_DRAB);
        courseButton
            .setFont(new Font("Arial", Font.PLAIN, 20));
        courseButton.addActionListener(actionListener);
        courseButton.setActionCommand(COURSES);
        courseButton.setBorderPainted(false);

        accountButton =
            new JButton("<html><b>Account</b></html>");
        accountButton.addActionListener(actionListener);
        accountButton
            .setFont(new Font("Arial", Font.PLAIN, 20));
        accountButton.setForeground(PUR_GOLD_DRAB);
        accountButton.setActionCommand(ACCOUNT);
        accountButton.setBorderPainted(false);

        logoutButton =
            new JButton("<html><b>Logout</b></html>");
        logoutButton.setForeground(PUR_GOLD_DRAB);
        logoutButton
            .setFont(new Font("Arial", Font.PLAIN, 20));
        logoutButton.addActionListener(actionListener);
        logoutButton.setActionCommand(LOGOUT);
        logoutButton.setBorderPainted(false);

        JLabel iconLabel =
            new JLabel(new ImageIcon(scaledIcon));
        navBar.add(iconLabel);

        // Adding JPanels to cards for transitions
        cards.add(new JScrollPane(userV), USERS);
        cards.add(accountV, ACCOUNT);
        cards.add(courseListV, COURSES);
        cards.add(forumListV, FORUMS);
        cards.add(postListV, POST_LIST);
        cards.add(userPostListV, USER_POST_LIST);

        // Adding buttons to top panel
        navBar.add(usersButton);
        navBar.add(courseButton);
        navBar.add(accountButton);
        navBar.add(logoutButton);

        // Formatting top panel
        navBar.setLayout(new FlowLayout(FlowLayout.LEFT));
        navBar.setBackground(Color.BLACK);
        navBar.setBorder(BorderFactory
            .createLineBorder(PUR_GOLD_NEON, 5));

        // Formatting frame
        add(cards);
        setBackground(Color.white);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    /**
     *
     * Resets all buttons to color indicating this view isn't currently selected
     *
     */
    public void resetButtonColors()
    {
        usersButton.setForeground(PUR_GOLD_DRAB);
        courseButton.setForeground(PUR_GOLD_DRAB);
        accountButton.setForeground(PUR_GOLD_DRAB);
    }

    /**
     * Initializes scaled icon
     */
    private void iconSetup()
    {
        try
        {
            iconImage =
                ImageIO.read(getClass().getClassLoader()
                    .getResourceAsStream("purdueLogo.png"));

        } catch (IOException e)
        {
            System.out.println("Failed to load icons");
            e.printStackTrace();
        }
        scaledIcon =
            iconImage.getScaledInstance(64, 64,
                                        Image.SCALE_SMOOTH);

    }

    /**
     * All other panels stop updating UI to prevent conflict
     *
     * @param panelToUpdate
     *            Panel to continue updating UI
     */
    private void allocateUpdate(JPanel panelToUpdate)
    {
        if (panelToUpdate.equals(userV))
        {
            // Start this one
            userV.startAutoUpdate();

            // Pause all others
            accountV.pauseAutoUpdate();
            courseListV.pauseAutoUpdate();
            forumListV.pauseAutoUpdate();
            postListV.pauseAutoUpdate();
            userPostListV.pauseAutoUpdate();
        } else if (panelToUpdate.equals(accountV))
        {
            // Start this one
            accountV.startAutoUpdate();

            // Pause all others
            userV.pauseAutoUpdate();
            courseListV.pauseAutoUpdate();
            forumListV.pauseAutoUpdate();
            postListV.pauseAutoUpdate();
            userPostListV.pauseAutoUpdate();
        } else if (panelToUpdate.equals(courseListV))
        {
            // Start this one
            courseListV.startAutoUpdate();

            // Pause all others
            userV.pauseAutoUpdate();
            accountV.pauseAutoUpdate();
            forumListV.pauseAutoUpdate();
            postListV.pauseAutoUpdate();
            userPostListV.pauseAutoUpdate();
        } else if (panelToUpdate.equals(forumListV))
        {
            // Start this one
            forumListV.startAutoUpdate();

            // Pause all others
            userV.pauseAutoUpdate();
            accountV.pauseAutoUpdate();
            courseListV.pauseAutoUpdate();
            postListV.pauseAutoUpdate();
            userPostListV.pauseAutoUpdate();
        } else if (panelToUpdate.equals(postListV))
        {
            // Start this one
            postListV.startAutoUpdate();

            // Pause all others
            userV.pauseAutoUpdate();
            accountV.pauseAutoUpdate();
            courseListV.pauseAutoUpdate();
            forumListV.pauseAutoUpdate();
            userPostListV.pauseAutoUpdate();
        } else if (panelToUpdate.equals(userPostListV))
        {
            // Start this one
            userPostListV.startAutoUpdate();

            // Pause all others
            userV.pauseAutoUpdate();
            accountV.pauseAutoUpdate();
            courseListV.pauseAutoUpdate();
            forumListV.pauseAutoUpdate();
            postListV.pauseAutoUpdate();
        }
    }

    /**
     * Displays JPanel for specific course/forum list
     *
     * @param course
     *            The course whose forum list will be displayed
     */
    public void showForumList(UUID course)
    {
        CardLayout cl = (CardLayout) (cards.getLayout());

        cl.show(cards, FORUMS);
        forumListV.updateGUI(course);
        allocateUpdate(forumListV);
    }

    /**
     * Checks server to ensure current user's account exists
     */
    public boolean checkCurrentUser()
    {
        try
        {
            ci.getUser(ci.getCurrentUser());

            return true;
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Your Account Has Been Terminated",
                                   "Account Error",
                                   JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    /**
     * Displays JPanel for forum/post list
     *
     * @param forum
     *            The forum whose posts will be displayed
     */
    public void showPostList(UUID forum)
    {
        CardLayout cl = (CardLayout) (cards.getLayout());

        cl.show(cards, POST_LIST);
        System.out.println("NORMAL POSTS BEING UPDATED");
        postListV.updateGUI(forum);
        allocateUpdate(postListV);
    }

    /**
     * Displays JPanel listing specific user's post list
     *
     * @param user
     *            The user whose post list will be displayed
     */
    public void showUserPostList(UUID user)
    {
        CardLayout cl = (CardLayout) (cards.getLayout());

        cl.show(cards, USER_POST_LIST);
        System.out.println("USER POSTS BEING UPDATED");
        userPostListV.updateGUI(user);
        allocateUpdate(userPostListV);
    }

}
