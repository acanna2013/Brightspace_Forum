package cs180.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;

import cs180.client.ClientInterface.FetchException;
import cs180.client.database.User;

/**
 * LoginView - GUI login screen, also provides functionality to create account
 *
 * @author Ahmad Abdallah
 * @version November 25, 2021
 */

public class LoginView extends JFrame implements Runnable
{
    // Color
    final static Color PUR_GOLD_DRAB =
        Color.decode("#CEB888");
    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");
    // Strings
    final static String CREATE_ACC_HEADER = "Create Account";
    final static String ERROR_HEADER = "Server Error";

    // Client Interface
    ClientInterface ci;

    // Database info
    List<User> usersList;

    // Buttons
    JButton loginButton;
    JButton createAccountButton;

    // Text fields
    JTextField userField;
    JPasswordField passField;

    // Checkbox
    JCheckBox showPassBox;

    // Keystroke
    KeyStroke enter =
        KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);

    // Icons
    BufferedImage iconImage;
    Image scaledIcon;

    // Server stuff
    String host;
    String port;
    int tryAgain;
    static boolean successfulConnection;
    static boolean successfulAccountCreation;

    // Input
    private User createdAccount;
    private String createName;
    private String createUsername;
    private String createPassword;
    private String createKind;
    private String passCheck;
    private String loginUserText;
    private String loginPassText;

    // JOptionPane button labels
    private static String[] accountTypes =
        {"Teacher", "Student"};

    public LoginView()
    {
        iconSetup();

        successfulConnection = getServerInfo();

        // Uncomment lines below and comment line above if you get tired of
        // entering host/port (and vice versa)

        // bypassHostPortQuestion();
        // successfulConnection = true;

        if (successfulConnection)
        {
            loadData();

            autoUpdate();
        }
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new LoginView());
    }

    public void run()
    {
        JPanel textFields = new JPanel();
        JPanel buttonPanel = new JPanel();
        setLayout(new BoxLayout(getContentPane(),
                                BoxLayout.Y_AXIS));

        /**
         * A class which controls the action listener for the login view
         *
         */
        class ControlActionListener implements ActionListener
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == createAccountButton)
                {
                    successfulAccountCreation =
                        createAccount();

                    // Ensure user successfully entered all fields
                    if (successfulAccountCreation)
                    {

                        // Assembling collected info into user
                        createdAccount =
                            new User(UUID.randomUUID(),
                                     createKind,
                                     createUsername,
                                     createPassword,
                                     createName,
                                     new ArrayList<UUID>(),
                                     new ArrayList<UUID>());

                        // Registering user with server
                        try
                        {
                            ci.createUser(createdAccount);

                            // Success pane
                            JOptionPane
                                .showMessageDialog(null,
                                                   "Account Creation Successful!",
                                                   CREATE_ACC_HEADER,
                                                   JOptionPane.ERROR_MESSAGE,
                                                   new ImageIcon(scaledIcon));

                            userField.setText(createdAccount
                                .getUsername());
                            passField.setText(createdAccount
                                .getPassword());

                            attemptLogin();

                        } catch (FetchException fe)
                        {
                            JOptionPane
                                .showMessageDialog(null,
                                                   "There was an issue creating your account",
                                                   CREATE_ACC_HEADER,
                                                   JOptionPane.ERROR_MESSAGE);
                        }
                    }

                }

            }
        }

        ControlActionListener actionListener =
            new ControlActionListener();

        // Login Components
        JLabel title =
            new JLabel("<html><b>Brightspace++</b></html>");
        title.setForeground((PUR_GOLD_NEON));
        title.setFont(new Font("Arial", Font.PLAIN, 24));
        title.setBorder(new CompoundBorder(BorderFactory
            .createMatteBorder(0, 0, 1, 0, Color
                .decode("#C28E0E")), BorderFactory
                    .createEmptyBorder(0, 0, 10, 0)));

        JLabel userLabel =
            new JLabel("<html><b>Username</b></html>");
        userLabel.setForeground((PUR_GOLD_DRAB));
        userLabel.setFont(new Font("Arial", Font.PLAIN, 20));

        JLabel passwordLabel =
            new JLabel("<html><b>Password</b></html>");
        passwordLabel.setForeground((PUR_GOLD_DRAB));
        passwordLabel
            .setFont(new Font("Arial", Font.PLAIN, 20));

        userField = new JTextField();
        userField.setMaximumSize(new Dimension(500, 30));

        passField = new JPasswordField();
        passField.setMaximumSize(new Dimension(500, 30));

        showPassBox =
            new JCheckBox("<html><b>Show Password</b></html>");
        showPassBox.setForeground((PUR_GOLD_DRAB));
        showPassBox
            .setFont(new Font("Arial", Font.PLAIN, 15));
        showPassBox.addItemListener(new ItemListener()
        {
            public void itemStateChanged(ItemEvent e)
            {
                if (e.getStateChange() == ItemEvent.SELECTED)
                {
                    passField.setEchoChar((char) 0);
                } else
                {
                    passField.setEchoChar('\u2022');
                }

            }
        });

        loginButton =
            new JButton("<html><b>Login</b></html>");
        loginButton
            .setFont(new Font("Arial", Font.PLAIN, 15));
        loginButton.setForeground(PUR_GOLD_NEON);

        // Components allowing login button to enter key
        loginButton
            .getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
            .put(enter, "Enter");

        Action action = new AbstractAction()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                attemptLogin();
                resetKeyBindings(enter, getContentPane());

            }
        };

        loginButton.getActionMap().put("Enter", action);
        loginButton.addActionListener(action);

        createAccountButton =
            new JButton("<html><b>Create Account</b></html>");
        createAccountButton
            .setFont(new Font("Arial", Font.PLAIN, 15));
        createAccountButton.setForeground(PUR_GOLD_NEON);
        createAccountButton.addActionListener(actionListener);

        // Adding components to JPanels
        buttonPanel.add(loginButton);
        buttonPanel.add(createAccountButton);

        textFields.add(title);

        textFields.add(userLabel);
        textFields.add(userField);

        textFields.add(passwordLabel);
        textFields.add(passField);
        textFields.add(showPassBox);

        textFields.add(buttonPanel);

        // Formatting button panel
        buttonPanel.setBackground(Color.BLACK);
        buttonPanel.setBorder(BorderFactory
            .createEmptyBorder(15, 30, 15, 30));
        buttonPanel
            .setLayout(new BoxLayout(buttonPanel,
                                     BoxLayout.X_AXIS));
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Formatting textField JPanel
        textFields.setBackground(Color.BLACK);
        textFields
            .setBorder(new CompoundBorder(BorderFactory
                .createLineBorder(PUR_GOLD_NEON, 5),
                                          BorderFactory
                                              .createEmptyBorder(10,
                                                                 10,
                                                                 10,
                                                                 10)));
        textFields.setLayout(new BoxLayout(textFields,
                                           BoxLayout.Y_AXIS));
        textFields.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Formatting login view
        add(textFields, BorderLayout.CENTER);
        setBackground(Color.BLACK);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();

        if (!successfulConnection)
        {
            dispose();
        } else
        {
            setVisible(true);
        }

    }

    /**
     * Gets host name and port number from user
     */
    private boolean getServerInfo()
    {
        Object input;

        do
        {
            host = null;
            port = null;

            do
            {
                input =
                    JOptionPane
                        .showInputDialog(this,
                                         "Enter Host Name",
                                         CREATE_ACC_HEADER,
                                         JOptionPane.QUESTION_MESSAGE,
                                         new ImageIcon(scaledIcon),
                                         null, null);
                host = nullCheckString(input);

                if (host == null)
                {
                    break;
                }
                if (host.isEmpty())
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           "Please Enter a Valid Host Name",
                                           CREATE_ACC_HEADER,
                                           JOptionPane.ERROR_MESSAGE);

                }

            }
            while (host.isEmpty());

            if (host != null)
            {
                do
                {
                    input =
                        JOptionPane
                            .showInputDialog(this,
                                             "Enter Port Number",
                                             CREATE_ACC_HEADER,
                                             JOptionPane.QUESTION_MESSAGE,
                                             new ImageIcon(scaledIcon),
                                             null, null);

                    port = nullCheckString(input);

                    if (port == null)
                    {
                        break;
                    }
                    if (port.isEmpty())
                    {
                        JOptionPane
                            .showMessageDialog(null,
                                               "Please Enter a Valid Port Number",
                                               CREATE_ACC_HEADER,
                                               JOptionPane.ERROR_MESSAGE);
                        continue;
                    }

                    try
                    {
                        Integer.valueOf(port);
                    } catch (IllegalArgumentException iae)
                    {
                        JOptionPane
                            .showMessageDialog(null,
                                               "Please Enter a Valid Port Number",
                                               CREATE_ACC_HEADER,
                                               JOptionPane.ERROR_MESSAGE);
                        continue;
                    }

                    break;

                }
                while (true);
            }

            try
            {
                if (port == null)
                {
                    ci = new ClientInterface(host, 1);
                } else
                {
                    ci =
                        new ClientInterface(host, Integer
                            .valueOf(port));
                }

                return true;

            } catch (FetchException fe)
            {
                input =
                    JOptionPane
                        .showOptionDialog(this,
                                          "Connection Failed. Would you like to try again?",
                                          CREATE_ACC_HEADER,
                                          JOptionPane.YES_NO_OPTION,
                                          JOptionPane.QUESTION_MESSAGE,
                                          new ImageIcon(scaledIcon),
                                          null, null);
                tryAgain = nullCheckInt(input);
            }

        }
        while (tryAgain == JOptionPane.YES_OPTION);

        return false;
    }

    /**
     * Obtains information from user to initialize account
     */
    private boolean createAccount()
    {
        Object input;
        boolean usernameAlreadyUsed;

        // Obtaining name of user
        do
        {
            input =
                JOptionPane
                    .showInputDialog(this, "Enter Full Name",
                                     CREATE_ACC_HEADER,
                                     JOptionPane.QUESTION_MESSAGE,
                                     new ImageIcon(scaledIcon),
                                     null, null);
            createName = nullCheckString(input);
            if (createName == null)
            {
                return false;
            } else if (createName.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Please Enter a Valid Name",
                                       CREATE_ACC_HEADER,
                                       JOptionPane.ERROR_MESSAGE);
            }

        }
        while (createName.isEmpty());

        // Obtaining Teacher/Student Designation
        input =
            JOptionPane
                .showOptionDialog(this, "Choose Account Type",
                                  CREATE_ACC_HEADER,
                                  JOptionPane.YES_NO_OPTION,
                                  JOptionPane.QUESTION_MESSAGE,
                                  new ImageIcon(scaledIcon),
                                  accountTypes, null);
        if ((int) input == -1)
        {
            return false;
        } else
        {
            createKind = accountTypes[(int) input];
        }

        // Obtaining username
        do
        {

            input =
                JOptionPane
                    .showInputDialog(this, "Enter Username",
                                     CREATE_ACC_HEADER,
                                     JOptionPane.QUESTION_MESSAGE,
                                     new ImageIcon(scaledIcon),
                                     null, null);

            createUsername = nullCheckString(input);

            if (createUsername == null)
            {
                return false;
            } else if (createUsername.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Please Enter a Valid Username",
                                       CREATE_ACC_HEADER,
                                       JOptionPane.ERROR_MESSAGE);
            }

            usernameAlreadyUsed =
                usernameExists(createUsername);

            if (usernameAlreadyUsed)
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "This Username is Taken",
                                       CREATE_ACC_HEADER,
                                       JOptionPane.ERROR_MESSAGE);
            }

        }
        while (createUsername.isEmpty()
            || usernameAlreadyUsed);

        // Obtaining password
        do
        {
            do
            {
                input =
                    JOptionPane
                        .showInputDialog(this,
                                         "Enter Password",
                                         CREATE_ACC_HEADER,
                                         JOptionPane.QUESTION_MESSAGE,
                                         new ImageIcon(scaledIcon),
                                         null, null);
                createPassword = nullCheckString(input);

                if (createPassword == null)
                {
                    return false;
                } else if (createPassword.isEmpty())
                {
                    JOptionPane
                        .showMessageDialog(null,
                                           "Please Enter a Valid Password",
                                           CREATE_ACC_HEADER,
                                           JOptionPane.ERROR_MESSAGE);
                }
            }
            while (createPassword.isEmpty());

            // Confirming password
            input =
                JOptionPane
                    .showInputDialog(this, "Reenter Password",
                                     CREATE_ACC_HEADER,
                                     JOptionPane.QUESTION_MESSAGE,
                                     new ImageIcon(scaledIcon),
                                     null, null);
            passCheck = nullCheckString(input);

            if (passCheck == null)
            {
                return false;
            }
            if (!createPassword.equals(passCheck))
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Your passwords didn't match. Try again.",
                                       CREATE_ACC_HEADER,
                                       JOptionPane.ERROR_MESSAGE);

            }
        }
        while (!createPassword.equals(passCheck));

        return true;
    }

    /**
     * Logs in using text in username and password field
     *
     */
    private void attemptLogin()
    {
        // Obtain entered login info from fields
        loginUserText = userField.getText();
        loginPassText =
            String.valueOf(passField.getPassword());

        // Checks to make sure user has entered text in both fields
        if (loginUserText.isEmpty()
            || loginPassText.isEmpty())
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Please Provide Both Username and Password",
                                   CREATE_ACC_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
        } else
        {
            // Login with client interface
            try
            {
                ci.login(loginUserText, loginPassText);
                dispose();
                SwingUtilities
                    .invokeLater(new MainWindow(ci));
            } catch (FetchException fe)
            {
                JOptionPane
                    .showMessageDialog(null,
                                       "Incorrect Username or Password",
                                       CREATE_ACC_HEADER,
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Removes key bindings from provided keystroke. Adopted from
     * from Kedar's GUI Handbook
     * 
     * @param ks
     *            Keystroke to clear
     * @param comp
     *            Container of JFrame
     */
    private static void resetKeyBindings(KeyStroke ks,
                                         Container comp)
    {

        JPanel cp = ((JPanel) comp);

        ActionMap aMap = cp.getActionMap();

        InputMap inMap = cp.getInputMap();

        inMap.put(ks, null);

        aMap.put(ks, null);
    }

    /**
     * Checks if parameter is null, if not casts it to a string
     *
     * @param checkThis
     * @return String version of object, null if object was null
     */
    private String nullCheckString(Object checkThis)
    {
        if (checkThis == null)
        {
            return null;
        }

        return checkThis.toString();
    }

    /**
     * Checks if parameter is null, if not casts it to an int
     *
     * @param checkThis
     * @return Int version of object, -1 if object was null
     */
    private int nullCheckInt(Object checkThis)
    {
        String strInt = nullCheckString(checkThis);

        if (strInt == null)
        {
            return -1;
        } else if (strInt.isEmpty())
        {
            return -1;
        }

        return (int) checkThis;
    }

    /**
     * Checks if given username is already taken
     * 
     * @param username
     *            Username to check
     * @return True if username already exists, false otherwise
     */
    private boolean usernameExists(String username)
    {
        for (User curU : usersList)
        {
            if (curU.getUsername().equals(username))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * Initializes scaled icon
     */
    private void iconSetup()
    {
        try
        {
            iconImage =
                ImageIO.read(getClass().getClassLoader()
                    .getResourceAsStream("purdueLogo.png"));

        } catch (IOException e)
        {
            System.out.println("Failed to load icons");
            e.printStackTrace();
        }
        scaledIcon =
            iconImage.getScaledInstance(64, 64,
                                        Image.SCALE_SMOOTH);

    }

    /**
     * Loads user data from server
     */
    private void loadData()
    {
        try
        {
            usersList = ci.getAllUsers();

        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error Loading Information",
                                   ERROR_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
            fe.printStackTrace();
        }
    }

    /**
     * Updates information from server every 45 seconds
     */
    private void autoUpdate()
    {
        new Timer(45000, new ActionListener()
        {

            public void actionPerformed(ActionEvent e)
            {
                loadData();
            }
        }).start();
    }

    /**
     * Connect to server without manually entering host/port name
     */
    private void bypassHostPortQuestion()
    {
        try
        {
            ci = new ClientInterface("localhost", 1234);
        } catch (FetchException ioe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Ran Into An Issue Connecting to the Server",
                                   CREATE_ACC_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
        }
    }
}
