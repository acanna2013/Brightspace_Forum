package cs180.client.database;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/**
 * Course class
 * Contains attributes of a Course, getters, and setters.
 * Contains methods to add/remove forums/students to a course.
 * Save and load course information into a file.
 * The Course class is tested in the CommandTest class.
 *
 * @author Rachel La, Zachary Mayhew
 * @version November 19, 2021
 */
// clang-format off
public class Course
{
    private UUID uuid;
    private String title;
    private UUID teacher;
    private List<UUID> students;
    private List<UUID> forums;

    public Course()
    {
    }

    public Course(String title, UUID teacher)
    {
        this.uuid = UUID.randomUUID();
        this.title = title;
        this.teacher = teacher;
        this.students = new ArrayList<>();
        this.forums = new ArrayList<>();
    }

    public Course(UUID uuid, String title, UUID teacher,
        List<UUID> students, List<UUID> forums)
    {
        this.uuid = uuid;
        this.title = title;
        this.teacher = teacher;
        this.students = students;
        this.forums = forums;
    }

    /**
     * Returns the UUID of the course
     */
    public UUID getUUID()
    {
        return this.uuid;
    }

    /**
     * Returns the title of the course
     */
    public String getTitle()
    {
        return this.title;
    }

    /**
     * Sets the title of the course to the title given as a parameter
     *
     * @param title
     */
    public void setTitle(String title)
    {
        this.title = title;
    }

    /**
     * Returns the teacher's UUID
     */
    public UUID getTeacher()
    {
        return this.teacher;
    }

    /**
     * Returns a list of UUIDs of the students enroll the course
     */
    public List<UUID> getStudents()
    {
        return this.students;
    }

    /**
     * Adds new student given as a parameter to the course
     *
     * @param student
     */
    public void addStudent(UUID student)
    {
        students.add(student);
    }

    /**
     * Removes student provided in the parameter from the course
     *
     * @param student
     */
    public void removeStudent(UUID student)
    {
        students.remove(student);
    }

    /**
     * Returns a list of UUIDs of the forums in the course
     */
    public List<UUID> getForum()
    {
        return this.forums;
    }

    @Override
    public boolean equals(Object o)
    {
        if (o == this)
            return true;
        if (!(o instanceof Course))
            return false;
        var course = (Course) o;
        return uuid.equals(course.uuid)
            && title.equals(course.title)
            && teacher.equals(course.teacher)
            && Arrays.equals(students.toArray(),
                             students.toArray())
            && Arrays.equals(forums.toArray(),
                             forums.toArray());
    }

}
// clang-format on
