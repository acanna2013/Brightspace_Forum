// @formatter:off
package cs180.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.CompoundBorder;

import cs180.client.ClientInterface.FetchException;
import cs180.client.database.Course;
import cs180.client.database.User;

/**
 * AccountView - Location for all the current user's information regarding their
 * account and how to alter it
 *
 * @author Ahmad Abdallah
 * @version November 30, 2021
 */

public class AccountView extends JPanel
{
    // String
    final static String EDIT_PROMPT = "Enter New ";
    final static String INVALID_ERROR =
        "Please Enter a Valid ";
    final static String DELETE_CONFIRMATION =
        "Please enter your username to confirm: ";
    final static String ERROR_HEADER = "Server Error";

    // Color
    final static Color PUR_GOLD_RUSH =
        Color.decode("#E8B800");
    final static Color PUR_GOLD_NEON =
        Color.decode("#C28E0E");
    final static Color DELETE_RED = Color.decode("#FF1D07");

    // Dimension
    final static Dimension MAX_PANEL_SIZE =
        new Dimension(2000, 100);

    // JFrame
    JFrame mainWindow;

    // Client Interface
    ClientInterface ci;

    // Database info
    private User currentUser;
    private List<User> usersList;
    private List<Course> courseList;

    // Timer
    Timer updateTimer;

    // Input
    private String oldField;
    private String updatedField;

    // Buttons
    JButton editNameButton;
    JButton editUserButton;
    JButton editPassButton;
    JButton deleteAccountButton;

    // Icons
    BufferedImage iconImage;
    Image scaledIcon;

    public AccountView(ClientInterface ci,
        MainWindow mainWindow)
    {

        this.mainWindow = mainWindow;

        this.ci = ci;

        updateTimer =
            new Timer(mainWindow.UPDATE_TIME,
                new ActionListener()
                {

                    public void actionPerformed(ActionEvent e)
                    {
                        if (!mainWindow
                            .checkCurrentUser())
                        { 
                            mainWindow.dispose();
                        } else
                        {
                            loadData();
                            removeAll();
                            createAndDisplayGUI();
                            revalidate();
                        }

                    }
                });

        loadData();

        iconSetup();

        createAndDisplayGUI();
    }

    public void createAndDisplayGUI()
    {
        // JPanel formatting
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.BLACK);
        setBorder(BorderFactory
            .createLineBorder(PUR_GOLD_NEON, 5));

        // View title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel,
                                           BoxLayout.X_AXIS));
        titlePanel.setOpaque(false);

        JLabel title =
            new JLabel("<html><b>Account Overview</b></html>");
        title.setForeground((PUR_GOLD_NEON));
        title.setFont(new Font("Arial", Font.PLAIN, 25));
        title.setBorder(BorderFactory
            .createEmptyBorder(10, 10, 10, 10));

        titlePanel.add(title);

        // JPanel for name ----------------------------------
        // Overall panel for name items
        JPanel namePanel = new JPanel();
        namePanel.setLayout(new BorderLayout(5, 5));
        namePanel.setBorder(new CompoundBorder(BorderFactory
            .createMatteBorder(5, 0, 0, 0, Color
                .decode("#C28E0E")), BorderFactory
                    .createEmptyBorder(10, 10, 10, 10)));
        namePanel.setMaximumSize((MAX_PANEL_SIZE));

        // Left side, indicates this is name
        JLabel nameCategory = new JLabel("Full Name");
        nameCategory.setForeground((PUR_GOLD_NEON));
        nameCategory
            .setFont(new Font("Arial", Font.BOLD, 20));

        // Right side, users name and edit button
        JPanel rightSideName = new JPanel();
        rightSideName
            .setLayout(new BoxLayout(rightSideName,
                                     BoxLayout.X_AXIS));

        JLabel name = new JLabel(currentUser.getFullName());
        name.setForeground((PUR_GOLD_NEON));
        name.setFont(new Font("Arial", Font.BOLD, 20));

        editNameButton = new JButton("Edit");
        editNameButton.setForeground(PUR_GOLD_RUSH);
        editNameButton
            .setFont(new Font("Arial", Font.BOLD, 20));
        editNameButton.setBorderPainted(false);

        rightSideName.add(name);
        rightSideName.add(editNameButton);

        namePanel.add(nameCategory, BorderLayout.LINE_START);
        namePanel.add(rightSideName, BorderLayout.LINE_END);

        // JPanel for Username --------------------------------
        JPanel userPanel = new JPanel();
        userPanel.setLayout(new BorderLayout(5, 5));
        userPanel.setBorder(BorderFactory
            .createEmptyBorder(10, 10, 10, 10));
        userPanel.setMaximumSize((MAX_PANEL_SIZE));

        // Left side, indicates this is username
        JLabel userCategory = new JLabel("Username");
        userCategory.setForeground((PUR_GOLD_NEON));
        userCategory
            .setFont(new Font("Arial", Font.BOLD, 20));

        // Right side, users name and edit button
        JPanel rightSideUser = new JPanel();
        rightSideUser
            .setLayout(new BoxLayout(rightSideUser,
                                     BoxLayout.X_AXIS));

        JLabel user = new JLabel(currentUser.getUsername());
        user.setForeground((PUR_GOLD_NEON));
        user.setFont(new Font("Arial", Font.BOLD, 20));

        editUserButton = new JButton("Edit");
        editUserButton.setForeground(PUR_GOLD_RUSH);
        editUserButton
            .setFont(new Font("Arial", Font.BOLD, 20));
        editUserButton.setBorderPainted(false);

        rightSideUser.add(user);
        rightSideUser.add(editUserButton);

        userPanel.add(userCategory, BorderLayout.LINE_START);
        userPanel.add(rightSideUser, BorderLayout.LINE_END);

        // JPanel for Password -------------------------------
        JPanel passPanel = new JPanel();
        passPanel.setLayout(new BorderLayout(5, 5));
        passPanel.setBorder(BorderFactory
            .createEmptyBorder(10, 10, 10, 10));
        passPanel.setMaximumSize((MAX_PANEL_SIZE));

        // Left side, indicates this is password
        JLabel passCategory = new JLabel("Password");
        passCategory.setForeground((PUR_GOLD_NEON));
        passCategory
            .setFont(new Font("Arial", Font.BOLD, 20));

        // Right side, users name and edit button
        JPanel rightSidePass = new JPanel();
        rightSidePass
            .setLayout(new BoxLayout(rightSidePass,
                                     BoxLayout.X_AXIS));

        JLabel pass = new JLabel(currentUser.getPassword());
        pass.setForeground((PUR_GOLD_NEON));
        pass.setFont(new Font("Arial", Font.BOLD, 20));

        editPassButton = new JButton("Edit");
        editPassButton.setForeground(PUR_GOLD_RUSH);
        editPassButton
            .setFont(new Font("Arial", Font.BOLD, 20));
        editPassButton.setBorderPainted(false);

        rightSidePass.add(pass);
        rightSidePass.add(editPassButton);

        passPanel.add(passCategory, BorderLayout.LINE_START);
        passPanel.add(rightSidePass, BorderLayout.LINE_END);

        // JPanel for account type ------------------------------
        JPanel kindPanel = new JPanel();
        kindPanel.setLayout(new BoxLayout(kindPanel,
                                          BoxLayout.X_AXIS));
        kindPanel.setBorder(BorderFactory
            .createEmptyBorder(10, 10, 10, 10));
        kindPanel.setMinimumSize((MAX_PANEL_SIZE));

        JLabel kind =
            new JLabel(String
                .format("<html>Account Type: %s</html>",
                        currentUser.getKind()));
        kind.setForeground((PUR_GOLD_NEON));
        kind.setFont(new Font("Arial", Font.BOLD, 20));

        kindPanel.add(kind);

        // JPanel for all user courses -------------------------
        JPanel coursePanel = new JPanel();
        coursePanel
            .setLayout(new BoxLayout(coursePanel,
                                     BoxLayout.X_AXIS));
        coursePanel.setBorder(BorderFactory
            .createEmptyBorder(10, 10, 10, 10));
        namePanel.setMinimumSize((MAX_PANEL_SIZE));

        String coursesStr = "";
        for (UUID curCourse : currentUser.getCourses())
        {
            if (!coursesStr.isEmpty())
            {
                coursesStr += ", ";
            }

            // Getting course title and adding to string of user's courses
            for (Course c : courseList)
            {
                if (c.getUUID().equals(curCourse))
                {
                    coursesStr += c.getTitle();
                }
            }
        }

        JLabel courses =
            new JLabel(String
                .format("<html>Courses: %s</html>",
                        coursesStr));
        courses.setForeground((PUR_GOLD_NEON));
        courses.setFont(new Font("Arial", Font.BOLD, 20));

        coursePanel.add(courses);

        // JPanel for delete account button
        JPanel delete = new JPanel();
        coursePanel.setBorder(BorderFactory
            .createEmptyBorder(10, 10, 10, 10));

        deleteAccountButton =
            new JButton("<html>Delete Account</html>");
        deleteAccountButton.setForeground(DELETE_RED);
        deleteAccountButton
            .setFont(new Font("Arial", Font.BOLD, 24));

        delete.add(deleteAccountButton);
        
        /**
         * A class which controls the action listener for the account view
         *
         */
        class ControlActionListener implements ActionListener
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (e.getSource() == editNameButton)
                {
                    updatedField = enterNew("Name");

                    if (updatedField != null)
                    {
                        currentUser.setFullName(updatedField);
                        updateAccount();
                        name.setText(currentUser
                            .getFullName());
                        revalidate();
                    }
                } else if (e.getSource() == editUserButton)
                {
                    updatedField = enterNew("Username");

                    if (updatedField != null)
                    {
                        if (usernameExists(updatedField))
                        {
                            JOptionPane
                                .showMessageDialog(null,
                                                   "This Username is Taken",
                                                   "Edit Account",
                                                   JOptionPane.ERROR_MESSAGE);
                        } else
                        {
                            currentUser
                                .setUsername(updatedField);
                            updateAccount();
                            user.setText(currentUser
                                .getUsername());
                            revalidate();
                        }

                    }
                } else if (e.getSource() == editPassButton)
                {
                    updatedField = enterNew("Password");

                    if (updatedField != null)
                    {
                        currentUser.setPassword(updatedField);
                        updateAccount();
                        pass.setText(currentUser
                            .getPassword());
                        revalidate();
                    }
                } else if (e.getSource()
                    == deleteAccountButton)
                {
                    boolean proceed = deleteAccount();
                    if (proceed)
                    {
                        delete();
                        mainWindow.dispose();
                    }
                }
            }
        }

        ControlActionListener actionListener =
            new ControlActionListener();

        // Adding action listener to buttons
        editNameButton.addActionListener(actionListener);
        editUserButton.addActionListener(actionListener);
        editPassButton.addActionListener(actionListener);
        deleteAccountButton.addActionListener(actionListener);

        // Adding components to overarching JPanel
        add(titlePanel);
        add(namePanel);
        add(userPanel);
        add(passPanel);
        add(kindPanel);
        add(coursePanel);
        add(delete);

        // Configuring overarching JPanel
        setVisible(true);
    }

    /**
     * Updates the currect user on server
     */
    private void updateAccount()
    {
        try
        {
            ci.updateUser(currentUser);
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "There Was an Issue Updating Your Account",
                                   ERROR_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
        }

    }

    /**
     * Deletes user from server
     */
    private void delete()
    {
        try
        {
            ci.deleteUser(currentUser.getUUID());
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "There Was an Issue Deleting Your Account",
                                   ERROR_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Checks if parameter is null, if not casts it to a string
     *
     * @param checkThis
     * @return String version of object, null if object was null
     */
    private String nullCheck(Object checkThis)
    {
        if (checkThis == null)
        {
            return null;
        }

        return checkThis.toString();
    }

    /**
     * Prompts user for account field using requested parameter
     *
     * @param whatsNew
     *            Which field the JOptionPane will ask for
     * @return String containing user entry, null if user canceled
     */
    private String enterNew(String whatsNew)
    {
        String question = EDIT_PROMPT + whatsNew;
        String header = "Edit " + whatsNew;
        String error = INVALID_ERROR + whatsNew;
        String newVal = "";

        do
        {
            Object input =
                JOptionPane
                    .showInputDialog(this, question, header,
                                     JOptionPane.QUESTION_MESSAGE,
                                     new ImageIcon(scaledIcon),
                                     null, null);

            newVal = nullCheck(input);

            if (newVal == null)
            {
                return null;

            } else if (newVal.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null, error, header,
                                       JOptionPane.ERROR_MESSAGE);
            }
        }
        while (newVal.isEmpty());

        return newVal;
    }

    /**
     * Confirms user would like to delete account
     *
     * @return True if user confirms to delete, false otherwise
     */
    private boolean deleteAccount()
    {
        Object input;
        String deleteCheck =
            DELETE_CONFIRMATION + currentUser.getUsername();
        String typedUser = "";
        String header = "Delete Account";
        String emptyError = INVALID_ERROR + "Username";
        String nonMatchError =
            "The usernames don't match. Delete aborted";

        do
        {
            input =
                JOptionPane
                    .showInputDialog(this, deleteCheck,
                                     "Delete Account",
                                     JOptionPane.QUESTION_MESSAGE,
                                     new ImageIcon(scaledIcon),
                                     null, null);

            typedUser = nullCheck(input);

            if (typedUser == null)
            {
                return false;

            } else if (typedUser.isEmpty())
            {
                JOptionPane
                    .showMessageDialog(null, emptyError,
                                       header,
                                       JOptionPane.ERROR_MESSAGE);
            } else if (!typedUser
                .equals(currentUser.getUsername()))
            {
                JOptionPane
                    .showMessageDialog(null, nonMatchError,
                                       header,
                                       JOptionPane.ERROR_MESSAGE);
                return false;
            } else if (typedUser
                .equals(currentUser.getUsername()))
            {
                break;
            }

        }
        while (typedUser.isEmpty());

        return true;

    }

    /**
     * Checks if given username is already taken
     *
     * @param username
     *            Username to check
     * @return True if username already exists, false otherwise
     */
    private boolean usernameExists(String username)
    {
        for (User curU : usersList)
        {
            if (curU.getUsername().equals(username))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * Loads user, current user, and course data from server
     */
    public void loadData()
    {
        try
        {
            currentUser = ci.getUser(ci.getCurrentUser());

            courseList = ci.getAllCourses();

            usersList = ci.getAllUsers();
        } catch (FetchException fe)
        {
            JOptionPane
                .showMessageDialog(null,
                                   "Error Loading Information",
                                   ERROR_HEADER,
                                   JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Initializes scaled icon
     */
    private void iconSetup()
    {
        try
        {
            iconImage =
                ImageIO.read(getClass().getClassLoader()
                    .getResourceAsStream("purdueLogo.png"));

        } catch (IOException e)
        {
            System.out.println("Failed to load icons");
            e.printStackTrace();
        }
        scaledIcon =
            iconImage.getScaledInstance(64, 64,
                                        Image.SCALE_SMOOTH);

    }

    /**
     * Updates information from server every 10 seconds and refreshes UI
     */
    public void startAutoUpdate()
    {
        updateTimer.start();
    }

    /**
     * Pauses information transfer and UI updates
     */
    public void pauseAutoUpdate()
    {
        updateTimer.stop();
    }

}
