# Test cases

- [Test cases](#test-cases)
  - [Cases](#cases)
    - [Users](#users)
      - [1. Login: `Pass`](#1-login-pass)
      - [2. Create user `Pass`](#2-create-user-pass)
      - [3. Login with invalid user](#3-login-with-invalid-user)
      - [4. Edit user `Pass`](#4-edit-user-pass)
      - [5. Delete user `Pass`](#5-delete-user-pass)
      - [6. List users `Pass`](#6-list-users-pass)
      - [7. List posts made by user `Pass`](#7-list-posts-made-by-user-pass)
    - [Courses](#courses)
      - [8. Create course `Pass`](#8-create-course-pass)
      - [9. Edit course `Pass`](#9-edit-course-pass)
      - [10. Delete course `Pass`](#10-delete-course-pass)
      - [11. Join course `Pass`](#11-join-course-pass)
      - [12. Open course `Pass`](#12-open-course-pass)
    - [Forums](#forums)
      - [13. Create forum `Pass`](#13-create-forum-pass)
      - [14. Delete forum `Pass`](#14-delete-forum-pass)
      - [15. Edit forum `Pass`](#15-edit-forum-pass)
      - [16. Open forum `Pass`](#16-open-forum-pass)
    - [Posts](#posts)
      - [17. Create a post `Pass`](#17-create-a-post-pass)
      - [18. Sort oldest-newest `Pass`](#18-sort-oldest-newest-pass)
      - [19. Sort newest-oldest `Pass`](#19-sort-newest-oldest-pass)
      - [20. Upvote a post `Pass`](#20-upvote-a-post-pass)
      - [21. Sort by votes `Pass`](#21-sort-by-votes-pass)
      - [22. Reply to a post `Pass`](#22-reply-to-a-post-pass)
      - [23. Score a post `Pass`](#23-score-a-post-pass)
      - [24. Edit a post `Pass`](#24-edit-a-post-pass)
      - [25. Delete a post `Pass`](#25-delete-a-post-pass)
    - [Update](#updates)
      - [26. Update user view `Pass`](#26-update-user-view-pass)
      - [27. Update course view `Pass`](#27-update-course-view-pass)
      - [28. Update forum view `Pass`](#28-update-forum-view-pass)
      - [29. Update post view `Pass`](#29-update-post-view-pass)


## Cases

### Users

#### 1. Login: `Pass`

1. Enter server IP Address and Port
2. Enter a valid username and password
3. Click the login button or return key

> Expected result: The application opens to the main window

#### 2. Create user `Pass`

1. Click the `Create user` button
2. Enter the required fields

> Expected result: The new user should be logged in

#### 3. Login with invalid user

1. Login with invalid username and password

> Expected result: An error message will be displayed

#### 4. Edit user `Pass`

1. Login to a user account
2. Go to the `Account` page
3. Edit a field

> Expected result: The field should change for the user

#### 5. Delete user `Pass`

1. Login to a user account with teacher privileges
2. Go to the `Users` page
3. Delete a user

> Expected result: The user should be deleted

#### 6. List users `Pass`

1. Login to a user account with teacher privileges
2. Go to the `Users` page

> Expected result: The user should see all registered users
#### 7. List posts made by user `Pass`

1. Login to a user account with teacher privileges
2. Go to the `Users` page
3. Click `List Posts`

> Expected result: The user should see all posts for a particular user

### Courses

#### 8. Create course `Pass`

1. Login to a user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Create course` button
4. Enter the required fields

> Expected result: The new course should appear

#### 9. Edit course `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Edit` button under a the previously created course
4. Enter yes to affirm editing course
5. Enter <span style="color:green">My Course</span>

> Expected result: The course's name should change to **My Course**

#### 10. Delete course `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Create` button at the top of the page
4. Enter <span style="color:green">Delete this course</span> as the name of the course
5. Click the `Delete` button under a the previously created course
6. Enter yes to affirm deleting course

> Expected result: The course titled **Delete this course** should be deleted and removed from the course panel

#### 11. Join course `Pass`
1. Create a student user named <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Join` button on the course titled <span style="color:green">My Course</span>
4. Enter yes to affirm joining course
6. Go to the `Users` page

> Expected result: The course list for your user now has **My Course**

#### 12. Open course `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on My Course

> Expected result: The forum view for this course is displayed
>> - Note: This will be blank since no forums exist yet

### Forums

#### 13. Create forum `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Create Forum` button at the top of the page
5. Enter the required fields

> Expected result: A forum with the entered title will appear on the forum view

#### 14. Delete forum `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Create Forum` button at the top of the page
5. Enter the name <span style="color:green">Delete this forum</span>.
6. Click the `Delete` button next to the forum created in the previous step

> Expected result: The forum titled **Delete this forum** will be deleted and removed from the forum view

#### 15. Edit forum `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Edit` button on the forum created in step #13
5. Enter <span style="color:green">My Forum</span>

> Expected result: The forum name will change to **My Forum**

#### 16. Open forum `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>

> Expected result: The post view for the **My Forum** will be visible
>> - Note: This will be blank since no posts exist yet

### Posts

#### 17. Create a post `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Create Post` button at the top right of the post view nav bar
6. Title the post <span style="color:green">My First Post</span>
7. Add text to the post message
8. Click the `Submit` button

> Expected Result: Your post titled **My First Post** has appeared in the post feed

#### 18. Sort oldest-newest `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Create Post` button at the top right of the post view nav bar
6. Title the post <span style="color:green">A Second Post</span>
7. Add text to the post message
8. Click the `submit` button
9. Click the `Oldest-Newest` button in the post view nav bar

> Expected Result: The post feed is sorted from oldest to newest, with **My First Post** on top **A Second Post**
>> - Note: The default order of the post feed is oldest to newest, so it might not appear to change

#### 19. Sort newest-oldest `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
9. Click the `Newest-Oldest` button in the post view nav bar

> Expected Result: The post feed is sorted from newest to oldest, with **A Second Post** on top **My First Post**

#### 20. Upvote a post `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Upvote` button on any post

> Expected Result: The upvote counter on the selected post has incremented by one

#### 21. Sort by votes `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `By Votes` button on the post view nav bar

> Expected Result: The view will be sorted by votes, with the highest voted post at the bottom

#### 22. Reply to a post `Pass`
1. Login to <span style="color:green">John Doe</span>
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Reply` button on any post
6. Enter a title and message body
7. Click the `submit` button

> Expected Result: The reply will appear indented underneath the selected parent post

#### 23. Score a post `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Score` button on any post
6. Enter a grade for the post
7. Click `OK` to confirm

> Expected Result: The selected post's grade label will update to reflect the entered grade

#### 24. Edit a post `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Edit` button on any post
6. Update the title and post message with new text
7. Click `Submit` to confirm

> Expected Result: The selected post has updated to reflect your edits

#### 25. Delete a post `Pass`
1. Login to user account with teacher privileges
2. Go to the `Courses` page from the nav bar
3. Click the `Open` button on <span style="color:green">My Course</span>
4. Click the `Open` button on <span style="color:green">My Forum</span>
5. Click the `Delete` button on any post

> Expected Result: The post has been deleted and removed from the post view

### Updates

#### 26. Update user view `pass`
1. Login to <span style="color:green">John Doe</span>
2. On a separate screen open client again
3. Click the `Create Account` button and fill in the fields

> Expected Result: The created user has appeared on the **John Doe** user view 

#### 27. Update course view `pass`
1. Login to <span style="color:green">John Doe</span>
2. Open the course view from the top nav bar
3. On a seperate screen Login to an account with teacher privileges
4. Open the course view from the top nav bar
5. Click the `Create Course` button and fill in the fields

> Expected Result: The created course will appear on the **John Doe** user view

#### 28. Update forum view `pass`
1. Login to <span style="color:green">John Doe</span>
2. Open <span style"color:green">My Course</span> from the course view
3. On a seperate screen Login to an account with teacher privileges
4. Open the course view from the top nav bar
5. Open <span style"color:green">My Course</span> from the course view
6. Click the `Create Forum` button and fill in fields

> Expected Result: The created forum will appear on the **John Doe** user view

#### 29. Update post view `pass`
1. Login to <span style="color:green">John Doe</span>
2. Open <span style"color:green">My Course</span> from the course view
3. Open <span style"color:green">My Forum</span> from the <span style"color:green">My Course</span> view
4. On a seperate screen Login to an account with teacher privileges
5. Open the course view from the top nav bar
6. Open <span style"color:green">My Course</span> from the course view
7. Open <span style"color:green">My Forum</span> from the <span style"color:green">My Course</span> view
8. Click the `Create Post` button on the post view nav bar and fill in the fields


> Expected Result: The created post will appear on the **John Doe** user view

